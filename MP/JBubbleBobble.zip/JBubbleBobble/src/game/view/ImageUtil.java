package game.view;

import game.model.*;
import game.model.entities.*;
import game.model.entities.bubbles.*;
import game.model.entities.bubbles.special_bubbles.*;
import game.model.entities.opps.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.lang.Character;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Class that handles the images for the project. Images are loaded from here, and, if needed,
 * put into Collections.
 */
public class ImageUtil {

    private HashMap<BlockType, BufferedImage> blocks;
    private static ImageUtil instance;

    /**
     * ImageUtil constructor according to the Singleton Design Pattern
     */
    private ImageUtil(){
        blocks = new HashMap<>();
        dealBlocks();
    }

    /**
     * @return the ImageUtil instance (Singleton Design Pattern)
     */
    public static ImageUtil getInstance(){
        if(instance == null) instance = new ImageUtil();
        return instance;
    }

    /**
     * Fills the "blocks" HashMap (with the block type as a key and the block image as the associated object)
     */
    public void dealBlocks(){
        try{
            blocks.put(BlockType.ZERO, ImageIO.read(ImageUtil.class.getResource("../../resources/blocks/empty.png")));
            BlockType blockType;
            for(int i = 1; i < 101; i++){
                blockType = BlockType.getBlock(i);
                blocks.put(blockType, ImageIO.read(ImageUtil.class.getResource("../../resources/blocks/super blocks/block_"+ i + ".png")));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Fills the given HashMap (HashMap of HashMaps of Animation keys and SpriteIterator associated objects, using the "setSpriteIterator" method).
     * @param imageDealer HashMap to fill
     */
    public static void dealImages(HashMap<Class, HashMap<Animation, SpriteIterator>> imageDealer) {

        HashMap<Animation, SpriteIterator> bubMap = new HashMap<>();

        setSpriteIterator(bubMap, Animation.LEFT, "../../resources/sprites/bubblun/moving/", "moving_left", 7, 0.1);
        setSpriteIterator(bubMap, Animation.RIGHT, "../../resources/sprites/bubblun/moving/", "moving_right", 7, 0.1);
        setSpriteIterator(bubMap, Animation.JUMPING_LEFT, "../../resources/sprites/bubblun/jumping/", "jumping_left", 5, 0.2);
        setSpriteIterator(bubMap, Animation.JUMPING_RIGHT, "../../resources/sprites/bubblun/jumping/", "jumping_right", 5, 0.2);
        setSpriteIterator(bubMap, Animation.SHOOTING_LEFT, "../../resources/sprites/bubblun/shooting/", "shoot_left", 4, 0.1);
        setSpriteIterator(bubMap, Animation.SHOOTING_RIGHT, "../../resources/sprites/bubblun/shooting/", "shoot_right", 4, 0.1);
        setSpriteIterator(bubMap, Animation.DAMAGED, "../../resources/sprites/bubblun/dying/", "dying", 13, 0.24);
        setSpriteIterator(bubMap, Animation.FLOATING,"../../resources/sprites/bubblun/level transition/", "", 10, 0.15);
        setSpriteIterator(bubMap, Animation.BURNT,"../../resources/sprites/bubblun/burnt/", "burnt", 2, 0.1);
        setSpriteIterator(bubMap, Animation.MELTING,"../../resources/sprites/bubblun/melting/", "melting", 16, 0.15);

        imageDealer.put(Bubblun.class, bubMap);

        //add bubbles
        HashMap<Animation, SpriteIterator> bubbleMap = new HashMap<>();

        setSpriteIterator(bubbleMap, Animation.SPAWNING, "../../resources/bubbles/spawning/", "spawning", 6, 0.5);
        setSpriteIterator(bubbleMap, Animation.FLOATING, "../../resources/bubbles/floating/", "floating", 3, 0.1);
        setSpriteIterator(bubbleMap, Animation.EXPLODING1, "../../resources/bubbles/exploding1/", "exploding", 3, 0.1);
        setSpriteIterator(bubbleMap, Animation.EXPLODING2, "../../resources/bubbles/exploding2/", "exploding", 6, 0.2);
        setSpriteIterator(bubbleMap, Animation.POPPED, "../../resources/bubbles/pop/", "pop", 2, 0.5);

        setSpriteIterator(bubbleMap, Animation.ZENCHAN, "../../resources/bubbles/zen chan/bubble green/", "green", 4, 0.1);
        setSpriteIterator(bubbleMap, Animation.ZENCHAN_EXPLODING1, "../../resources/bubbles/zen chan/bubble orange/", "orange", 4, 0.1);
        setSpriteIterator(bubbleMap, Animation.ZENCHAN_EXPLODING2, "../../resources/bubbles/zen chan/bubble exploding/", "exploding", 8, 0.2);

        setSpriteIterator(bubbleMap, Animation.MIGHTA, "../../resources/bubbles/mighta/bubble green/", "green", 4, 0.1);
        setSpriteIterator(bubbleMap, Animation.MIGHTA_EXPLODING1, "../../resources/bubbles/mighta/bubble orange/", "orange", 4, 0.1);
        setSpriteIterator(bubbleMap, Animation.MIGHTA_EXPLODING2, "../../resources/bubbles/mighta/bubble exploding/", "exploding", 8, 0.2);

        setSpriteIterator(bubbleMap, Animation.MONSTA, "../../resources/bubbles/monsta/bubble green/", "green", 4, 0.1);
        setSpriteIterator(bubbleMap, Animation.MONSTA_EXPLODING1, "../../resources/bubbles/monsta/bubble orange/", "orange", 4, 0.1);
        setSpriteIterator(bubbleMap, Animation.MONSTA_EXPLODING2, "../../resources/bubbles/monsta/bubble exploding/", "exploding", 8, 0.2);

        setSpriteIterator(bubbleMap, Animation.INVADER, "../../resources/bubbles/invader/bubble green/", "green", 4, 0.1);
        setSpriteIterator(bubbleMap, Animation.INVADER_EXPLODING1, "../../resources/bubbles/invader/bubble orange/", "orange", 4, 0.1);
        setSpriteIterator(bubbleMap, Animation.INVADER_EXPLODING2, "../../resources/bubbles/invader/bubble exploding/", "exploding", 8, 0.2);

        setSpriteIterator(bubbleMap, Animation.BANEBOU, "../../resources/bubbles/banebou/bubble green/", "green", 4, 0.1);
        setSpriteIterator(bubbleMap, Animation.BANEBOU_EXPLODING1, "../../resources/bubbles/banebou/bubble orange/", "orange", 4, 0.1);
        setSpriteIterator(bubbleMap, Animation.BANEBOU_EXPLODING2, "../../resources/bubbles/banebou/bubble exploding/", "exploding", 8, 0.2);

        setSpriteIterator(bubbleMap, Animation.HIDEGONS, "../../resources/bubbles/hidegons/bubble green/", "green", 4, 0.1);
        setSpriteIterator(bubbleMap, Animation.HIDEGONS_EXPLODING1, "../../resources/bubbles/hidegons/bubble orange/", "orange", 4, 0.1);
        setSpriteIterator(bubbleMap, Animation.HIDEGONS_EXPLODING2, "../../resources/bubbles/hidegons/bubble exploding/", "exploding", 8, 0.2);
        imageDealer.put(BBubble.class, bubbleMap);

        HashMap<Animation, SpriteIterator> waterBubbleMap = new HashMap<>();
        setSpriteIterator(waterBubbleMap, Animation.WATER, "../../resources/bubbles/water/", "water", 3, 0.1);
        setSpriteIterator(waterBubbleMap, Animation.POPPED, "../../resources/bubbles/pop/", "pop", 2, 0.5);
        imageDealer.put(WaterBubble.class, waterBubbleMap);

        HashMap<Animation, SpriteIterator> fireBubbleMap = new HashMap<>();
        setSpriteIterator(fireBubbleMap, Animation.FIRE, "../../resources/bubbles/fire/", "fire", 3, 0.1);
        imageDealer.put(FireBubble.class, fireBubbleMap);


        HashMap<Animation, SpriteIterator> fireBlockMap = new HashMap<>();
        setSpriteIterator(fireBlockMap, Animation.FIRE_GROUND, "../../resources/sprites/misc/fire/", "ground", 5, 0.1);
        setSpriteIterator(fireBlockMap, Animation.FIRE_DROPPING, "../../resources/sprites/misc/fire/", "dropping", 4, 0.1);
        setSpriteIterator(fireBlockMap, Animation.POPPED, "../../resources/bubbles/pop/", "pop", 2, 0.5);
        imageDealer.put(Blaze.FireBlock.class, fireBlockMap);

        HashMap<Animation, SpriteIterator> lightningBubbleMap = new HashMap<>();
        setSpriteIterator(lightningBubbleMap, Animation.LIGHTNING, "../../resources/bubbles/lightning/", "lightning", 3, 0.1);
        setSpriteIterator(lightningBubbleMap, Animation.POPPED, "../../resources/bubbles/pop/", "pop", 2, 0.5);
        imageDealer.put(LightningBubble.class, lightningBubbleMap);

        HashMap<Animation, SpriteIterator> lightningMap = new HashMap<>();
        setSpriteIterator(lightningMap, Animation.LIGHTNING_STORM, "../../resources/sprites/misc/storm/", "storm", 3, 0.5);
        setSpriteIterator(lightningMap, Animation.LIGHTNING_STRUCK, "../../resources/sprites/misc/storm/", "struck", 6, 0.2);
        imageDealer.put(Storm.Lightning.class, lightningMap);

        HashMap<Animation, SpriteIterator> spellMap = new HashMap<>();
        setSpriteIterator(spellMap, Animation. FLOATING, "../../resources/sprites/mighta/spell/", "spell", 4, 0.1);
        setSpriteIterator(spellMap, Animation.POPPED, "../../resources/sprites/mighta/spell/", "popping", 3, 0.1);
        imageDealer.put(Spell.class, spellMap);

        HashMap<Animation, SpriteIterator> fireballMap = new HashMap<>();
        setSpriteIterator(fireballMap, Animation.SPAWNING_LEFT, "../../resources/sprites/hidegons/blast left/", "left", 6, 0.1);
        setSpriteIterator(fireballMap, Animation.SPAWNING_RIGHT, "../../resources/sprites/hidegons/blast right/", "right", 6, 0.1);
        imageDealer.put(Fireball.class, fireballMap);

        HashMap<Animation, SpriteIterator> zapMap = new HashMap<>();
        setSpriteIterator(zapMap, Animation.FLOATING, "../../resources/sprites/invader/zap/", "zap", 2, 0.1);
        setSpriteIterator(zapMap, Animation.POPPED, "../../resources/sprites/invader/zap/", "end", 2, 0.1);
        imageDealer.put(Zap.class, zapMap);


        // add enemies
        HashMap<Animation, SpriteIterator> zenChanMap = new HashMap<>();
        setSpriteIterator(zenChanMap, Animation.LEFT, "../../resources/sprites/zen-chan/normal left/", "left", 4, 0.1);
        setSpriteIterator(zenChanMap, Animation.RIGHT, "../../resources/sprites/zen-chan/normal right/", "right", 4, 0.1);
        setSpriteIterator(zenChanMap, Animation.ANGRY_LEFT, "../../resources/sprites/zen-chan/angry left/", "left", 4, 0.1);
        setSpriteIterator(zenChanMap, Animation.ANGRY_RIGHT, "../../resources/sprites/zen-chan/angry right/", "right", 4, 0.1);
        setSpriteIterator(zenChanMap, Animation.DYING, "../../resources/sprites/zen-chan/dying/", "dying", 8, 0.1);
        imageDealer.put(ZenChan.class, zenChanMap);

        HashMap<Animation, SpriteIterator> mightaMap = new HashMap<>();
        setSpriteIterator(mightaMap, Animation.LEFT, "../../resources/sprites/mighta/normal left/","left", 4, 0.1);
        setSpriteIterator(mightaMap, Animation.RIGHT, "../../resources/sprites/mighta/normal right/", "right", 4, 0.1);
        setSpriteIterator(mightaMap, Animation.ANGRY_LEFT, "../../resources/sprites/mighta/angry left/", "left", 4, 0.1);
        setSpriteIterator(mightaMap, Animation.ANGRY_RIGHT, "../../resources/sprites/mighta/angry right/", "right", 4, 0.1);
        setSpriteIterator(mightaMap, Animation.SHOOTING_LEFT, "../../resources/sprites/mighta/normal shooting left/", "left", 5, 0.1);
        setSpriteIterator(mightaMap, Animation.SHOOTING_RIGHT, "../../resources/sprites/mighta/normal shooting right/", "right", 5, 0.1);
        setSpriteIterator(mightaMap, Animation.ANGRY_SHOOTING_LEFT, "../../resources/sprites/mighta/angry shooting left/", "left", 5, 0.1);
        setSpriteIterator(mightaMap, Animation.ANGRY_SHOOTING_RIGHT, "../../resources/sprites/mighta/angry shooting right/", "right", 5, 0.1);
        setSpriteIterator(mightaMap, Animation.DYING, "../../resources/sprites/mighta/dying/", "dying",9 ,0.1);
        imageDealer.put(Mighta.class, mightaMap);

        HashMap<Animation, SpriteIterator> monstaMap = new HashMap<>();
        setSpriteIterator(monstaMap, Animation.LEFT, "../../resources/sprites/monsta/normal left/","left", 2, 0.1);
        setSpriteIterator(monstaMap, Animation.RIGHT, "../../resources/sprites/monsta/normal right/", "right", 2, 0.1);
        setSpriteIterator(monstaMap, Animation.ANGRY_LEFT, "../../resources/sprites/monsta/angry left/", "left", 2, 0.1);
        setSpriteIterator(monstaMap, Animation.ANGRY_RIGHT, "../../resources/sprites/monsta/angry right/", "right", 2, 0.1);
        setSpriteIterator(monstaMap, Animation.DYING, "../../resources/sprites/monsta/dying/", "dying", 4, 0.1);
        imageDealer.put(Monsta.class, monstaMap);

        HashMap<Animation, SpriteIterator> invaderMap = new HashMap<>();
        setSpriteIterator(invaderMap, Animation.LEFT, "../../resources/sprites/invader/normal/","normal", 2, 0.1);
        setSpriteIterator(invaderMap, Animation.RIGHT, "../../resources/sprites/invader/normal/", "normal", 2, 0.1);
        setSpriteIterator(invaderMap, Animation.ANGRY_LEFT, "../../resources/sprites/invader/angry/", "angry", 2, 0.1);
        setSpriteIterator(invaderMap, Animation.ANGRY_RIGHT, "../../resources/sprites/invader/angry/", "angry", 2, 0.1);
        setSpriteIterator(invaderMap, Animation.DYING, "../../resources/sprites/invader/dying/", "dying", 6, 0.1);
        imageDealer.put(Invader.class, invaderMap);

        HashMap<Animation, SpriteIterator> banebouMap = new HashMap<>();
        setSpriteIterator(banebouMap, Animation.LEFT, "../../resources/sprites/banebou/normal left/","left", 4, 0.1);
        setSpriteIterator(banebouMap, Animation.RIGHT, "../../resources/sprites/banebou/normal right/", "right", 4, 0.1);
        setSpriteIterator(banebouMap, Animation.ANGRY_LEFT, "../../resources/sprites/banebou/angry left/", "left", 4, 0.1);
        setSpriteIterator(banebouMap, Animation.ANGRY_RIGHT, "../../resources/sprites/banebou/angry right/", "right", 4, 0.1);
        setSpriteIterator(banebouMap, Animation.DYING, "../../resources/sprites/banebou/dying/", "dying", 8, 0.1);
        imageDealer.put(Banebou.class, banebouMap);

        HashMap<Animation, SpriteIterator> hidegonsMap = new HashMap<>();

        setSpriteIterator(hidegonsMap, Animation.LEFT, "../../resources/sprites/hidegons/normal left/walk/","left", 3, 0.1);
        setSpriteIterator(hidegonsMap, Animation.JUMPING_LEFT, "../../resources/sprites/hidegons/normal left/jump/","left", 3, 0.1);
        setSpriteIterator(hidegonsMap, Animation.RIGHT, "../../resources/sprites/hidegons/normal right/walk/", "right", 3, 0.1);
        setSpriteIterator(hidegonsMap, Animation.JUMPING_RIGHT, "../../resources/sprites/hidegons/normal right/jump/","right", 3, 0.1);
        setSpriteIterator(hidegonsMap, Animation.ANGRY_LEFT, "../../resources/sprites/hidegons/angry left/walk/", "left", 3, 0.1);
        setSpriteIterator(hidegonsMap, Animation.ANGRY_JUMPING_LEFT, "../../resources/sprites/hidegons/angry left/jump/", "left", 3, 0.1);
        setSpriteIterator(hidegonsMap, Animation.ANGRY_RIGHT, "../../resources/sprites/hidegons/angry right/walk/", "right", 3, 0.1);
        setSpriteIterator(hidegonsMap, Animation.ANGRY_JUMPING_RIGHT, "../../resources/sprites/hidegons/angry right/jump/", "right", 3, 0.1);
        setSpriteIterator(hidegonsMap, Animation.DYING, "../../resources/sprites/hidegons/dying/", "dying", 10, 0.1);
        imageDealer.put(Hidegons.class, hidegonsMap);

        HashMap<Animation, SpriteIterator> SkelMonstaMap = new HashMap<>();
        setSpriteIterator(SkelMonstaMap, Animation.SPAWNING, "../../resources/sprites/monsta/skel-monsta/spawning/", "spawning",3, 0.1);
        setSpriteIterator(SkelMonstaMap, Animation.LEFT, "../../resources/sprites/monsta/skel-monsta/left/", "left", 2, 0.2);
        setSpriteIterator(SkelMonstaMap, Animation.RIGHT, "../../resources/sprites/monsta/skel-monsta/right/", "right", 2, 0.2);
        imageDealer.put(SkelMonsta.class, SkelMonstaMap);

        HashMap<Animation, SpriteIterator> starMap = new HashMap<>();
        setSpriteIterator(starMap, Animation.STAR, "../../resources/sprites/misc/star/", "star", 6, 0.2);
        imageDealer.put(Star.class, starMap);

        HashMap<Animation, SpriteIterator> levelMap = new HashMap<>();
        setSpriteIterator(levelMap, Animation.HURRY_UP, "../../resources/sprites/levels/", "hurryup", 2 ,0.1);
        imageDealer.put(Level.class, levelMap);
    }

    /**
     * Adds BufferedImages to a given ArrayList (from a base filename that all the images share, and the number in the last filename).
     * @param list the ArrayList of BufferedImages.
     * @param path the path before the file name.
     * @param fileName base file name
     * @param count number of images to add (assuming they are ordered in ascending order and there aren't any number skips)
     * @return the filled ArrayList
     */
    public static ArrayList<BufferedImage> addImages(ArrayList<BufferedImage> list, String path, String fileName, int count){
        for(int i=1; i<count+1; i++){
            BufferedImage img = null;
            try{
                img = (ImageIO.read(ImageUtil.class.getResource(path+fileName+i+".png")));
            }catch (IOException e){e.printStackTrace();}
            list.add(img);
        }
        return list;
    }

    /**
     * Fills the given Hashmap (with Animation keys and SpriteIterator associated objects). Uses the addImages method to fill the ArrayList that will be used to create the iterator.
     * @param map the HashMap that needs to be filled
     * @param animation the HashMap key
     * @param path (needed for the addImages method) the path to the images for the SpriteIterator
     * @param fileName (needed for the addImages method) the base name of the image files
     * @param count (needed for the addImages method) amount of image files
     */
    public static void setSpriteIterator(HashMap<Animation, SpriteIterator> map, Animation animation, String path, String fileName, int count, double speed){
        SpriteIterator iterator = new SpriteIterator();
        iterator.set(addImages(new ArrayList<>(), path, fileName, count));
        iterator.setSpeed(speed);
        map.put(animation, iterator);
    }

    /**
     * Fills the given map with font images.
     * @param map the HashMap that needs to be filled
     * @param path the path to the font images' location
     * @param fileName the base name of the image files
     * @return the filled HashMap
     */
    public static HashMap<Character, BufferedImage> setUpFont(HashMap<java.lang.Character, BufferedImage> map, String path, String fileName, boolean letters){
        //digits
        for(int i=0; i<10; i++){
            BufferedImage img = null;
            try{
                img = (ImageIO.read(ImageUtil.class.getResource(path+fileName+i+".png")));
            }catch (IOException e){e.printStackTrace();}
            map.put((char)(i+'0'), img);
        }
        //letters
        if(letters){
            for(int j=97; j<123; j++){
                char character = (char)j;
                BufferedImage image = null;
                try{
                    image = (ImageIO.read(ImageUtil.class.getResource(path+fileName+character+".png")));
                }catch (IOException e){e.printStackTrace();}
                map.put(character, image);
            }
            map.put('!', getImage(path+fileName+"excl.png"));
        }

        return map;
    }

    /**
     * Given a relative path to an image it returns the BufferedImage of it
     * @param path the path to an image
     * @return a single BufferedImage
     */
    public static BufferedImage getImage(String path) {
        BufferedImage image = null;
        try{
            image = ImageIO.read(ImageUtil.class.getResource(path));
            // TODO: rimuovere exception
            if (!path.endsWith(".png")) throw new RuntimeException();
        }catch(IOException | RuntimeException e){e.printStackTrace();}
        return image;
    }

    /**
     * Used to set the map for the avatars
     * @return an HashMap of String->BufferedImage of avatars
     */
    public static HashMap<String, BufferedImage> setUpAvatarHashMap(){
        HashMap<String, BufferedImage> avatarMap = new HashMap<>();
        avatarMap.put("bub", getImage("../../resources/avatars/bub.png"));
        avatarMap.put("bob", getImage("../../resources/avatars/bob.png"));
        avatarMap.put("cyanbub", getImage("../../resources/avatars/cyanbub.png"));
        avatarMap.put("jedibub", getImage("../../resources/avatars/jedibub.png"));
        avatarMap.put("digitalbub", getImage("../../resources/avatars/digitalbub.png"));
        avatarMap.put("oldbub", getImage("../../resources/avatars/oldbub.png"));
        avatarMap.put("yodabub", getImage("../../resources/avatars/yodabub.png"));
        avatarMap.put("redbub", getImage("../../resources/avatars/redbub.png"));
        avatarMap.put("purplebub", getImage("../../resources/avatars/purplebub.png"));
        avatarMap.put("hello-kitty", getImage("../../resources/avatars/hello-kitty.png"));
        return avatarMap;
    }

    /**
     * @return an HashMap of String->BufferedImage of blocks
     */
    public HashMap<BlockType, BufferedImage> getBlocks(){ return blocks;}
}
