package game.view.panels;

import game.view.ButtonFactory;
import game.view.ImageUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * Help Screen panel. Base on its type, it can display two kinds of information: either the game rules, or the game commands.
 */
public class HelpScreen extends JPanel {

    public enum HelpType {
        RULES, COMMANDS
    }

    private HelpType type;

    /**
     * HelpScreen constructor. Creates two types of help screens - the "rule" panels, and the "command" panels.
     * @param type discerns "rule" panels from "command" panels.
     * @param helpLayout Help panel organiser's cardLayout, useful to make buttons that switch between "rule" and "command" panels
     * @param helpManager Help panel organiser, useful to make buttons that switch between "rule" and "command" panels
     * @param generalLayout JBubbleBobble menu organiser's cardLayout, useful to make buttons that go back to the main menu
     * @param generalManager JBubbleBobble menu organiser, useful to make buttons that go back to the main menu
     */
    public HelpScreen(HelpType type, CardLayout helpLayout, JPanel helpManager, CardLayout generalLayout, JPanel generalManager){
        this.type = type;

        setLayout(new GridBagLayout());

        GridBagConstraints backGBC = setUpGridbagConstraints(0,0,0,0, 30, 13, 0, 0);
        add(ButtonFactory.createShowButton(new Dimension(80,37), "../../resources/panels/back.png", generalLayout, generalManager, "Menu"), backGBC);

        if(type == HelpType.RULES) {
            GridBagConstraints rulesGBC = setUpGridbagConstraints(1,1,1,1,335,0,0,93);
            add(ButtonFactory.createShowButton(new Dimension(226,48), "../../resources/panels/commands.png", helpLayout, helpManager, "commands"), rulesGBC);
        }
        else {
            GridBagConstraints commandsGBC = setUpGridbagConstraints(1,1,1,1,224,0,0,93);
            add(ButtonFactory.createShowButton(new Dimension(226,48), "../../resources/panels/gameRules.png", helpLayout, helpManager, "rules"), commandsGBC);

        }
    }

    /**
     * Helper method to set up GridbagConstraints quickly (and in an orderly manner).
     * @return the GridBagConstraints
     */
    public GridBagConstraints setUpGridbagConstraints(int x, int y, int wX, int wY, int inT, int inL, int inB, int inR){
        return new GridBagConstraints(){
            {
                gridx = x;
                gridy = y;
                weightx = wX;
                weighty = wY;

                insets = new Insets(inT, inL, inB, inR);
            }
        };
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        BufferedImage background = ImageUtil.getImage( type == HelpType.RULES ? "../../resources/panels/rulePanel.png" : "../../resources/panels/commandPanel.png");
        g.drawImage(background, 0,0, null);
    }

}
