package game.view.panels;

import game.controller.JBubbleBobble;
import game.model.GameStats;
import game.model.Model;
import game.view.ButtonFactory;
import game.view.FontUtil;
import game.view.Frame;
import game.view.ImageUtil;

import javax.swing.*;
import javax.swing.Timer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Main menu panel. Allows the player to change their username and avatar, and to select
 */
public class MainMenu extends JPanel {

    private CardLayout cLayout;
    private JPanel organiser;
    private GamePanel gamePanel;
    private JTextField playerInput;
    private JLabel userName;
    private String newPlayerName;
    private String playerName;
    private game.view.Frame frame;
    private ArrayList<String> avatarList;
    private HashMap<String, BufferedImage> avatarMap;
    private String avatar;
    private Font pixelFont;

    private boolean userUnavailable;
    private boolean userTooLong;

    /**
     * MainMenu constructor. Sets some options, creates the first components and calls its helper methods.
     * @param cLayout the CardLayout that handles the showing of the panels
     * @param organiser the panel with the CardLayout layout
     * @param gamePanel the GamePanel (needed to start the game)
     * @param frame the Frame, needed to change the avatar and the username
     */
    public MainMenu(CardLayout cLayout, JPanel organiser, GamePanel gamePanel, Frame frame){
        this.cLayout = cLayout;
        this.organiser = organiser;
        this.gamePanel = gamePanel;
        this.frame = frame;
        this.avatar = frame.getAvatar();
        this.avatarMap = ImageUtil.setUpAvatarHashMap();
        this.avatarList = new ArrayList();
        avatarList.addAll(avatarMap.keySet());
        avatarList.sort(null);

        pixelFont = FontUtil.getFont("src/resources/16bfZX.ttf");
        setLayout(new GridBagLayout());

        userName = new JLabel("userName");
        userName.setForeground(new Color(204, 204, 232));
        if(pixelFont != null) userName.setFont(pixelFont.deriveFont(30f));

        GridBagConstraints gb = new GridBagConstraints();
        gb.insets = new Insets(25, 0, 0, 0); // 10 pixels from the top
        gb.gridx =1;
        gb.gridy = 0;
        gb.weighty = 0;// doesn't get the extra top space
        add(userName, gb);

        gb.insets = new Insets(68, 0, 0, 0);
        gb.gridy = 1;
        gb.gridx = 1;

        add(setUpSideButtons(), gb);
        addButtonPanel(this);
    }

    /**
     * Helper method. Creates a panel composed of the input handling (name change) and the main menu buttons.
     * @param panel the panel to add it to.
     */
    public void addButtonPanel(JPanel panel){
        JPanel buttonPanel = new JPanel(){
            {
                add(createInputPanel());

                setPreferredSize(new Dimension(412, 260));
                setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));//vertical
                setBackground(Color.BLACK);

                add(Box.createRigidArea(new Dimension(0, 20)));
                add(ButtonFactory.createActionButton(new Dimension(384,50),
                        "../../resources/panels/startGame.png",e-> startGame()));

                add(Box.createRigidArea(new Dimension(0, 20)));
                add(ButtonFactory.createShowButton(new Dimension(384,50),
                        "../../resources/panels/leaderBoard.png", cLayout, organiser,"Leaderboard"));

                add(Box.createRigidArea(new Dimension(0, 20)));
                add(ButtonFactory.createShowButton(new Dimension(384,50),
                        "../../resources/panels/help.png", cLayout, organiser,"Help"));
            }
        };

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.weighty = 1; //gets the extra top space

        gbc.insets = new Insets(0, 0, 52, 0);
        panel.add(buttonPanel, gbc);
    }

    /**
     * Helper method. Creates an "input panel", made up of a JTextField to write a username,
     * and a tick button to set it. Handles the fact that the name can also be set by clicking "Enter".
     * @return the input JPanel
     */
    public JPanel createInputPanel(){
        return new JPanel(){
            {
                setPreferredSize(new Dimension(226, 40));
                setBackground(Color.BLACK);

                playerInput = new JTextField(){
                    {
                        setPreferredSize(new Dimension(186, 40));
                        setFont(pixelFont.deriveFont(34f));
                        setHorizontalAlignment(JTextField.CENTER);
                        setBorder(BorderFactory.createEmptyBorder());
                        setBackground(new Color(36, 33, 58));
                        setForeground(new Color(188, 188, 211));
                        setCaretColor(new Color(188, 188, 211));
                    }
                };
                add(playerInput);

                AbstractAction setPlayerName = new AbstractAction() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        newPlayerName = playerInput.getText();
                        if(!newPlayerName.isEmpty()) {
                            if(changeNameInStats(newPlayerName, playerName)) {
                                userName.setText(newPlayerName);
                                changePlayerName(newPlayerName);
                            }
                        }
                    }
                };

                JButton setNameButton = ButtonFactory.createActionButton(new Dimension(40,40),
                        "../../resources/panels/tick.png", setPlayerName);
                setNameButton.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
                        .put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER,0), "Enter_pressed");
                setNameButton.getActionMap().put("Enter_pressed", setPlayerName);
                add(setNameButton);
            }
        };
    }

    /**
     * Sets the player's username.
     * @param playerName the new name
     */
    public void setPlayerName(String playerName){
        this.playerName = playerName;
        userName.setText(playerName);
    }

    /**
     * Used to change a player's username (here and in the Frame).
     * @param playerName the new name
     */
    public void changePlayerName(String playerName){
        setPlayerName(playerName);
        frame.setUser(playerName);
    }

    /**
     * Used to change a player's avatar (here, in the stats and in the frame).
     * @param avatar the new avatar
     */
    public void changeAvatar(String avatar){
        this.avatar = avatar;
        this.repaint();
        if (changeAvatarInStats(avatar)) frame.changeAvatar(playerName, avatar);
    }

    /**
     * Used to change a player's name in the serialized stats.
     * The name will be rejected if it's longer than 10 characters, or if
     * it's not available.
     * @param newPlayerName the new name
     * @param oldPlayerName the old name
     * @return true if the name has been changed, false otherwise
     */
    public boolean changeNameInStats(String newPlayerName, String oldPlayerName){
        if(newPlayerName.equals(oldPlayerName)) return false;

        if(newPlayerName.length() > 10){
            userTooLong = true;
            showError();
            return false;
        }

        ArrayList<GameStats> stats = Model.getInstance().deserializeGameStats();
        Set<String> unAvailableNames = stats.stream().map(GameStats::getPlayername).collect(Collectors.toSet());

        if(unAvailableNames.contains(newPlayerName)){
            userUnavailable = true;
            showError();
            return false;
        }

        for(GameStats stat : stats){
            if(stat.getPlayername().equals(oldPlayerName)){
                stat.setPlayerName(newPlayerName);
            }
        }
        Model.getInstance().serializeGameStats(stats);
        return true;
    }

    /**
     * Used to change a player's avatar in the serialized stats.
     * The name will be rejected if it's longer than 10 characters, or if
     * it's not available.
     * @param newAvatar the new avatar
     * @return whether there's been a change
     */
    public boolean changeAvatarInStats(String newAvatar){
        ArrayList<GameStats> stats = Model.getInstance().deserializeGameStats();
        boolean changed = false;
        for(GameStats stat : stats){
            if(stat.getPlayername().equals(playerName)){
                stat.setAvatar(newAvatar);
                changed = true;
            }
        }
        Model.getInstance().serializeGameStats(stats);
        return changed;
    }

    /**
     * Helper function that sets up a transparent JPanel containing the arrow
     * buttons to change the player's avatar.
     * @return the panel
     */
    public JPanel setUpSideButtons(){
        return new JPanel(){
            {
                setLayout(new GridBagLayout());
                setOpaque(false);

                GridBagConstraints g = new GridBagConstraints();

                g.gridy = 0;
                g.gridx = 0;
                g.insets = new Insets(0,90,0,55);

                //left button
                add(ButtonFactory.createActionButton(new Dimension(34,45),
                        "../../resources/panels/lButton2.png", e -> changeUserAction("l")), g);

                g.gridy = 0;
                g.gridx = 1;
                g.insets = new Insets(0,140,0,80);

                //right button
                add(ButtonFactory.createActionButton(new Dimension(34,45),
                        "../../resources/panels/rButton2.png", e -> changeUserAction("r")), g);
            }
        };

    }

    /**
     * Action for the changing of the avatar.
     * Used as the ActionPerformed for the buttons designed for that function.
     * @param direction whether the new avatar precedes or follows the current avatar in the avatarList ArrayList.
     */
    public void changeUserAction(String direction){
        String oldAvatar = avatar;
        int avIn = avatarList.indexOf(oldAvatar);

        String newAvatar;
        if(direction.equals("l")) newAvatar = avIn == 0 ? avatarList.getLast() : avatarList.get(avIn-1);
        else newAvatar = avIn == avatarList.size() -1 ? avatarList.getFirst() : avatarList.get(avIn+1);

        changeAvatar(newAvatar);
    }

    /**
     * Action associated to the "Start Game" button. Starts the Game loop, and requests focus
     * for the gamePanel.
     */
    public void startGame(){
        cLayout.show(organiser, "Game");
        gamePanel.requestFocusInWindow();
        JBubbleBobble.startGameLoop();
    }

    /**
     * Handles the showing of the error text for the username selection.
     * Creates a new timer with a 600ms delay, after which the booleans will be
     * set to false and the images will stop showing.
     */
    private void showError(){
        Timer hideErrorTimer = new Timer(600, e -> {
            userTooLong = false;
            userUnavailable = false;
            repaint();
        });
        hideErrorTimer.setRepeats(false);
        hideErrorTimer.start();
        repaint();
    }

    @Override
    public void paintComponent(Graphics g) {
        BufferedImage background = ImageUtil.getImage("../../resources/panels/mainMenu.png");
        g.drawImage(background, 0,0, null);

        g.drawImage(avatarMap.get(avatar), 305,60, null);
        drawErrors(g);
    }

    /**
     * Handles the drawing of the errors related to the username selection.
     * If the booleans corresponding to the errors are true, the images are shown.
     */
    public void drawErrors(Graphics g){
        BufferedImage unavailable = ImageUtil.getImage("../../resources/panels/userUnavailable.png");
        BufferedImage tooLong = ImageUtil.getImage("../../resources/panels/userLong.png");

        if (userUnavailable) {
            g.drawImage(unavailable, 224, 199, 300, 140, null);
        }
        if (userTooLong) {
            g.drawImage(tooLong, 213, 199, 300, 140, null);
        }
    }


}



