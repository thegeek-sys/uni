package game.view.panels;
import game.model.*;
import game.model.behaviours.Shooting;
import game.model.entities.*;
import game.model.entities.bubbles.*;
import game.model.entities.bubbles.special_bubbles.*;
import game.model.entities.opps.Enemy;
import game.view.ImageUtil;
import game.view.SpriteIterator;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.lang.Character;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Panel that displays the game.
 */
public class GamePanel extends JPanel {

    private HashMap<Class, HashMap<Animation, SpriteIterator>> imageDealer;
    private HashMap<Long, HashMap<Animation, SpriteIterator>> bubbleImages;
    private int hurryUpX, hurryUpY;
    private int flash;

    /**
     * GamePanel constructor. Sets some options and creates a new imageDealer through the ImageUtil class
     */
    public GamePanel() {
        setPreferredSize(new Dimension (Model.SCREEN_WIDTH, Model.GAME_SCREEN_HEIGHT));
        setBackground(Color.black);
        setFocusable(true);
        imageDealer = new HashMap<>();
        ImageUtil.dealImages(imageDealer);
        bubbleImages = new HashMap<>();
        hurryUpX = Model.TILE_SIZE * 11;
        hurryUpY = Model.GAME_LATERAL_SPEED;
    }

    @Override
    public void paintComponent(Graphics g) {
        Model m = Model.getInstance();
        Toolkit.getDefaultToolkit().sync();
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        drawLevel(g2);
        drawBubbles(g2, m);
        drawEnemies(g2, m);
        drawItems(g2, m);
        drawInfo(g2, m);
        drawElements(g2, m);
        drawStars(g2, m);
        drawTrains(g2, m);
        drawBub(g2, m);
        g2.dispose();
    }

    /**
     * Displays the bubbles
     * @param g2 Used to render the images
     * @param m Model instance
     */
    public void drawBubbles(Graphics2D g2, Model m){
        for(BBubble bubble : m.getLevel().getBubbles()){
            // TODO PATCHING
            if (bubble == null) continue;
            if (!bubbleImages.keySet().contains(bubble.getId()) || !bubbleImages.get(bubble.getId()).containsKey(bubble.getAnimation())) {
                //if the id isn't already in the hashmap,
                // a new hashmap is created with the "spawning" animation as default (the BBubble is spawning)
                bubbleImages.put(bubble.getId(), new HashMap<>() {
                    {
                        put(bubble.getAnimation(), imageDealer.get(BBubble.class).get(bubble.getAnimation()).copy());
                    }
                });
            }
            BufferedImage bImage = bubbleImages.get(bubble.getId()).get(bubble.getAnimation()).next();
            g2.drawImage(bImage, bubble.getX(), bubble.getY(), Model.TILE_SIZE*2, Model.TILE_SIZE*2, null);
            if(bubble.getAnimation() == Animation.POPPED && bubble.getState() == State.POPPED) bubbleImages.remove(bubble.getId());
        }

        for(int i = 0; i < m.getLevel().getSpecialBubbles().size(); i++){
            SpecialBubble specialBubble = m.getLevel().getSpecialBubbles().get(i);
            if(specialBubble.getY() > 0 && specialBubble.getY() <= Model.GAME_SCREEN_HEIGHT) {
                BufferedImage bImage;
                if (specialBubble instanceof LaudeBubble)
                    bImage = ImageUtil.getImage("../../resources/bubbles/extend/"+((LaudeBubble)specialBubble).getLetter().toString().toLowerCase()+".png");
                else bImage = imageDealer.get(specialBubble.getClass()).get(specialBubble.getAnimation()).next();
                g2.drawImage(bImage, specialBubble.getX(), specialBubble.getY(), Model.TILE_SIZE*2, Model.TILE_SIZE *2, null);
            }
        }
    }

    /**
     * Displays the enemies
     * @param g2 Used to render the images
     * @param m Model instance
     */
    public void drawEnemies(Graphics2D g2, Model m){
        for(int i = 0; i < m.getLevel().getEnemies().size(); i++){
            Enemy e = m.getLevel().getEnemies().get(i);
            if(e instanceof Shooting<?> && ((Shooting<?>)e).getBubble() != null){
                Bubble bubble = ((Shooting<?>)e).getBubble();
                if (bubble.getAnimation() == Animation.FLOATING_LEFT)
                    g2.drawImage(ImageUtil.getImage("../../resources/sprites/hidegons/blast left/left6.png"), bubble.getX(), bubble.getY(), Model.TILE_SIZE*2, Model.TILE_SIZE*2, null);
                else if (bubble.getAnimation() == Animation.FLOATING_RIGHT)
                    g2.drawImage(ImageUtil.getImage("../../resources/sprites/hidegons/blast right/right6.png"),bubble.getX(), bubble.getY(), Model.TILE_SIZE*2, Model.TILE_SIZE*2, null);
                else g2.drawImage(imageDealer.get(bubble.getClass()).get(bubble.getAnimation()).next(), bubble.getX(), bubble.getY(), Model.TILE_SIZE*2, Model.TILE_SIZE*2, null);
            }
            g2.drawImage(imageDealer.get(e.getClass()).get(
                    e.getAnimation()).next(), e.getX(), e.getY(), editor.model.Model.TILE_SIZE * 2, editor.model.Model.TILE_SIZE * 2, null
            );
        }
    }

    /**
     * Displays the level
     * @param g2 Used to render the images
     */
    public void drawLevel(Graphics g2){
        for(int i = 0; i < Model.MAX_SCREEN_ROW; i++){
            for(int j = 0; j < Model.MAX_SCREEN_COL; j++){
                g2.drawImage(ImageUtil.getInstance().getBlocks().get(BlockType.getBlock(Model.getInstance().getLevel().getLevelMap().get(i).get(j))),
                        j * Model.TILE_SIZE, i * Model.TILE_SIZE , Model.TILE_SIZE* Model.SCALE, Model.TILE_SIZE* Model.SCALE, null);
            }
        }
        if(Model.getInstance().getLevel()!= null && Model.getInstance().getLevel().getLevelNumber() == 25) {
            BufferedImage img = ImageUtil.getImage("../../resources/sprites/faralli.png");
            g2.drawImage(img, 0, 264, 768, 360, null);
        }
    }

    /**
     * Displays Bubblun
     * @param g2 Used to render the images
     * @param m Model instance
     */
    public void drawBub(Graphics2D g2, Model m){
        Bubblun bub = m.getPlayer();

        Animation animation = bub.getAnimation();

        BufferedImage image = switch (animation) {
            case Animation.STILL_LEFT -> ImageUtil.getImage("../../resources/sprites/bubblun/moving/moving_left7.png");
            case Animation.STILL_RIGHT -> ImageUtil.getImage("../../resources/sprites/bubblun/moving/moving_right7.png");
            default -> imageDealer.get(Bubblun.class).get(animation).next();
        };

        if (bub.getState() == State.FLOATING) {
            g2.drawImage(image, bub.getX() - Model.TILE_SIZE, bub.getY() - Model.TILE_SIZE, Model.TILE_SIZE * 4, Model.TILE_SIZE * 4, null);
        }
        else if(bub.getHealthState() == State.INVULNERABLE) {
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
            if(flash++ % 2 == 0){
                g2.drawImage(image, bub.getX(), bub.getY(), Model.TILE_SIZE*2, Model.TILE_SIZE*2, null);
            }
        } else {
            g2.drawImage(image, bub.getX(), bub.getY(), Model.TILE_SIZE * 2, Model.TILE_SIZE * 2, null);

        }
    }

    /**
     * Displays all the infos about the player's current health, the extend bubbles, when a level is ready, and the level number
     * @param g2 Used to render the images
     * @param m Model instance
     */
    public void drawInfo(Graphics2D g2, Model m){
        BufferedImage image = ImageUtil.getImage("../../resources/sprites/bubblun/life.png");
        for(int i=0; i<m.getPlayer().getHealth(); i++) {
            g2.drawImage(image, (i * Model.TILE_SIZE), Model.GAME_SCREEN_HEIGHT - Model.TILE_SIZE, Model.TILE_SIZE, Model.TILE_SIZE, null);
        }

        for(int j = 0; j<6; j++){
            if(Model.getInstance().getPlayerStats().getLaudeBubbles()[j]){
                BufferedImage img = ImageUtil.getImage("../../resources/bubbles/extend/big/" + LaudeType.getLetter(j).toString().toLowerCase() + ".png");
                g2.drawImage(img,  0,Model.TILE_SIZE * 12 +(j * Model.TILE_SIZE * 2), Model.TILE_SIZE*2, Model.TILE_SIZE*2, null);
            }
        }

        BufferedImage img = ImageUtil.getImage("../../resources/sprites/levels/" + m.getLevel().getLevelNumber() + ".png");
        g2.drawImage(img, 0, 0, Model.TILE_SIZE*2, Model.TILE_SIZE*2, null);
        
        if(m.getLevel().showRoundInfo()){
            BufferedImage roundImg = ImageUtil.getImage("../../resources/sprites/levels/round" + m.getLevel().getLevelNumber() + ".png");
            g2.drawImage(roundImg, Model.TILE_SIZE*12,Model.TILE_SIZE * 11, Model.TILE_SIZE *8, Model.TILE_SIZE, null);
            BufferedImage readyImg = ImageUtil.getImage("../../resources/sprites/levels/ready.png");
            g2.drawImage(readyImg, Model.TILE_SIZE*12, Model.TILE_SIZE * 12, Model.TILE_SIZE * 7, Model.TILE_SIZE, null);
        }

        long hurryUpTimer = m.getLevel().getHurryUpTimer();
        if(hurryUpTimer > 0 && hurryUpTimer < 4_000_000_000L){
            if(hurryUpTimer < 1_000_000_000L || hurryUpTimer > 3_000_000_000L) hurryUpY -= Model.GAME_GRAVITY*5;
            g2.drawImage(imageDealer.get(Level.class).get(Animation.HURRY_UP).next(), hurryUpX, hurryUpY, Model.TILE_SIZE * 10, Model.TILE_SIZE, null);
        }else hurryUpY = Model.GAME_SCREEN_HEIGHT;

    }

    /**
     * Displays the items
     * @param g2 Used to render the images
     * @param m Model instance
     */
    public void drawItems(Graphics2D g2, Model m){
        ArrayList<Item> items = m.getLevel().getItems();
        for(int i=0; i<items.size(); i++){
            Item item = items.get(i);
            if(item.getType() != null && item.getState() != State.DEAD) {
                g2.drawImage(ImageUtil.getImage("../../resources/sprites/items/"+item.getType().toString().toLowerCase()+".png"), item.getX(), item.getY(), (int)(Model.TILE_SIZE*1.5), (int)(Model.TILE_SIZE*1.5), null);
            } else{
                BufferedImage img;
                if(item.isBig()){
                    img = ImageUtil.getImage("../../resources/sprites/points/" + m.getLevel().getHitPoints() + "b.png");
                } else img = ImageUtil.getImage("../../resources/sprites/points/"+Math.abs(item.getType().getValue())+".png");
                g2.drawImage(img, item.getX(), item.getY(), img.getWidth()*3, img.getHeight()*3, null);
            }
        }

        if(m.getLevel().getLevelNumber() == 25){

        }
    }

    /**
     * Displays the elements that spawn when the player hits a WaterBubble, FireBubble or Lightning Bubble
     * @param g2 Used to render the images
     * @param m Model instance
     */
    public void drawElements(Graphics2D g2, Model m){
        for (Element element : m.getLevel().getElements()){
            switch(element.getClass().getSimpleName()){

                case "WaterFlow" -> {
                    ArrayList<WaterFlow.WaterBlock> flow = element.getContent();
                    for(int i=0; i<flow.size(); i++){
                        WaterFlow.WaterBlock waterBlock = flow.get(i);
                        BufferedImage bImage = ImageUtil.getImage("../../resources/sprites/misc/water/" + waterBlock.getAnimation().toString().toLowerCase().substring(6) + ".png");
                        g2.drawImage(bImage, waterBlock.getX(), waterBlock.getY(), Model.TILE_SIZE, Model.TILE_SIZE, null);
                    }

                }

                case "Blaze" -> {
                    ArrayList<Blaze.FireBlock> flow = element.getContent();
                    for(int i=0; i<flow.size(); i++){
                        Blaze.FireBlock fireBlock = flow.get(i);
                        BufferedImage bImage = imageDealer.get(fireBlock.getClass()).get(fireBlock.getAnimation()).next();
                        g2.drawImage(bImage, fireBlock.getX(), fireBlock.getY(), Model.TILE_SIZE, Model.TILE_SIZE, null);
                    }
                }

                case "Storm" ->{
                    ArrayList<Storm.Lightning> storm = element.getContent();
                    Storm.Lightning lightning = storm.getFirst();
                    BufferedImage bImage = imageDealer.get(lightning.getClass()).get(lightning.getAnimation()).next();
                    g2.drawImage(bImage, lightning.getX(), lightning.getY(), (int)(Model.TILE_SIZE*1.5), (int)(Model.TILE_SIZE*1.5), null);
                }
            }

        }
    }

    /**
     * Displays the stars that spawn when the player gets the silver ring power-up
     * @param g2 Used to render the images
     * @param m Model instance
     */
    public void drawStars(Graphics2D g2, Model m){
        for(int i = 0; i < m.getLevel().getStars().size(); i++){
            Star star = m.getLevel().getStars().get(i);
            g2.drawImage(imageDealer.get(Star.class).get(star.getAnimation()).next(), star.getX(), star.getY(), (int)(Model.TILE_SIZE*1.5), (int)(Model.TILE_SIZE*1.5), null);
        }
    }

    /**
     * Displays trains in the final level
     * @param g2 Used to render the images
     * @param m Model instance
     */
    public void drawTrains(Graphics2D g2, Model m){
        HashMap<Character, BufferedImage> greenFont = ImageUtil.setUpFont(new HashMap<>(),"../../resources/scorepanel/green_font/", "green_font_", false);
        HashMap<Character, BufferedImage> blueFont = ImageUtil.setUpFont(new HashMap<>(),"../../resources/scorepanel/blue_font/", "blue_font_", false);

        if(m.getLevel() != null && m.getLevel().getLevelNumber() == 25){
            Character firstNumber = m.getLevel().getTrainsHit() < 10 ? '0' : String.valueOf(m.getLevel().getTrainsHit()).charAt(0);
            Character secondNumber = String.valueOf(m.getLevel().getTrainsHit()).charAt(m.getLevel().getTrainsHit()<10 ? 0 : 1);

            long entireTime = 150_000_000_000L-(System.nanoTime()-m.getLevel().getLevelTime());
            String time = String.format("%012d", entireTime);

            g2.drawImage(ImageUtil.getImage("../../resources/sprites/misc/score board.png"), Model.TILE_SIZE*2, 264,128,32, null);
            g2.drawImage(greenFont.get(firstNumber), Model.TILE_SIZE*2, 264+3*2, 9*2, 9*2, null);
            g2.drawImage(greenFont.get(secondNumber), Model.TILE_SIZE*2+9*2, 264+3*2, 9*2, 9*2, null);
            g2.drawImage(blueFont.get(time.charAt(0)), Model.TILE_SIZE*2+70, 264+3*2, 9*2, 9*2, null);
            g2.drawImage(blueFont.get(time.charAt(1)), Model.TILE_SIZE*2+70+9*2, 264+3*2, 9*2, 9*2, null);
            g2.drawImage(blueFont.get(time.charAt(2)), Model.TILE_SIZE*2+70+9*4, 264+3*2, 9*2, 9*2, null);

        }
        for(int i = 0; i < m.getLevel().getTrains().size(); i++){
            Train train = m.getLevel().getTrains().get(i);
            BufferedImage trainImage = ImageUtil.getImage("../../resources/sprites/misc/metro/" + train.getLine().toString().toLowerCase()+".png");
            g2.drawImage(trainImage, train.getX(), train.getY(), 18, 64, null);
        }
    }
}
