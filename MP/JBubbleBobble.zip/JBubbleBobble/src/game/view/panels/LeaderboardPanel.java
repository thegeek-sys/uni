package game.view.panels;

import game.model.GameStats;
import game.model.Model;
import game.view.ButtonFactory;
import game.view.FontUtil;
import game.view.ImageUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.stream.Collectors;

/**
 * Panel containg two leaderboards: a global and a personal one for the player.
 */
public class LeaderboardPanel extends JPanel{

    private ArrayList<GameStats> stats;
    private ArrayList<GameStats> personalStats;
    private Font pixelFont;
    private JSplitPane twoBoards;
    private boolean end;
    /**
     * LeaderboardPanel constructor. Sets some options, calls helper methods to add the back button and the Leaderboards.
     * @param cLayout the organiser's card layout, to set up the back button
     * @param organiser the organiser panel (on which to show the cardLayout panels), to set up the back button
     */
    public LeaderboardPanel(CardLayout cLayout, JPanel organiser){
        getStats();
        this.end = false;

        setPreferredSize(new Dimension(Model.SCREEN_WIDTH, Model.SCREEN_HEIGHT));
        setLayout(new GridBagLayout());
        this.pixelFont = FontUtil.getFont("src/resources/16bfZX.ttf").deriveFont(32F);

        addBackButton(cLayout, organiser);
    }

    /**
     * LeaderboardPanel constructor for the final leaderboard. Sets some options, calls helper methods to add the exit button and the Leaderboards.
     * @param userName the current player's username
     */
    public LeaderboardPanel(String userName){
        this.end = true;
        setPreferredSize(new Dimension(Model.SCREEN_WIDTH, Model.SCREEN_HEIGHT));
        setLayout(new GridBagLayout());
        this.pixelFont = FontUtil.getFont("src/resources/16bfZX.ttf").deriveFont(32F);
        getStats();
        this.personalStats = getPersonalLeaderboard(userName);
        addLeaderboards();
        addExitButton();
    }

    /**
     * Sets the current player's username. Recreates the Leaderboards based on the new name.
     * @param playerName the current player's username
     */
    public void setPlayerName(String playerName) {
        getStats();
        this.personalStats = getPersonalLeaderboard(playerName);
        addLeaderboards();
    }

    /**
     * Helper method to add the two Leaderboards to the panel.
     * Creates the JSplitPane that will contain them, and calls the "setUpScrollPane" helper
     * method with two new Leaderboards.
     */
    public void addLeaderboards(){
        twoBoards = new JSplitPane(){
            {
                setBorder(BorderFactory.createEmptyBorder());
                setOrientation(JSplitPane.VERTICAL_SPLIT);
                setPreferredSize(new Dimension(525, 484));
                setDividerLocation(242);
                setDividerSize(2);

                setTopComponent(setUpScrollPane(new Leaderboard(stats, pixelFont, true)));

                setBottomComponent(setUpScrollPane(new Leaderboard(personalStats, pixelFont, false)));
            }
        };

        GridBagConstraints gb = new GridBagConstraints();
        gb.gridx = 1;
        gb.gridy = 1;

        gb.weighty = 1;
        gb.weightx = 1;

        gb.insets = end ? new Insets(0, 0, 85, 113) : new Insets(0, 0, 66, 92);
        add(twoBoards, gb);
        repaint();
    }

    /**
     * Helper method to simplify the creation of JScrollPanes for the leaderboards.
     * Sets the necessary options.
     * @return the JScrollPane
     */
    public JScrollPane setUpScrollPane(Leaderboard leaderboard){
        return new JScrollPane(leaderboard){
            {
                setBorder(BorderFactory.createEmptyBorder());
                getVerticalScrollBar().setBackground(Color.BLACK);
                setVerticalScrollBarPolicy(VERTICAL_SCROLLBAR_ALWAYS);
                getHorizontalScrollBar().setBackground(Color.BLACK);
                setHorizontalScrollBarPolicy(HORIZONTAL_SCROLLBAR_NEVER);
            }
        };
    }

    /**
     * Helper method that sets up the "back button", to go back to the main menu.
     * @param cLayout the organiser's card layout, to show the main
     * @param manager the organiser panel, to show the main menu on
     */
    public void addBackButton(CardLayout cLayout, JPanel manager){
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;

        gbc.weighty = 0;
        gbc.weightx = 0;

        gbc.insets = new Insets(30, 13, 0, 0);

        add(ButtonFactory.createShowButton(new Dimension(80,37), "../../resources/panels/greenBack.png",cLayout, manager,"Menu"), gbc);
    }

    /**
     * Helper method that sets up the "exit button", to quit the game.
     */
    public void addExitButton(){
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;

        gbc.weighty = 0;
        gbc.weightx = 0;

        gbc.insets = new Insets(25, 3, 0, 0);

        add(ButtonFactory.createActionButton(new Dimension(120,56),"../../resources/panels/EXIT.png", e -> System.exit(0)), gbc);
    }

    /**
     * Method that filters through the global leaderboard and returns a new ArrayList containing the
     * games the current player has played.
     * @param userName the player username
     * @return a player's personal "leaderboard"
     */
    public ArrayList<GameStats> getPersonalLeaderboard(String userName){
        return stats.stream().filter(x -> x.getPlayername().equals(userName)).collect(Collectors.toCollection(ArrayList::new));
    }

    /**
     * Getter method for the stats. Calls the deserialization of the stats, done in Model.
     */
    public void getStats(){
        ArrayList<GameStats> gStats = Model.getInstance().deserializeGameStats();
        gStats.sort(null);
        this.stats = gStats;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        BufferedImage background = ImageUtil.getImage("../../resources/panels/leaderboardPanel.png");
        g.drawImage(background,0,0,null);
    }
}
