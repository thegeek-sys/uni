package game.view.panels;

import game.model.GameStats;
import game.view.ImageUtil;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

/**
 * Leaderboard panel. Based on the "global" field, it can display two kinds of information:
 * the global leaderboard, or the current player's.
 */
public class Leaderboard extends JPanel {
    private ArrayList<GameStats> stats;
    private Font pixelFont;
    private boolean global;

    /**
     * Leaderboard constructor. Sets some options and calls its helper methods.
     * @param stats complete leaderboard.
     * @param pixelFont custom font.
     * @param global a boolean that discerns "global" leaderboards from player-specific ones
     */
    public Leaderboard(ArrayList<GameStats> stats, Font pixelFont, boolean global){
        this.stats = stats;
        this.pixelFont = pixelFont;
        this.global = global;

        setLayout(new GridBagLayout());
        setSize(new Dimension(525, stats.size() * 50));

        setBackground(Color.BLACK);
        setBorder(BorderFactory.createEmptyBorder());
        setUpLeaderBoard();
    }

    /**
     * Helper method that starts the initialization of the Leaderboard.
     * It sets the first row (whether it's an actual row or just a "your games" label) and,
     * using the helper method "addRow", the other ones.
     */
    public void setUpLeaderBoard(){
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;

        if(!global) {
            gbc.insets = new Insets(10, 0,0,10);
            gbc.weighty = 0;
            gbc.gridx = 1;
            add(setUpLabel("you:", new Color(144, 148, 187)),gbc);
        }
        else addFirstRow(gbc);

        for(int i=0; i<stats.size(); i++){
            addRow(stats.get(i), i+1);
        }
    }

    /**
     * Helper method. Called for every row. Adds the values that are in each row.
     * (avatar, (optional)username, score, win, time)
     * @param stat the current GameStats ArrayList to analyse
     * @param row the current row (used for the GridBagLayout)
     */
    public void addRow(GameStats stat, int row){
        GridBagConstraints gb = new GridBagConstraints();

        gb.gridx = 0;
        gb.gridy = row;
        gb.insets = new Insets(10, 0,0,10);

        add(new JLabel(new ImageIcon(ImageUtil.getImage("../../resources/avatars/" + stat.getAvatar() + ".png")
                .getScaledInstance(32, 32, Image.SCALE_SMOOTH))), gb);

        if(global){
            gb.gridx++;
            add(setUpLabel(stat.getPlayername(),Color.WHITE), gb);
        }

        gb.gridx++;
        add(setUpLabel(String.valueOf(stat.getScore()), Color.WHITE), gb);

        gb.gridx++;
        boolean win = stat.getWin();
        add(setUpLabel(win ? "won" : "lost", win ? Color.GREEN : Color.RED), gb);

        gb.gridx++;
        add(setUpLabel(stat.getTimeTaken(),Color.WHITE),gb);
    }

    /**
     * Method to simplify the creation of labels.
     * Sets the label's font to "pixelFont" and uses the parameters to set the rest.
     * @param text the JLabel text
     * @param color the foreground color (text color)
     * @return the JLabel
     */
    public JLabel setUpLabel(String text, Color color){
        return new JLabel(text){
            {
                setFont(pixelFont);
                setForeground(color);
            }
        };
    }
    /**
     * Helper method to add the first row of labels (if it's a global leaderboard).
     * Adds "player", "score", "win", "time" labels above the rows that will contain those values.
     * @param gbc Leaderboard GridBagLayout, to add the labels in the correct row and columns
     */
    public void addFirstRow(GridBagConstraints gbc){
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10,0,10);
        gbc.gridx++;
        add(setUpLabel("name:", new Color(144, 148, 187)), gbc);
        gbc.gridx++;
        add(setUpLabel("score:", new Color(144, 148, 187)), gbc);
        gbc.gridx++;
        add(setUpLabel("win:", new Color(144, 148, 187)), gbc);
        gbc.gridx++;
        add(setUpLabel("time:", new Color(144, 148, 187)), gbc);
    }

}
