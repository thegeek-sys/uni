package game.view.panels;

import game.view.ImageUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

/**
 * Used for the starting and ending screens. Shows a background and allows the user
 * to move on to a different screen by clicking Enter.
 */
public class MainScreen extends JPanel {
    private final String path;

    /**
     * MainScreen constructor. Sets the path to its background and the panel shown when enter is clicked.
     */
    public MainScreen(CardLayout cLayout, JPanel organiser, String constraints, String path){
        this.path = path;
        AbstractAction start = new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cLayout.show(organiser, constraints);
            }
        };
        getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER,0), "Enter_pressed");
        getActionMap().put("Enter_pressed", start);
    }


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        BufferedImage background = ImageUtil.getImage(path);
        g.drawImage(background, 0,0, null);
    }
}
