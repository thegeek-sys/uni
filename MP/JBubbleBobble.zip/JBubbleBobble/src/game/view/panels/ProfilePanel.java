package game.view.panels;

import game.model.GameStats;
import game.model.Model;
import game.view.ButtonFactory;
import game.view.FontUtil;
import game.view.Frame;
import game.view.ImageUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * "Login" screen. Allows the player to choose between the available profiles.
 */
public class ProfilePanel extends JPanel {
    private Map<String, String> playerInfo;
    private Font pixelFont;
    private String userName;
    private game.view.Frame frame;
    private CardLayout cLayout;
    private JPanel organiser;

    public ProfilePanel(Frame frame, CardLayout cLayout, JPanel organiser){
        ArrayList<GameStats> stats = Model.getInstance().deserializeGameStats();
        this.playerInfo = getInfo(stats);
        this.pixelFont = FontUtil.getFont("src/resources/16bfZX.ttf");
        this.frame = frame;
        this.cLayout = cLayout;
        this.organiser = organiser;

        setLayout(new GridBagLayout());
        setBackground(Color.BLACK);
        setPreferredSize(new Dimension(Model.SCREEN_WIDTH, Model.SCREEN_HEIGHT));
        setUpProfileGrid();

    }

    /**
     * Sets up the grid with the different profiles.
     */
    public void setUpProfileGrid(){
        JPanel profileGrid = new JPanel();
        profileGrid.setLayout(new BoxLayout(profileGrid,BoxLayout.X_AXIS));
        profileGrid.setBackground(Color.BLACK);

        for(Map.Entry<String, String> entry : playerInfo.entrySet()){
            profileGrid.add(Box.createHorizontalStrut(5));
            profileGrid.add(setUpProfile(entry));
            profileGrid.add(Box.createHorizontalStrut(5));
        }

        //centers the profile grid on the main panel
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 1;

        add(profileGrid, gbc);
    }

    /**
     * Given a Map Entry comprised of a username key and an avatar name value,
     * it returns a JPanel with the image associated to that avatar name, and the username under it.
     * @param info Map Entry with a username key and an avatar name value
     * @return the "profile" JPanel
     */
    public JPanel setUpProfile(Map.Entry<String, String> info){
        return new JPanel(){
            {
                setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
                setBackground(Color.BLACK);
                setAlignmentX(Component.CENTER_ALIGNMENT);
                setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

                ActionListener setInfo = new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        userName = info.getKey();
                        frame.setAvatar(info.getValue());
                        frame.setUser(userName);
                        cLayout.show(organiser, "Menu");
                    }
                };

                add(ButtonFactory.createRowButton(new ImageIcon(ImageUtil.getImage("../../resources/avatars/"+info.getValue()+".png")
                        .getScaledInstance(64, 64, Image.SCALE_SMOOTH)), setInfo));

                add(Box.createVerticalStrut(5));

                add(new JLabel(info.getKey()){
                    {
                        setFont(pixelFont.deriveFont(34f));
                        setForeground(Color.WHITE);
                        setAlignmentX(Component.CENTER_ALIGNMENT);
                    }
                });
            }
        };
    }

    /**
     * Given an ArrayList of GameStats, this method returns a username->avatar Map.
     * When finding a duplicate, it keeps the first avatar it found.
     * @param stats ArrayList of GameStats (a "leaderboard")
     * @return a Map containing the different usernames.
     */
    public Map<String, String> getInfo(ArrayList<GameStats> stats){
        return stats.stream().collect(Collectors
                .toMap(GameStats::getPlayername, GameStats::getAvatar,
                        (oldAvatar, newAvatar)->oldAvatar));
    }


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        BufferedImage background = ImageUtil.getImage("../../resources/panels/profilePanel.png");
        g.drawImage(background, 0,0, null);


    }
}
