package game.view.panels;

import game.model.GameStats;
import game.model.Model;
import game.view.ImageUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.HashMap;

/**
 * Displays the score on the top of the screen.
 */
public class ScorePanel extends JPanel {
    private final HashMap<Character, BufferedImage> whiteFont;

    /**
     * ScorePanel constructor. Sets a couple options.
     * */
    public ScorePanel(){
        setPreferredSize(new Dimension(Model.SCREEN_WIDTH, Model.SCORE_HEIGHT));
        setFocusable(false);

        whiteFont = ImageUtil.setUpFont(new HashMap<>(),"../../resources/scorepanel/white_font/", "white_font_", true);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        setBackground(Color.BLACK);
        BufferedImage img;

        img = ImageUtil.getImage("../../resources/scorepanel/scorepanel.png");
        g.drawImage(img,0,0, null);

        GameStats stats = Model.getInstance().getPlayerStats();

        String oneUp = formatScores(String.valueOf(Math.abs(stats.getScore())));
        String highScore = formatScores(String.valueOf(stats.getHighScore()));

        if (stats.getScore()<0) {
            img = ImageUtil.getImage("../../resources/scorepanel/white_font/white_font_dash.png");
            g.drawImage(img, Model.TILE_SIZE, 40, Model.TILE_SIZE, Model.TILE_SIZE, null);
        }

        for(int i=0; i<168; i+=Model.TILE_SIZE){
            img = whiteFont.get(highScore.charAt(i/Model.TILE_SIZE));
            g.drawImage(img,300+i,40, Model.TILE_SIZE, Model.TILE_SIZE, null);
            img = whiteFont.get(oneUp.charAt(i/Model.TILE_SIZE));
            g.drawImage(img,48+i,40, Model.TILE_SIZE, Model.TILE_SIZE, null);
        }
    }


    /**
     * <p>Given a String in input, it fills it with zeroes until it becomes 7 chars-long.
     * (if it's already 7 chars-long, it returns the String itself)</p>
     * <p><b>formatting:</b></p>
     * <ul>
     * <li> % - format start</li>
     * <li> 0 - pad with leading zeroes </li>
     * <li> (7-highScore.length()) - how long the padding should be </li>
     * <li> d - interpret the number in input as a decimal number </li>
     * <li> %s - there will be a string after the zeroes </li>
     * <li> 0, score - the number to be formatted as a decimal (and padded) and the string </li>
     * </ul>
     * @param score the String to format
     * @return the formatted String
     */
    public String formatScores(String score){
        if(score.length()==7) return score;
        return String.format("%0"+(7-score.length())+"d%s",0,score);
    }

}
