package game.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 *Class created to aid with the creation of buttons.
 */
public class ButtonFactory {

    /**
     * Method to set up a button. This button's action listener will switch the given panel's shown panel
     * to the panel corresponding to the given "constraints".
     * @param cardLayout the organiser panel's layout, needed for the switch
     * @param organiser the organiser panel, needed for the switch
     * @param constraints the new panel's constraints when added to the organiser panel's CardLayout
     * @param dim the button's dimensions
     * @param path the path to the button's icon
     */
    public static JButton createShowButton(Dimension dim, String path, CardLayout cardLayout, JPanel organiser, String constraints) {
        return new JButton() {
            {
                setPreferredSize(dim);
                setIcon(new ImageIcon(ImageUtil.getImage(path)));
                setContentAreaFilled(false);
                setBorder(BorderFactory.createEmptyBorder());
                addActionListener( e -> cardLayout.show(organiser, constraints));
            }

        };
    }

    /**
     * Method to set up a button. Adjusts some settings, and
     * associates the button to the ActionListener in input.
     * @param dim the button's dimensions
     * @param path the path to the button's icon
     * @param aListener the button's ActionListener
     */
    public static JButton createActionButton(Dimension dim, String path, ActionListener aListener){
        return new JButton() {
            {
                setPreferredSize(dim);
                setIcon(new ImageIcon(ImageUtil.getImage(path)));
                setContentAreaFilled(false);
                setBorder(BorderFactory.createEmptyBorder());
                addActionListener(aListener);
            }
        };


    }
    /**
     * Method to set up a button. Adjusts some settings, and
     * associates the button to the ActionListener in input.
     * @param dim the button's dimensions
     * @param icon the button's icon
     * @param aListener the button's ActionListener
     */
    public static JButton createActionButton(Dimension dim, ImageIcon icon, ActionListener aListener){
        return new JButton() {
            {
                setPreferredSize(dim);
                setIcon(icon);
                setContentAreaFilled(false);
                setBorder(BorderFactory.createEmptyBorder());
                addActionListener(aListener);
            }
        };
    }

    /**
     * Factory Design Pattern method to set up a button designed to be inserted in a list of buttons.
     * Adjusts some settings, and associates the button to the ActionListener in input.
     * @param aListener the button's action listener
     * @param icon the button's icon
     */
    public static JButton createRowButton(ImageIcon icon, ActionListener aListener){
        return new JButton(){
            {
                setAlignmentX(Component.CENTER_ALIGNMENT);
                addActionListener(aListener);
                setBorder(BorderFactory.createEmptyBorder());
                setContentAreaFilled(false);
                setIcon(icon);
            }
        };
    }

}
