package game.view;


import game.model.Model;
import game.model.SoundEffect;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;



/**
 * MVC View class.
 */
@SuppressWarnings("deprecation")
public class View implements Observer {

    private static View instance;
    public Frame frame;

    /**
     * Private View constructor according to the Singleton Design Pattern. Instances a new Frame.
     */
    private View() {
        frame = new Frame();
        AudioManager.getInstance().play(SoundEffect.ARCADE_START);
    }

    /**
     * @return the instance of the View (Singleton Design Pattern)
     */
    public static View getInstance(){
        if(instance==null) instance = new View();
        return instance;
    }

    /**
     * When the observable is updated, it repaints the frame.
     * @param o     the observable object.
     * @param ob   an argument passed to the {@code notifyObservers}
     *                 method.
     */
    @Override
    public void update(Observable o, Object ob) {
        frame.repaint();
        AudioManager.getInstance().update();
        updateAudio();
    }
    /**
     * Handles the updating of the audio.
     */
    public void updateAudio(){
        ArrayList<SoundEffect> soundQueue = Model.getInstance().getSoundQueue();
        for(int i = soundQueue.size()-1; i >= 0; i--){
            switch(soundQueue.get(i)){
                case HURRY_UP_ALERT, MAIN_THEME -> AudioManager.getInstance().clearTracks();
                case SKEL_MONSTA_SPAWN -> AudioManager.getInstance().pauseTracks();
                case POP_BUBBLES -> {
                    if(AudioManager.getInstance().getTracks().containsKey(SoundEffect.POP_BUBBLES)) continue;
                }
                default -> {}
            }
            AudioManager.getInstance().play(soundQueue.get(i));
        }
    }

    /**
     * @return the player's name, from the Frame
     */
    public String getPlayerName(){return frame.getPlayerName();}

    /**
     * @return the player avatar, from the Frame
     */
    public String getAvatar() { return frame.getAvatar(); }

}
