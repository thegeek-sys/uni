package game.view;

import game.model.Model;
import game.view.panels.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyListener;

/**
 * Main Frame. Handles all the different panels.
 */
public class Frame extends JFrame{

    private CardLayout cLayout;
    private final JPanel organiser;
    private final MainScreen startScreen;
    private MainScreen winScreen;
    private MainMenu menu;
    private final JPanel gameScreenPanel;
    private GamePanel gamePanel;
    private ScorePanel scorePanel;
    private final JPanel helpPanel;
    private final ProfilePanel profilePanel;
    private LeaderboardPanel leaderBoard;
    private LeaderboardPanel endLeaderboard;

    private String avatar;
    private String playerName;

    /**
     * Frame constructor, which sets some options and creates a new instance of the first panels.
     */
    public Frame(){
        super("JBubble Bobble");
        setSize(new Dimension(Model.SCREEN_WIDTH, Model.SCREEN_HEIGHT));
        cLayout = new CardLayout();
        organiser = new JPanel(cLayout);
        organiser.setSize(new Dimension(Model.SCREEN_WIDTH, Model.SCREEN_HEIGHT));

        startScreen = new MainScreen(cLayout, organiser, "Profiles", "../../resources/panels/MainScreenPink.png");

        profilePanel = new ProfilePanel(this, cLayout, organiser);

        gameScreenPanel = new JPanel(){
            {
                setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
                gamePanel = new GamePanel();
                scorePanel= new ScorePanel();
                add(scorePanel);
                add(gamePanel);
            }
        };

        CardLayout helpScreens = new CardLayout();
        helpPanel = new JPanel(helpScreens);

        JPanel ruleScreen = new HelpScreen(HelpScreen.HelpType.RULES, helpScreens, helpPanel, cLayout, organiser);
        JPanel commandScreen = new HelpScreen(HelpScreen.HelpType.COMMANDS, helpScreens, helpPanel, cLayout, organiser);

        //handling the help panel CardLayout ("rules" vs "commands" panels)
        helpPanel.add(ruleScreen, "rules");
        helpPanel.add(commandScreen, "commands");
        helpScreens.show(helpPanel,"rules");

        organiser.add(startScreen, "StartScreen");
        organiser.add(profilePanel, "Profiles");
        organiser.add(helpPanel, "Help");
        add(organiser);
        //panel to start from
        cLayout.show(organiser, "StartScreen");

        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    /**
     * Creates the end screen, the main menu and the leaderboards (which cannot exist without a user) and sets
     * the current user.
     * @param playerName the player's username
     */
    public void setUser(String playerName){
        this.playerName = playerName;

        menu = new MainMenu(cLayout, organiser, gamePanel, this);
        leaderBoard = new LeaderboardPanel(cLayout, organiser);

        //handling the main CardLayout (all the different panels)
        organiser.add(menu, "Menu");
        organiser.add(gameScreenPanel, "Game");
        organiser.add(leaderBoard, "Leaderboard");

        validate(); //to be safe
        menu.setPlayerName(playerName);
        leaderBoard.setPlayerName(playerName);
    }

    /**
     * Handles the changing of the player's avatar.
     * @param playerName the player's username
     * @param avatar the player's avatar
     */
    public void changeAvatar(String playerName, String avatar){
        this.avatar = avatar;
        leaderBoard = new LeaderboardPanel(cLayout, organiser);
        leaderBoard.setPlayerName(playerName);
        organiser.add(leaderBoard, "Leaderboard");
    }

    /**
     * Setter for the "avatar" field.
     * @param avatar the avatar
     */
    public void setAvatar(String avatar){this.avatar = avatar;}

    /**
     * Getter for the "avatar" field.
     * @return the avatar name String
     */
    public String getAvatar(){return avatar;}

    /**
     * Getter for the "playerName" field.
     * @return the playerName
     */
    public String getPlayerName(){return playerName;}

    /**
     * Handles the showing of the end of the game leaderboard (if the player has lost)
     */
    public void showEndGame(){
        endLeaderboard = new LeaderboardPanel(Model.getInstance().getPlayerStats().getPlayername());
        organiser.add(endLeaderboard, "endGame");
        cLayout.show(organiser, "endGame");
    }

    /**
     * Handles the showing of the win screen (if the player has won)
     */
    public void showWinScreen(){
        winScreen = new MainScreen(cLayout, organiser, "endGame", "../../resources/panels/winScreen.png");
        endLeaderboard = new LeaderboardPanel(Model.getInstance().getPlayerStats().getPlayername());
        organiser.add(winScreen, "winScreen");
        organiser.add(endLeaderboard, "endGame");
        cLayout.show(organiser, "winScreen");
        winScreen.requestFocusInWindow();
    }

    @Override
    public void repaint() {
        gamePanel.repaint();
        scorePanel.repaint();
    }

    @Override
    public void addKeyListener(KeyListener k) {
        gamePanel.addKeyListener(k);
    }

}
