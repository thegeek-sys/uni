package game.view;

import game.model.SoundEffect;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import javax.sound.sampled.*;

/**
 * Singleton class used to handle audio playblack during the game
 */
public class AudioManager {

    private HashMap<SoundEffect, Clip> tracks;
    private static AudioManager instance;

    /**
     * @return AudioManager instance
     */
    public static AudioManager getInstance() {
        if (instance == null)instance = new AudioManager();
        return instance;
    }

    /**
     * private constructor according to Singleton pattern
     */
    private AudioManager() {
        tracks = new HashMap<>();
    }


    /**
     * Plays sound effect
     * @param sf type of sound effect to be played
     */
    public void play(SoundEffect sf) {
        try {
            InputStream in = new BufferedInputStream(new FileInputStream(System.getProperty("user.dir") + "/src/resources/audio/" + sf.toString().toLowerCase() + ".wav"));
            AudioInputStream audioIn = AudioSystem.getAudioInputStream(in);
            Clip clip = AudioSystem.getClip();
            clip.open(audioIn);
            Map<SoundEffect, Clip> syncedTracks = Collections.synchronizedMap(tracks);
            syncedTracks.put(sf, clip);
            setVolume(clip, sf.getVolume());
            clip.start();
        } catch (FileNotFoundException e1) {
            e1.printStackTrace();
        } catch (IOException e1) {e1.printStackTrace();
        } catch (UnsupportedAudioFileException e1) {e1.printStackTrace();
        } catch (LineUnavailableException e1) {e1.printStackTrace();}
    }

    /**
     * Updates all the tracks currently playing. Removes tracks that ended
     */
    public void update(){
        Map<SoundEffect, Clip> syncedTracks = Collections.synchronizedMap(tracks);
        Iterator<Map.Entry<SoundEffect, Clip>> tracksIterator = syncedTracks.entrySet().iterator();

        while(tracksIterator.hasNext()){
            Map.Entry<SoundEffect, Clip> track = tracksIterator.next();
            SoundEffect key = track.getKey();
            if(!syncedTracks.get(key).isActive() && !key.toString().endsWith("THEME")){
                tracksIterator.remove();
                switch(key){
                    case HURRY_UP_ALERT -> play(SoundEffect.HURRY_UP_THEME);
                    case SKEL_MONSTA_SPAWN -> resumeTracks();
                    default -> {}
                }

            }
        }
    }

    /**
     * Pauses all tracks currently playing
     */
    public void pauseTracks(){
        Iterator<Map.Entry<SoundEffect, Clip>> tracksIterator = tracks.entrySet().iterator();
        while(tracksIterator.hasNext()) {
            Map.Entry<SoundEffect, Clip> track = tracksIterator.next();
            track.getValue().stop();
            if(!track.getKey().toString().endsWith("THEME"))tracksIterator.remove();
        }
    }

    /**
     * Resumes all the tracks that were previously paused
     */
    public void resumeTracks(){
        Iterator<Map.Entry<SoundEffect, Clip>> tracksIterator = tracks.entrySet().iterator();
        while(tracksIterator.hasNext()) {
            Map.Entry<SoundEffect, Clip> track = tracksIterator.next();
            track.getValue().start();
        }
    }

    /**
     * Clears all the tracks currently playing
     */
    public void clearTracks() {
        Iterator<Map.Entry<SoundEffect, Clip>> tracksIterator = tracks.entrySet().iterator();
        while(tracksIterator.hasNext()) {
            Map.Entry<SoundEffect, Clip> track = tracksIterator.next();
            track.getValue().stop();
            tracksIterator.remove();
        }
    }

    /**
     * Sets volume of audio track
     * @param clip audio track
     * @param volume volume value in float type
     */
    public void setVolume(Clip clip, float volume) {
        if (volume < 0f || volume > 1f)
            throw new IllegalArgumentException("Volume not valid: " + volume);
        FloatControl gainControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
        gainControl.setValue(20f * (float) Math.log10(volume));
    }

    /**
     * @return all tracks currently playing
     */
    public HashMap<SoundEffect, Clip> getTracks(){ return tracks;}
}
