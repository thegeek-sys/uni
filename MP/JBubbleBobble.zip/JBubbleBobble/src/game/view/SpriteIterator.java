package game.view;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Implementation of the Iterator interface without an end.
 * A SpriteIterator keeps cycling through the given ArrayList of images.
 */
public class SpriteIterator implements Iterator<BufferedImage> {

    private ArrayList<BufferedImage> it;
    private double i; //index of the current image in the loop

    //the amount of sprites very frame.
    //speed = 1: next() gives one sprite every frame
    //speed = 1/10: next() gives one sprite every 10 frames
    private double speed;

    /**
     * SpriteIterator constructor. Sets the speed and the images to cycle through.
     * @param it ArrayList of BufferedImage
     * @param speed speed of the iterator
     */
    public SpriteIterator(ArrayList<BufferedImage> it, double speed){
        this.it = it;
        this.speed = speed;
    }

    /**
     * Another SpriteIterator constructor which takes no input. A SpriteIterator is an implementation of Iterator which has no end, it keeps cycling through the images.
     */
    public SpriteIterator(){
        it = new ArrayList<>();
    }

    /**
     * @return the next BufferedImage in the SpriteIterator
     */
    @Override
    public BufferedImage next() {
        i += speed;
        BufferedImage ob = it.get(Math.min((int)i, it.size()-1));
        if ((int)i > it.size()-1) i = 0;
        return ob;
    }

    /**
     * @return true (it's an infinite iterator)
     */
    @Override
    public boolean hasNext(){
        return true; //è infinito, ha sempre un next
}

    /**
     * Sets the "buf" Arraylist of BufferedImage field with the ArrayList in input.
     * @param buf the ArrayList of BufferedImage
     */
    public void set(ArrayList<BufferedImage> buf){
        it = buf;
    }

    /**
     * Creates a copy of the SpriteIterator instance.
     * @return a new SpriteIterator identical to the first one
     */
    public SpriteIterator copy(){
        return new SpriteIterator((ArrayList<BufferedImage>) it.clone(), speed);
    }

    /**
     * Sets the Sprite Iterator's speed.
     */
    public void setSpeed(double speed) { this.speed = speed;}

}
