package game.view;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

/**
 * Class that handles the import of fonts.
 **/
public class FontUtil {
    /**
    * Static font getter. Given a font in input, it will look for it in the
     * existing fonts and, if absent, register it. It will then return it as a Font.
     * @param fontPath the path to the font to check
     * @return the new Font
    **/
    public static Font getFont(String fontPath){
        GraphicsEnvironment GE = GraphicsEnvironment.getLocalGraphicsEnvironment();
        List<String> fonts = Arrays.asList(GE.getAvailableFontFamilyNames());
        try {
            File pixelFont = new File(fontPath);
            if (pixelFont.exists()) {
                Font FONT = Font.createFont(Font.TRUETYPE_FONT, pixelFont);
                if (!fonts.contains(FONT.toString())) {
                    GE.registerFont(FONT);
                }
                return FONT;
            }
        }catch (IOException | FontFormatException e) {e.printStackTrace();}
        return null;
    }

}




