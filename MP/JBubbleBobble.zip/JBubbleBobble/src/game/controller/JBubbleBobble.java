package game.controller;
import game.model.Model;
import game.view.View;

/**
 * Main class
 */
public class JBubbleBobble {
    public static final int FPS = 60;
    public static final long NS_WAIT = 1000000000/FPS;
    public static boolean started;

    public static void main(String[] args) throws InterruptedException {
        long timeBefore;
        long timeAfter;
        long timeDifference;
        boolean running = true;

        View v = View.getInstance();

        //waits for the button click before starting the game
        Model m = Model.getInstance();
        while(!started){
            try {
                Thread.sleep(1);
            }catch(InterruptedException e) {e.printStackTrace();}
        }

        m.startGame();
        m.setPlayerStats(v.getPlayerName(), v.getAvatar());
        Controller c = new Controller(m,v);

        while(running){
            timeBefore = System.nanoTime();
            c.update();
            m.update();

            timeAfter = System.nanoTime();
            timeDifference = timeAfter - timeBefore;
            long nsSleep = NS_WAIT - timeDifference;
            Thread.sleep(Math.max(nsSleep/1000000, 0));
            if(m.isEnded()) running = false;
        }

        boolean endScreen = false;
        while(true) {
            if (!endScreen) {
                if (Model.getInstance().getPlayerStats().getWin()) v.frame.showWinScreen();
                else v.frame.showEndGame();
                endScreen = true;
            }
        }
    }

    /**
     * Starts the gameloop
     */
    public static void startGameLoop(){started = true;}

}
