package game.controller;

import game.model.Model;
import game.model.State;
import game.model.entities.Bubblun;
import game.view.View;

/**
 * Manages players inputs
 */
public class Controller{

    private final KeyHandler keyH;
    private final Model m;

    /**
     * Controller constructor.
     * Creates a Controller with Model and View as parameter
     * @param m instance of Model
     * @param v instance of View
     */
    public Controller(Model m, View v) {
        this.m = m;
        keyH = new KeyHandler();
        v.frame.addKeyListener(keyH);
        m.addObserver(v);
        //escamotage to play ARCADE_START
        //m.update();
    }

    /**
     * Manages the keyHandler. Sets the player's Direction according to the pressed key.
     */
    public void update() {

        if (m.getPlayer().getHealthState() == State.STANDARD  || m.getPlayer().getHealthState() == State.INVULNERABLE) {
            if (keyH.isZPressed() && !m.getPlayer().isJumping() && !m.getPlayer().isFalling() && keyH.wasZReleased()) {
                keyH.setZReleased(false);
                m.updatePlayer(0, true, false);
            }
            if (keyH.isLeftPressed()) m.updatePlayer(-Bubblun.VEL_X, false, false);
            else if (keyH.isRightPressed()) m.updatePlayer(Bubblun.VEL_X, false, false);

            if (!keyH.isLeftPressed() && !keyH.isRightPressed() && ((!m.getPlayer().isJumping() && !m.getPlayer().isShooting())
                    || (m.getPlayer().isJumping()) && !m.getPlayer().isShooting() && !keyH.wasXReleased())) {
                m.updatePlayer(0, false, false);
            }
            if (keyH.isXPressed() && !m.getPlayer().isShooting() && keyH.wasXReleased() && m.getPlayer().isAllowedToShoot()) {
                m.updatePlayer(0, false, true);
                keyH.setXReleased(false);
            }
        }

    }

}
