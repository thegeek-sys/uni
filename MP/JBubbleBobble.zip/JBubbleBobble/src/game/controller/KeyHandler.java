package game.controller;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * Handles the keys pressed. Used in the Controller
 */
public class KeyHandler implements KeyListener {

    private boolean zPressed, leftPressed, rightPressed, xPressed;
    private boolean zReleased,xReleased;

    /**
     * KeyHandler constructor
     */
    public KeyHandler() {
        zReleased = true;
        xReleased = true;
    }

    /**
     * Necessary due to KeyListener implementation
     * @param e the event to be processed
     */
    @Override
    public void keyTyped(KeyEvent e) {}

    /**
     * Checks which key pressed and sets the corresponding pressed boolean to true
     * @param e the event to be processed
     */
    @Override
    public void keyPressed(KeyEvent e) {

        int code = e.getKeyCode();

        if (code == KeyEvent.VK_Z)  zPressed = true;
        if (code == KeyEvent.VK_LEFT)  leftPressed = true;
        if (code == KeyEvent.VK_RIGHT) rightPressed = true;
        if (code == KeyEvent.VK_X) xPressed = true;
    }

    /**
     * Checks when a key is released and sets the corresponding released boolean to true and pressed boolean to false
     * @param e the event to be processed
     */
    @Override
    public void keyReleased(KeyEvent e) {

        int code = e.getKeyCode();

        if (code == KeyEvent.VK_Z) {
            zPressed = false;
            zReleased = true;
        }
        if (code == KeyEvent.VK_LEFT) leftPressed = false;
        if (code == KeyEvent.VK_RIGHT) rightPressed = false;
        if (code == KeyEvent.VK_X){
            xPressed = false;
            xReleased = true;
        }
    }

    /**
     * @return whether the left arrow key is pressed
     */
    public boolean isLeftPressed() { return leftPressed; }

    /**
     * @return whether the right arrow key is pressed
     */
    public boolean isRightPressed() { return rightPressed; }

    /**
     * @return whether the X key is pressed
     */
    public boolean isXPressed() { return xPressed; }

    /**
     * @return whether the Z key is pressed
     */
    public boolean isZPressed() { return zPressed; }

    /**
     * @return whether the X key has been released
     */
    public boolean wasXReleased() { return xReleased; }

    /**
     * @return whether the Z key has been released
     */
    public boolean wasZReleased() { return zReleased; }

    /**
     * Sets zReleased to the boolean in input
     * @param zReleased whether the Z key has been released
     */
    public void setZReleased(boolean zReleased) { this.zReleased = zReleased; }

    /**
     * Sets xReleased to the boolean in input
     * @param xReleased whether the X key has been released
     */
    public void setXReleased(boolean xReleased) { this.xReleased = xReleased; }

}

