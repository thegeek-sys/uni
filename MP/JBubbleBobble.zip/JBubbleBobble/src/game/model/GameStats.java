package game.model;

import game.model.entities.bubbles.special_bubbles.LaudeType;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Class that handles all the possible stats from a game
 */
public class GameStats implements Serializable, Comparable<GameStats>{
    public static ArrayList<GameStats> leaderboard;

    private int score;
    private String playerName;
    private String avatar;
    private String timeTaken;
    private boolean win;

    private transient int bubblesBlown;
    private transient int emptyBubblesPopped;
    private transient int jumpCounter;
    private transient int steps;
    private transient int waterBubblesPopped;
    private transient int purpleCandiesEaten;
    private transient int yellowCandiesEaten;
    private transient int blueCandiesEaten;
    private transient int enemiesStruck;
    private transient Boolean[] laudeBubbles;
    private transient HashMap<LaudeType, Integer> laudeFrequency;
    private transient int sec;
    private transient int min;

    /**
     * Constructor
     * @param playerName player name
     * @param avatar player avatar
     */
    public GameStats(String playerName, String avatar){
        this.playerName = playerName;
        this.avatar = avatar;
        laudeFrequency = new HashMap<>();
        laudeFrequency.put(LaudeType.ZERO, 0);
        laudeFrequency.put(LaudeType.THREE, 0);
        laudeFrequency.put(LaudeType.L, 0);
        laudeFrequency.put(LaudeType.O, 0);
        laudeFrequency.put(LaudeType.D, 0);
        laudeFrequency.put(LaudeType.E, 0);
        laudeBubbles = new Boolean[]{false, false, false, false, false, false};
    }

    /**
     * Adds to the total game points
     * @param score new points gained
     */
    public void addScore(int score) {
        this.score += score;
    }

    /**
     * @return current game points
     */
    public int getScore() { return score; }

    /**
     * Sets current game points
     * @param score game points
     */
    public void setScore(int score){this.score = score;}

    /**
     * @return whether the game was won or lost
     */
    public boolean getWin(){ return win;}

    /**
     *
     */
    public void setWin(){win = true;}

    /**
     * Sets leaderboard
     */
    public static void setLeaderboard(){ leaderboard = Model.getInstance().deserializeGameStats(); }

    /**
     * @return player avatar
     */
    public String getAvatar() { return avatar; }

    /**
     * Sets player avatar
     * @param avatar player avatar
     */
    public void setAvatar(String avatar) {this.avatar = avatar;}

    /**
     * @return player name
     */
    public String getPlayername() { return playerName;}

    /**
     * Sets player name
     * @param newPlayerName new player name
     */
    public void setPlayerName(String newPlayerName){this.playerName = newPlayerName;}

    /**
     * @return leaderboard high score
     */
    public int getHighScore(){ return Math.max(leaderboard.getFirst().score, score); }

    /**
     * @return time elapsed during the game
     */
    public String getTimeTaken(){ return timeTaken; }

    /**
     * Sets time elapsed during the game
     * @param min minutes elapsed
     * @param sec seconds elapsed
     */
    public void setTimeTaken(int min, int sec) {
        this.min = min;
        this.sec = sec;
        timeTaken = min+" min "+sec+" sec";
    }

    /**
     * Adds new LaudeBubble to count
     * @param laudeType laude bubble letter
     */
    public void addLaude(LaudeType laudeType) {
        laudeFrequency.put(laudeType, laudeFrequency.get(laudeType)+1);
        laudeBubbles[laudeType.getId()] = true;
    }

    /**
     * @return array that contains if each letter has been collected at least once or not
     */
    public Boolean[] getLaudeBubbles() {return laudeBubbles;}

    /**
     * Resets laude bubble count
     */
    public void resetLaudeBubbles(){laudeBubbles = new Boolean[]{false, false, false, false, false, false}; }

    /**
     * @return how many laude bubbles of the same letter have been collected, for each letter
     */
    public HashMap<LaudeType, Integer> getLaudeFrequency() { return laudeFrequency; }

    /**
     * @return array containing all stats that influence 12-second item drop, in descending order of importance
     */
    public int[] getStats() { return new int[] { enemiesStruck, waterBubblesPopped, purpleCandiesEaten,yellowCandiesEaten, blueCandiesEaten, steps, emptyBubblesPopped, bubblesBlown, jumpCounter}; }

    /**
     * Adds one bubble blown to count
     */
    public void addBubblesBlown(){bubblesBlown++;}

    /**
     * Adds one blue candy eaten to count
     */
    public void addBlueCandiesEaten(){blueCandiesEaten++;}

    /**
     * Resets blue candies eaten count
     */
    public void resetBlueCandiesEaten(){blueCandiesEaten=0;}

    /**
     * Adds one yellow candy eaten to count
     */
    public void addYellowCandiesEaten(){yellowCandiesEaten++;}

    /**
     * Resets yellow candies eaten count
     */
    public void resetYellowCandiesEaten(){yellowCandiesEaten=0;}

    /**
     * Adds one purple candy eaten to count
     */
    public void addPurpleCandiesEaten(){purpleCandiesEaten++;}

    /**
     * Resets purple candies eaten count
     */
    public void resetPurpleCandiesEaten(){purpleCandiesEaten=0;}

    /**
     * Adds one empty bubble popped to count
     */
    public void addEmptyBubblesPopped() { emptyBubblesPopped++; }

    /**
     * Resets empty bubbles popped
     */
    public void resetEmptyBubblesPopped(){emptyBubblesPopped = 0;}

    /**
     * Adds one water bubble popped to count
     */
    public void addWaterBubblesPopped(){waterBubblesPopped++;}

    /**
     * Resets water bubbles popped count
     */
    public void resetWaterBubblesPopped(){waterBubblesPopped = 0;}

    /**
     * Resets bubbles blown count
     */
    public void resetBubblesBlown(){ bubblesBlown = 0; }

    /**
     * Adds one jump to count
     */
    public void addJumps(){jumpCounter++;}

    /**
     * Resets jumps count
     */
    public void resetJumpCounter() { jumpCounter = 0; }

    /**
     * Adds steps to totals steps during the game
     * @param newSteps new steps taken
     */
    public void addSteps(int newSteps){steps+= newSteps;}

    /**
     * Resets steps taken count
     */
    public void resetSteps() { steps = 0; }

    /**
     * @param laude laude bubble letter
     * @return amount of bubbles containing the same letter popped
     */
    public Integer getLetterFrequency(LaudeType laude) { return laudeFrequency.get(laude); }

    /**
     * Adds one enemy struck to counter
     */
    public void addEnemiesStruck(){ enemiesStruck++; }

    /**
     * Resets enemies struck counter
     */
    public void resetEnemiesStruck(){ enemiesStruck = 0; }

    /**
     * @return leaderboard
     */
    public static ArrayList<GameStats> getLeaderboard() { return leaderboard; }

    /**
     * Implementation of Comparable interface method. Compares two objects, used to establish an order
     * @param otherStat the object to be compared.
     * @return whether one stat line is better than another
     */
    @Override
    public int compareTo(GameStats otherStat) {
        if(this.score > otherStat.score) return -1;
        if(otherStat.score > this.score) return 1;
        if(min*60+sec < otherStat.min*60+ otherStat.sec) return -1;
        if(otherStat.min*60+ otherStat.sec < this.min*60+this.sec) return 1;
        return this.playerName.compareTo(otherStat.playerName);
    }
}
