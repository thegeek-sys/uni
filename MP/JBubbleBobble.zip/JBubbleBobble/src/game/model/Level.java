package game.model;

import game.model.entities.*;
import game.model.entities.bubbles.*;
import game.model.entities.bubbles.special_bubbles.LaudeType;
import game.model.entities.bubbles.special_bubbles.SpecialBubble;
import game.model.entities.Train;
import game.model.entities.opps.Enemy;
import game.model.entities.opps.SkelMonsta;
import game.view.View;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Class of the current level player. Instanced whenever the previous level is ended
 */
public class Level {
    private final int levelNumber;
    private static Bubblun player;

    private static GameStats playerStats;

    private ArrayList<ArrayList<Integer>> levelMap;
    private ArrayList<BBubble> bubbles;
    private ArrayList<SpecialBubble> specialBubbles;
    private ArrayList<Element> elements;
    private ArrayList<Enemy> enemies;
    private ArrayList<Item> items;
    private ArrayList<Star> stars;
    private ArrayList<Train> trains;
    private CollisionHandler collisionHandler;
    private boolean completed;
    private boolean finished;
    private int transitionCounter;
    private long hitTimer;
    private boolean hurryUp;
    //trash code
    private boolean hurriedUp;
    //end of trash code
    private long trainTimer;
    //for final level:
    private int trainsHit;

    private int enemyMultiplier;
    private int currEnemyMultiplier;
    private int countingStars;

    private boolean loadedNextLevelEnemies;
    private Item bigScore; //last bubble popped when multiple BBubbles are popped

    private long levelTime;
    private long previousLevelTime;
    private long delayTimer;

    public final static long HURRY_UP = 30_000_000_000L;
    public static final long SEVEN_SECONDS = 7_000_000_000L;
    public static final long TWELVE_SECONDS = 12_000_000_000L;
    public static final long DELAY_LENGTH = 6_000_000_000L;
    public static final long LOADING_TIME = 2_000_000_000L;
    public static final long SKELMONSTA_SPAWN = HURRY_UP + 6_000_000_000L;
    public static final long LEVEL_INFO_LENGTH= 2_000_000_000L;

    private boolean sevenSecondItem;
    private boolean twelveSecondItem;

    /**
     * Constructor called when creating the first level and used to create all the others
     * @param levelNumber level to create (from 1 to 25)
     * @param p Bubblun's instance
     */
    public Level(int levelNumber, Bubblun p){
        this.levelNumber = levelNumber;
        player = p;
        levelMap = new ArrayList<>();
        bubbles = new ArrayList<>();
        enemies = new ArrayList<>();
        items = new ArrayList<>();
        elements = new ArrayList<>();
        specialBubbles = new ArrayList<>();
        stars = new ArrayList<>();
        trains = new ArrayList<>();
        collisionHandler = new CollisionHandler(p);
        transitionCounter = 1;
        trainTimer = System.nanoTime();
        loadLevel();
        MovementManager.setLevel(this);
        levelTime = System.nanoTime();
    }

    /**
     * Level constructor for all the levels except for the first one. Calls the other constructor
     * @param levelNumber level to create (from 1 to 25)
     * @param previousLevelTime previous level time used to spawn the 7-second item
     * @param enemies ArrayList of Enemy
     */
    public Level(int levelNumber, long previousLevelTime, ArrayList<Enemy> enemies){
        this(levelNumber, player);
        player.resetMultipliers();
        player.clearPowerUp();
        this.previousLevelTime = previousLevelTime;
        this.enemies = enemies;
    }

    /**
     * Used to update the current level (except for level 25), called every frame
     * <ul>
     *     <li>Checks if a level is empty (there are no enemies except for SkelMonsta and no bubbles have an enemy inside it) and sets completed to true</li>
     *     <li>When a level is completed a timer is started to make the user collect all the remaining items before transitioning to the next level</li>
     *     <li>If none of the previous conditions is matched it moves all the items on screen and spawns possible power-ups</li>
     * </ul>
     */
    public void update(){
        if(!completed && (enemies.isEmpty() || (enemies.size() == 1 && enemies.getFirst() instanceof SkelMonsta)) && bubbles.stream().allMatch(x -> x.getAbsordbedEnemy() == null)){
            if(!enemies.isEmpty()) {
                ((SkelMonsta)enemies.getFirst()).setKiller();
            }
            setCompleted(true);
        }
        if (completed && ((levelNumber != 100 &&System.nanoTime()-delayTimer>=DELAY_LENGTH ) || (levelNumber == 100 && System.nanoTime()-delayTimer >= DELAY_LENGTH * 5))) {
            stars.clear();
            items.clear();
            bubbles.clear();
            specialBubbles.clear();
            transition();
            moveEnemies();
        } else {
            if(System.nanoTime() - levelTime >= HURRY_UP && !completed) handleHurryUp();
            moveBubblun();
            moveEnemies();
            moveBubbles();
            moveElements();
            moveItems();
            if(player.getPowerUp() == ItemType.SILVER_RING) spawnStars();
            spawnPowerUps();
        }
    }

    /**
     * Used to update level 25, called every frame
     * <ul>
     *     <li>Checks if the timeout time for this level is reached (150 seconds) and kills the player making the player lose the game</li>
     *     <li>When the player collects 30 Metro B trains the game is won</li>
     *     <li>If none of the previous conditions is matched it spawns a new ATAC train (chosen randomly between Metro A, Metro B and Metro C) and moves the items on screen</li>
     * </ul>
     */
    public void updateLastLevel(){
        if(System.nanoTime()-levelTime>=150_000_000_000L) {
            while (player.getHealth() > 0) {
                player.loseHealth();
            }
        } else if (trainsHit >= 30) {
            playerStats.setWin();
            addStats();

        } else {
            if(System.nanoTime()-trainTimer>=800_000_000L){
                int x = Math.random() <= 0.5 ? 460 : 342;
                trains.add(new Train(x));
                trains.add(new Train(x==460 ? 342 : 460));
                trainTimer = System.nanoTime();
            }
            moveBubblun();
            moveBubbles();
            moveTrains();
        }
    }

    /**
     * Sets players' game stats
     * @param stats GameStats to set
     */
    public void setPlayerStats(GameStats stats){ playerStats = stats;}

    /**
     * Loads level and all the Entities in it
     * <ol>
     *     <li>Deserializes the enemies of the level</li>
     *     <li>Reads a level and puts it into a int matrix</li>
     *     <li>Interprets the previous matrix and turns it into an ArrayList of ArrayList of Block (used later on to check collisions)</li>
     *     <li>Turns the ArrayList matrix into an array matrix through stream</li>
     *     <li>Sets the array to the CollisionHandler</li>
     *     <li>Deserializes all the other bubbles and items of the level</li>
     * </ol>
     */
    public void loadLevel() {
        String levelString = "level" + levelNumber;
        if(enemies.isEmpty()) enemies = deserializeEnemy(levelString);
        loadLevelMap(levelString);

        ArrayList<ArrayList<Block>> glob = new ArrayList<>();
        for (int y = 0; y < levelMap.size(); y++) {
            ArrayList<Block> temp = new ArrayList<>();
            for (int x = 0; x < levelMap.getFirst().size(); x++) {
                int p = Math.min(levelMap.get(y).get(x), 1);
                temp.add(x, new Block(p != 0,
                        x * Model.TILE_SIZE, y * Model.TILE_SIZE));
            }
            glob.add(temp);
        }
        Block[][] blocksArray = glob.stream().map(u -> u.toArray(new Block[0])).toArray(Block[][]::new);
        collisionHandler.setBlocksArray(blocksArray);
        deserializeThings(levelString);
    }

    /**
     * Reads the level txt file and turns it into a matrix ArrayList of integers. Reads each line, splits it on the spaces, transform the line into an ArrayList of integers and adds it to levelMap
     * @param levelString String representing a Level
     */
    public void loadLevelMap(String levelString) {
        try (BufferedReader br = Files.newBufferedReader(Paths.get(System.getProperty("user.dir") + "/src/game/model/levels/level" + levelNumber + "/" + levelString + ".txt"))) {
            Stream<String> s = br.lines();
            /* from a String stream containing the level's representation split into lines, this:
        1) takes each line, splits it and puts it into an Array,
        2) turns the array into a Stream, maps each String in the stream to an Integer, and
        3) collects the Integers into an ArrayList,
        4) adds the ArrayList to the "level" matrix, effectively creating a level
        */
            s.forEach(l -> levelMap.add((ArrayList<Integer>)Arrays.stream(l.split(" ")).map(Integer::parseInt).collect(Collectors.toList())));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Deserializes the enemies of a certain level and sets the y coordinate to -288 to make the transition animation
     * @param fileName file to deserialize
     * @return deserialized ArrayList of Enemy
     */
    public ArrayList<Enemy> deserializeEnemy(String fileName) {
        ArrayList<Enemy> enemyList = new ArrayList<>();
        try {
            FileInputStream fis = new FileInputStream(System.getProperty("user.dir") + "/src/game/model/levels/" + fileName + "/" + fileName + ".enemy");
            ObjectInputStream ois = new ObjectInputStream(fis);

            //reading and casting
            enemyList = (ArrayList<Enemy>) ois.readObject();

            for (Enemy enemy : enemyList) {
                enemy.setSpawnY(enemy.getY()-6);
                enemy.setY(-288 + enemy.getY()-6);
                enemy.setFalling(true);
            }

            ois.close();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return enemyList;
    }

    /**
     * Deserializes the special bubbles and items of a certain level. Starts the spawn timer for them
     * @param fileName file to deserialize
     */
    public void deserializeThings(String fileName){
        try {
            FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"/src/game/model/levels/"+fileName + "/" + fileName + ".item");
            ObjectInputStream ois = new ObjectInputStream(fis);

            specialBubbles = (ArrayList<SpecialBubble>) ois.readObject();
            for(SpecialBubble bubble : specialBubbles){
                bubble.startTimer();
            }

            ArrayList<Item> ob = (ArrayList<Item>) ois.readObject();
            items.addAll(ob);

            for(Item item:items){
                item.startTimer();
            }
            ois.close();
        }

        catch(ClassNotFoundException e) {e.printStackTrace();}
        catch(IOException e) {e.printStackTrace();}
    }

    /**
     * Calls a MovementManager method on each Enemy to move it if the transition animation is ended and removes them if they are dead and out of the screen
     */
    public void moveEnemies(){

        for (int i = enemies.size()-1; i > -1; i--) {
            Enemy enemy = enemies.get(i);
            if (enemy.getHealthState()== State.DEAD && enemy.getY() > Model.GAME_SCREEN_HEIGHT) enemies.remove(enemy);
            else if (System.nanoTime() - levelTime >= LOADING_TIME) MovementManager.moveEnemy(enemy);
        }
    }

    /**
     * Calls a MovementManager method on each Element to move it
     */
    public void moveElements(){
        for(int i = elements.size()-1; i>-1; i--) MovementManager.moveElement(elements.get(i), elements);
    }

    /**
     * If Bubblun has no more lives adds the GameStats to the leaderboard and ends the game otherwise calls the MovementManager to move it
     */
    public void moveBubblun() {
        if(player.getHealthState() == State.DEAD ) {
            addStats();
        }
        MovementManager.moveBubblun(player, items, enemies);
    }

    /**
     * Adds the current game stats to the leaderboard and re-serialize it. Sets the end of the game to true
     */
    public void addStats() {
        ArrayList<GameStats> stats = GameStats.getLeaderboard();
        long time = Model.getInstance().getGameTime();
        time = time/1_000_000_000L;
        playerStats.setTimeTaken((int)time/60, (int)time%60);
        stats.add(playerStats);
        Model.getInstance().serializeGameStats(stats);
        Model.getInstance().setEnded(true);
    }

    /**
     * Calls the MovementManager on each bubble (normal and special). Added a check to avoid errors when there are too many bubbles on the screen
     */
    public void moveBubbles() {
        for (int i = bubbles.size() - 1; i > -1; i--) {
            if(bubbles.get(i) == null) continue;
            MovementManager.moveBubble(bubbles.get(i), bubbles, enemies, player);
        }
        for(int i = specialBubbles.size() -1; i > -1; i--){
            if(specialBubbles.get(i) == null) continue;
            MovementManager.moveSpecialBubble(specialBubbles.get(i), specialBubbles, player);
        }
    }

    /**
     * Handles the timer used to assign the score and to spawn the items when killing multiple enemies at the same time. Creates a new item if the score gaines it >= 2000
     */
    public void handleTimer(){
        if(System.nanoTime() - hitTimer >= 150_000_000L && hitTimer != 0) {
            hitTimer = 0;
            Model.getInstance().getPlayerStats().addScore(getHitPoints());
            if(getHitPoints() >= 2000){
                bigScore.setBig(true);
                bigScore.showValue();
                items.add(bigScore);
            }
        }
    }

    /**
     * Counts how many bubbles with enemies are popped together
     * @param bubble BBubble popped. It uses x and y coordinates to spawn an Item
     * @param popAll whether getting the score of all the BBubbles on the screen or not (true when there are no more enemies on the screen and a bubble is popped)
     */
    public void handleHits(BBubble bubble, boolean popAll){
        if (hitTimer == 0) {
            currEnemyMultiplier = enemyMultiplier;
            hitTimer = System.nanoTime();
            enemyMultiplier = 1;
            bigScore = new Item(bubble.getX(), bubble.getY(), null);
        } else if (popAll) {
            // gets the score of all the bubbles with enemies when there are no more enemies on the screen and a bubble is popped
            bigScore = new Item(bubble.getX(), bubble.getY(), null);
            Model.getInstance().getPlayerStats().addScore(getHitPoints());
            if(getHitPoints() >= 2000){
                bigScore.setBig(true);
                bigScore.showValue();
                items.add(bigScore);
            }
        } else {
            enemyMultiplier++;
        }
    }

    /**
     * Calls the MovementManager on each Item the last level to move it
     */
    public void moveItems() {
        for (int i = items.size() - 1; i >= 0; i--) {
            MovementManager.moveItem(items.get(i), items);
        }
    }

    /**
     * Calls the MovementManager on each Train in the last level to move it
     */
    public void moveTrains() {
        for (int i=trains.size()-1; i>-1; i--) {
            MovementManager.moveTrain(trains.get(i), trains, player);
        }
    }

    /**
     * Spawns the stars in a random x position when a silver ring is collected and calls the MovementManager to move them. They have go in random directions
     */
    public void spawnStars(){
        countingStars++;
        if (countingStars<=500 && countingStars%5==0) {
            int x = (int) (Math.random()*((Model.SCREEN_WIDTH-Model.TILE_SIZE*2)-Model.TILE_SIZE*2)+Model.TILE_SIZE*2);
            stars.add(new Star(x));
        } else if (stars.isEmpty() && countingStars > 5) {
            player.clearPowerUp();
        }

        for (int i=stars.size()-1; i>-1; i--) {
            MovementManager.moveStar(stars.get(i), stars);
        }
    }

    /**
     * Spawns the power-up Items according to original spawn rules
     */
    public void spawnPowerUps(){
        if (!sevenSecondItem && System.nanoTime()-levelTime >= SEVEN_SECONDS){
            int approxTime = previousLevelTime!=0L ? Math.max((int)Math.floor((double)previousLevelTime / 1_000_000_000L), 20) : 0;
            for(int i = 0; i < 6; i++){
                if(playerStats.getLetterFrequency(LaudeType.getLetter(i)) == 3){
                    items.add(new Item(Model.TILE_SIZE * 8, 0, CollisionHandler.findSpawnY(Model.TILE_SIZE * 8), LaudeType.getLaudeCane(LaudeType.getLetter(i))));
                    playerStats.getLaudeFrequency().put(LaudeType.getLetter(i), 0);
                    sevenSecondItem = true;
                    break;
                }
            }
            if(ItemType.getTimePointItem(approxTime) != null && !sevenSecondItem) items.add(new Item(Model.TILE_SIZE  * 8, 0, CollisionHandler.findSpawnY(Model.TILE_SIZE  * 8), ItemType.getTimePointItem(approxTime)));
            sevenSecondItem = true;
        }
        else if (!twelveSecondItem && System.nanoTime()-levelTime >= TWELVE_SECONDS) {
            twelveSecondItem = true;

            int spawnY = CollisionHandler.findSpawnY(Model.TILE_SIZE * 12);

            //secret level ?
            if(levelNumber == 20 && !player.hasLostLives()) items.add(new Item(Model.TILE_SIZE *12, 0, spawnY, ItemType.SILVER_DOOR));
                //if the player has hit 12+ enemies with lightning bubbles
            else if(playerStats.getStats()[0] >= 12){
                items.add(new Item(Model.TILE_SIZE * 12, 0, spawnY, ItemType.SILVER_RING));
                playerStats.resetEnemiesStruck();
            }
                //if the player has popped 6 water bubbles
            else if (playerStats.getStats()[1] >= 6) {
                items.add(new Item(Model.TILE_SIZE * 12, 0, spawnY, ItemType.PURPLE_UMBRELLA));
                playerStats.resetWaterBubblesPopped();

                //if the player has popped 4 water bubbles
            } else if (playerStats.getStats()[1] >= 4) {
                items.add(new Item(Model.TILE_SIZE * 12, 0, spawnY, ItemType.RED_UMBRELLA));

                //if the player has popped 2 water bubbles
            } else if (playerStats.getStats()[1] >= 2) {
                items.add(new Item(Model.TILE_SIZE * 12, 0, spawnY, ItemType.ORANGE_UMBRELLA));

                //if the player has eaten 3 purple candies
            } else if (playerStats.getStats()[2] >= 3) {
                items.add(new Item(Model.TILE_SIZE * 12, 0, spawnY, ItemType.RED_RING));
                playerStats.resetPurpleCandiesEaten();

                //if the player has eaten 3 yellow candies
            } else if (playerStats.getStats()[3] >= 3){
                items.add(new Item(Model.TILE_SIZE * 2, 0, spawnY, ItemType.PURPLE_RING ));
                playerStats.resetYellowCandiesEaten();

                //if the player has eaten 3 blue candies
            }else if (playerStats.getStats()[4] >= 3){
                items.add(new Item(Model.TILE_SIZE * 2, 0, spawnY, ItemType.CYAN_RING));
                playerStats.resetBlueCandiesEaten();

                //if the player has walked more than 15 times the length of the screen
            } else if(playerStats.getStats()[5] >= (28*Model.TILE_SIZE * 15) ){
                items.add(new Item(Model.TILE_SIZE * 12, 0, spawnY, ItemType.RED_SHOE));
                playerStats.resetSteps();

                //if the player has popped more than 35 empty bubbles
            }else if(playerStats.getStats()[6] >= 35){
                items.add(new Item(Model.TILE_SIZE * 12, 0, spawnY, ItemType.BLUE_CANDY));
                playerStats.resetEmptyBubblesPopped();

                //if the player has blown more than 35 bubbles
            }else if(playerStats.getStats()[7] >= 35) {
                items.add(new Item(Model.TILE_SIZE * 12, 0, spawnY, ItemType.PURPLE_CANDY));
                playerStats.resetBubblesBlown();

                //if the player has jumped more than 35 times
            }else if(playerStats.getStats()[8] >= 35){
                items.add(new Item(Model.TILE_SIZE * 12, 0, spawnY, ItemType.YELLOW_CANDY));
                playerStats.resetJumpCounter();
            }
        }

    }

    /**
     * Used to set a level to complete. It also gets the total levelTime (to spawn 7-second Item in the next level) and start the delay time before transition to next level
     * @param completed whether the level is completed or not
     */
    public void setCompleted(boolean completed) {
        this.completed = completed;
        levelTime = System.nanoTime() - levelTime;
        if(completed) {
            onComplete();
            delayTimer = System.nanoTime();
        }
    }

    /**
     * When a level is completed, clears the level and loads into levelMap the transition to the next level
     */
    public void onComplete(){
        levelMap.clear();
        int nextLevel;
        if(player.getPowerUp() == ItemType.SILVER_DOOR) nextLevel = 100;
        else if(levelNumber == 100) nextLevel = 21;
        else nextLevel = levelNumber+1;
        String levelString = "level" + levelNumber + "_" + "level" + nextLevel + "_transition";
        loadLevelMap(levelString);
        if(hurriedUp) Model.getInstance().addSound(SoundEffect.MAIN_THEME);
    }

    /**
     * Transitions to the next level
     */
    public void transition(){
        if(levelMap.size() > 26) {
            if(transitionCounter % Model.TRANSITION_SPEED == 0 )  levelMap.removeFirst();
            transitionCounter++;
            if(transitionCounter > 35 && !loadedNextLevelEnemies) {
                int nextLevel = levelNumber +1;
                if(levelNumber == 100) nextLevel = 21;
                else if(levelNumber == 20 && player.getPowerUp() == ItemType.SILVER_DOOR) nextLevel = 100;
                this.enemies = deserializeEnemy("level" + nextLevel);
                loadedNextLevelEnemies = true;
            }
        }

        if(((levelNumber == 24 && player.getX() == Bubblun.SPAWN_X && player.getY() >= Model.TILE_SIZE * 4) ||(levelNumber != 24 && player.getX() == Bubblun.SPAWN_X &&  player.getY() >= Bubblun.SPAWN_Y)) && levelMap.size() == 26){
            player.setState(State.STANDARD);
            player.setAnimation(Animation.STILL_RIGHT);
            finished = true;
        } else {
            player.setAnimation(Animation.FLOATING);
            player.setState(State.FLOATING);
            if(player.getX() > Bubblun.SPAWN_X) player.setVelX(-Bubblun.VEL_X);
            else if(player.getX() < Bubblun.SPAWN_X) player.setVelX(Bubblun.VEL_X);
            if(levelNumber == 24){
                if(player.getY() > Model.TILE_SIZE*4) player.setVelY(-Model.GAME_GRAVITY);
                else if(player.getY() < Model.TILE_SIZE*4) player.setVelY(Model.GAME_GRAVITY);
            }
            else if(player.getY() < Bubblun.SPAWN_Y) player.setVelY(Model.GAME_GRAVITY);
            player.update();
        }
    }

    /**
     * Sets the enemies to angry when 30 seconds are passed and spawns SkelMonsta
     */
    public void handleHurryUp(){
        if(!hurryUp && System.nanoTime() - levelTime <= SKELMONSTA_SPAWN){
            for(Enemy enemy : enemies){
                enemy.setAnimation(enemy.getAnimation() == Animation.LEFT ? Animation.ANGRY_LEFT: Animation.ANGRY_RIGHT);
                enemy.setState(State.ANGRY);
                Model.getInstance().addSound(SoundEffect.HURRY_UP_ALERT);
                hurriedUp = true;
            }
            hurryUp = true;
        }
        if(System.nanoTime() - levelTime >= SKELMONSTA_SPAWN && hurryUp && !completed){
            enemies.add(new SkelMonsta());
            Model.getInstance().addSound(SoundEffect.SKEL_MONSTA_SPAWN);
            hurryUp = false;
        }

    }

    /**
     * Return next level number. If the player got silver door power-up it returns the secret level
     * @return next level number
     */
    public int getNextLevel(){
        if(player.getPowerUp() == ItemType.SILVER_DOOR) return 100;
        else return levelNumber +1;
    }

    /**
     * @return level map
     */
    public ArrayList<ArrayList<Integer>> getLevelMap() { return levelMap; }

    /**
     * @return ArrayList of normal bubbles
     */
    public ArrayList<BBubble> getBubbles() { return bubbles; }

    /**
     * @return ArrayList of Enemy
     */
    public ArrayList<Enemy> getEnemies() { return enemies; }

    /**
     * @return whether the level is finished or not
     */
    public boolean isFinished() { return finished; }

    /**
     * @return current level number
     */
    public int getLevelNumber() { return levelNumber; }

    /**
     * @return ArrayList of Item
     */
    public ArrayList<Item> getItems() {return items; }

    /**
     * @return score generated when popping bubbles with enemies inside
     */
    public int getHitPoints() {
        return (int)Math.pow(2, (enemyMultiplier -1)) * 1000;
    }

    /**
     * Decrements currEnemyMultiplier and return it. Used in CollisionManager to spawn Item corresponding to bubble with enemy popped
     * @return currEnemyMultiplier decremented by one
     */
    public int decrementEnemyMultiplier() { return currEnemyMultiplier--; }

    /**
     * Sets currEnemyMultiplier to enemyMultiplier if it is less than one (it means that all the score Items are spawned)
     */
    public void setCurrEnemyMultiplier() {
        if (currEnemyMultiplier < 1) currEnemyMultiplier = enemyMultiplier;
    }

    /**
     * @return number of Metro B trains hit in the last level
     */
    public int getTrainsHit(){return trainsHit;}

    /**
     * @return ArrayList of SpecialBubble
     */
    public ArrayList<SpecialBubble> getSpecialBubbles() { return specialBubbles; }

    /**
     * @return ArrayList of Element
     */
    public ArrayList<Element> getElements() { return elements; }

    /**
     * @return ArrayList of Star
     */
    public ArrayList<Star> getStars() { return stars; }

    /**
     * @return level total time
     */
    public long getLevelTime() { return levelTime; }

    /**
     * @return ArrayList of Train
     */
    public ArrayList<Train> getTrains() { return trains; }

    /**
     * Increments number of Metro B trains hit
     */
    public void addTrain() { trainsHit++; }

    /**
     * Sets enemy multiplier. Used when all the bubbles are popped
     * @param enemyMultiplier number of bubbles with enemies are popped
     */
    public void setEnemyMultiplier(int enemyMultiplier) { this.enemyMultiplier = enemyMultiplier; }

    /**
     * Used to show round and ready images
     * @return whether the timer is up or not
     */
    public boolean showRoundInfo(){ return System.nanoTime() - levelTime <= LEVEL_INFO_LENGTH; }


    public long getHurryUpTimer() {
        return (System.nanoTime() - levelTime) - HURRY_UP;
    }
}