package game.model;

import game.model.entities.Bubblun;
import java.io.*;
import java.util.ArrayList;
import java.util.Observable;

/**
 * Class to manage creation of levels and to notify the Observers about the changes
 */
@SuppressWarnings("deprecation")
public class Model extends Observable {
    private static Model instance;
    private final Bubblun player;
    private Level currLevel;
    private int skippedLevels;
    private GameStats playerStats;
    private long gameTime;
    private ArrayList<SoundEffect> soundQueue;

    private boolean ended;

    public final static int ORIGINAL_TILE_SIZE = 24; // 24x24 tiles
    public final static int SCALE = 1;
    public final static int TILE_SIZE = ORIGINAL_TILE_SIZE * SCALE; // 24x24 tile

    public final static int MAX_SCREEN_COL = 32;
    public final static int MAX_SCREEN_ROW = 26;

    public final static int SCORE_HEIGHT = TILE_SIZE * 3;
    public final static int SCREEN_WIDTH = TILE_SIZE * MAX_SCREEN_COL;
    public final static int GAME_SCREEN_HEIGHT = TILE_SIZE * MAX_SCREEN_ROW;
    public static final int SCREEN_HEIGHT = TILE_SIZE * MAX_SCREEN_ROW + SCORE_HEIGHT;

    public static final int GAME_GRAVITY = 3;
    public static final int GAME_LATERAL_SPEED = 3;
    public static final int TRANSITION_SPEED = 4;

    /**
     * Private Model constructor according to the Singleton Design Pattern
     */
    private Model() {
        player = Bubblun.getInstance();
        soundQueue = new ArrayList<>();
        addSound(SoundEffect.MAIN_THEME);
    }

    /**
     * Starts game loop
     */
    public void startGame() {
        currLevel = new Level(1, player);

        gameTime = System.nanoTime();
    }

    /**
     * @return the Model instance (Singleton Design Pattern)
     */
    public static Model getInstance() {
        if (instance == null) instance = new Model();
        return instance;
    }

    /**
     * Updates the player's position and hitbox, and notifies Player's observers.
     */
    public void update() {
        if(currLevel.getLevelNumber() != 25) {
            if(currLevel.isFinished()){
                currLevel = new Level(currLevel.getNextLevel(), currLevel.getLevelTime(), currLevel.getEnemies());
                if(skippedLevels-1 > 0){
                    currLevel.setCompleted(true);
                    skippedLevels--;
                }
            }else currLevel.update();
        } else {
            currLevel.updateLastLevel();
        }

        setChanged();
        notifyObservers();
        soundQueue.clear();
    }

    /**
     * According to user's input updates player's states
     * @param vel whether the user clicked right or left arrow
     * @param jump whether the user clicked Z or not
     * @param shoot whether the user clicked X or not
     */
    public void updatePlayer(int vel, boolean jump, boolean shoot){
        player.setVelX(vel);
        if(jump){
            player.setState(State.JUMPING);
            player.setJumping(true);
            addSound(SoundEffect.JUMP);
        }
        if(shoot){
            player.setShooting(true);
            currLevel.getBubbles().add(player.shootBubble());
            addSound(SoundEffect.SHOOT);
        }
        player.updateSprite(vel, jump, shoot);
    }

    /**
     * @return current level instance
     */
    public Level getLevel(){ return currLevel; }

    /**
     * @return Bubblun instance
     */
    public Bubblun getPlayer() { return player; }

    /**
     * Called when the player hits an umbrella power-up. Used to decide how many levels to skip
     * @param levelsSkipped number of levels to skip
     */
    public void setLevelsSkipped(int levelsSkipped){ this.skippedLevels = levelsSkipped;}

    /**
     * @return player stats
     */
    public GameStats getPlayerStats() { return playerStats; }

    /**
     * Serializes game stats into <code>game.stats</code> file
     * @param gameStats ArrayList of GameStats to serialize
     */
    public void serializeGameStats(ArrayList<GameStats> gameStats){
        try{
            FileOutputStream fos = new FileOutputStream(System.getProperty("user.dir")+"/src/game/model/game.stats");
            ObjectOutputStream oos = new ObjectOutputStream(fos);

            oos.writeObject(gameStats);
            oos.close();

        }catch(IOException e) {e.printStackTrace();}

    }

    /**
     * Deserializes game stats from <code>game.stats</code> file
     * @return ArrayList of GameStats deserialized
     */
    public ArrayList<GameStats> deserializeGameStats(){
        ArrayList<GameStats> stats = new ArrayList<>();

        try {
            FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"/src/game/model/game.stats");
            ObjectInputStream ois = new ObjectInputStream(fis);

            stats = (ArrayList<GameStats>) ois.readObject();

            ois.close();
        } catch(ClassNotFoundException | IOException e) {e.printStackTrace();}

        return stats;
    }

    /**
     * Sets ended
     * @param ended whether the game if ended or not
     */
    public void setEnded(boolean ended){ this.ended = ended; }

    /**
     * @return whether the game is ended or not
     */
    public boolean isEnded() { return ended; }

    /**
     * Sets the leaderboard and creates a new instance of GameStats that assigns to the current level and to the player. Called in the Controller's constructor
     * @param playerName used to create GameStats' instance
     * @param avatar used to create GameStats' instance
     */
    public void setPlayerStats(String playerName, String avatar) {
        GameStats.setLeaderboard();
        playerStats = new GameStats(playerName, avatar);
        player.setPlayerStats(playerStats);
        currLevel.setPlayerStats(playerStats);
    }

    /**
     * @return total game time
     */
    public long getGameTime() { return System.nanoTime()-gameTime; }
    public ArrayList<SoundEffect> getSoundQueue() { return soundQueue; }
    public void addSound(SoundEffect sf){ soundQueue.add(sf);}


}
