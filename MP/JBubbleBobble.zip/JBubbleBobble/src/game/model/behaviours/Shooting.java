package game.model.behaviours;

import game.model.entities.bubbles.Bubble;

/**
 * Interface that describes the shooting behaviour shared by some Enemies.
 */
public interface Shooting  <T extends  Bubble>{
    /**
     * Method to get the Enemy's bubble.
     */
    T getBubble();

    /**
     * Method for an Enemy to try shooting.
     */
    void tryShooting();

}
