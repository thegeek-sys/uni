package game.model.behaviours;

import game.model.entities.bubbles.BBubble;

/**
 * Implementation of the Strategy Pattern.
 * A PopBehaviour defines the way a BBubble acts once it's popped.
 */
public interface PopBehaviour {

    /**
     * The pop method that needs to be set according to the Strategy Pattern.
     */
    void pop(BBubble bubble);

}
