package game.model.behaviours;

import game.model.State;
import game.model.entities.bubbles.BBubble;

/**
 * Implementation of the Strategy Pattern.
 * One of two possible PopBehaviours. A Bubble exhibits this behaviour when
 * it gets popped while it has an Enemy inside it.
 */
public class PopWithEnemy implements PopBehaviour {

    /**
     * Implementation of the pop method from the "PopBehaviour" interface.
     * Describes a BBubble's behaviour when popping with an enemy inside it.
     */
    @Override
    public void pop(BBubble bubble) {
        bubble.getAbsordbedEnemy().setHealthState(State.DYING);

        bubble.setState(State.POPPED);

        bubble.setSpawning(false);
        bubble.setSpawningTimer(System.nanoTime() - (bubble.getPoppingLength() - BBubble.EXPLODING2_LENGTH));
    }

}
