package game.model;

/**
 * Enumeration that defines all types of sound effects used in the game
 */
public enum SoundEffect {
    ARCADE_START(1f),
    MAIN_THEME(0.5f), HURRY_UP_THEME(0.5f), HURRY_UP_ALERT(1f), SKEL_MONSTA_SPAWN(1f), SKEL_MONSTA_THEME(0.5f),
    PICK_UP_ITEM(1f), PICK_UP_SPECIAL_ITEM(1f), PICK_UP_30LODE(1f),
    JUMP(1f), SHOOT(1f), POP_BUBBLES(1f),
    INVADER_MISSILE_HIT(1f);

    private float volume;

    /**
     * Constructor
     * @param volume volume
     */
    SoundEffect(float volume) { this.volume = volume; }

    /**
     * @return sound effect volume
     */
    public float getVolume() { return volume; }

}
