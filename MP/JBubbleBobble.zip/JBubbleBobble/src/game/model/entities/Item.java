package game.model.entities;

import game.model.Model;
import game.model.State;

import java.awt.*;
import java.io.Serializable;

/**
 * Class that defines game items
 */
public class Item extends Entity{
    private ItemType type;

    private long expirationTimer;
    private long upTimer;
    private long delay;
    private long timer;

    private int spawnY;

    private boolean big;

    public static final long POINT_ANIMATION_LENGTH = 1_000_000_000L;
    public static final long EXPIRATION = 12_000_000_000L;

    /**
     * Constructor. calls super with parameter values
     * @param x x coordinate
     * @param y y coordinate
     * @param type item type
     */
    public Item(int x, int y, ItemType type){
        super(x +6 , y+12, 0, 0, new Rectangle(x, y, Model.TILE_SIZE, Model.TILE_SIZE));
        this.type = type;
        state = State.STANDARD;
        expirationTimer = System.nanoTime();
    }

    /**
     * Constructor. Calls super with parameter values, adds a spawn y coordinate where the item will stop landing
     * @param x x coordinate
     * @param y y coordinate
     * @param spawnY spawn y coodinate
     * @param type item type
     */
    public Item(int x, int y, int spawnY, ItemType type){
        super(x, y, 0, Model.GAME_GRAVITY, new Rectangle(x, y, Model.TILE_SIZE, Model.TILE_SIZE));
        this.spawnY = spawnY - (int)(Model.TILE_SIZE*1.5);
        this.type = type;
        state = State.STANDARD;
        expirationTimer = System.nanoTime();
    }

    /**
     * Constructor. Used to add items into game levels
     * @param x x coordinate
     * @param spawnY spawn y coordinate
     * @param type item type
     * @param delay spawn delay
     */
    public Item(int x, int spawnY, ItemType type, long delay){
        super(x, -Model.TILE_SIZE*2, 0, Model.GAME_GRAVITY, new Rectangle(x, -Model.TILE_SIZE*2, Model.TILE_SIZE, Model.TILE_SIZE));
        this.spawnY = spawnY - (int)(Model.TILE_SIZE*1.5);
        this.type = type;
        this.delay = delay;
        state = State.STANDARD;
    }

    /**
     * Updates item's position according to velocity, handles spawn delay time
     */
    public void update(){
        if (System.nanoTime()-timer>=delay) {
            if(state == State.DEAD || spawnY > y) y += velY;
            if (spawnY <= y && spawnY != 0) expirationTimer = System.nanoTime();
            updateHitbox();
        }
    }

    /**
     * @return whether an item's points animation is over
     */
    public boolean isUp() {
        return (System.nanoTime() - upTimer) >= (POINT_ANIMATION_LENGTH);
    }

    /**
     * Turns item into its points animation
     */
    public void showValue(){
        state = State.DEAD;
        upTimer = expirationTimer = System.nanoTime();
        velY = -Model.GAME_GRAVITY/2;
    }

    /**
     * @return whether an item needs to despawn
     */
    public boolean isExpired(){
        return expirationTimer!=0 && (System.nanoTime() - expirationTimer) >= EXPIRATION;
    }

    /**
     * @return item type
     */
    public ItemType getType() { return type; }

    /**
     * @return if the item's points animation needs to be big
     */
    public boolean isBig() { return big; }

    /**
     * sets the item's point animation size
     * @param big whether the item's points animation needs to be big
     */
    public void setBig(boolean big) { this.big = big; }

    /**
     * Starts timer to handle spawn delay time
     */
    public void startTimer(){
        timer = System.nanoTime();
    }
}


