package game.model.entities.bubbles.special_bubbles;

import game.model.Animation;
import game.model.Model;
import game.model.State;
import game.model.entities.bubbles.Element;
import game.model.entities.opps.Enemy;

import java.awt.*;
import java.util.ArrayList;

/**
 * Element spawned when WaterBubble is popped
 */
public class WaterFlow extends Element {
    private final ArrayList<WaterBlock> flow;
    public static final int MAX_LENGTH = 10;
    public static final long FALL_INTERVAL = 70_000_000L;
    private int swimmingVictims;
    private long timer;

    /**
     * WaterFlow's constructor. It spawns a WaterBlock
     * @param x x coordinate of where WaterBubble is popped
     * @param y y coordinate of where WaterBubble is popped
     */
    public WaterFlow(int x, int y) {
        flow = new ArrayList<>();
        flow.add(new WaterBlock(x ,y));
    }

    /**
     * Everytime the timer expires a new WaterBlock is added to the flow
     * @param x x coordinate of the WaterBlock
     * @param y y coordinate of the WaterBlock
     * @param animation direction of the WaterBlock
     */
    public void addWater(int x, int y, Animation animation){
        if (timer == 0) {
            timer = System.nanoTime();
            flow.add(new WaterBlock(x, y, animation));
        }
        else if (System.nanoTime() - timer >= FALL_INTERVAL) {
            timer = 0;
        }
        update();
    }

    /**
     * Updates last and second last WaterBlock direction. Removes the first one of the ArrayList if MAX_LENGTH is reached
     */
    @Override
    public void update(){
        //handle update of the spiking block, before adding the new block
        WaterBlock firstBlock = flow.getFirst();
        if(flow.size() > 1){
            WaterBlock secondBlock = flow.get(1);
            if(secondBlock.getAnimation() == Animation.WATER_VERTICAL || secondBlock.getAnimation() == Animation.WATER_DOWN || secondBlock.getAnimation() == Animation.WATER_DOWN_LEFT || secondBlock.getAnimation() == Animation.WATER_DOWN_RIGHT) firstBlock.setAnimation(Animation.WATER_UP);
            else if(secondBlock.getAnimation() == Animation.WATER_LEFT || secondBlock.getAnimation() == Animation.WATER_HORIZONTAL_LEFT) secondBlock.setAnimation(Animation.WATER_RIGHT);
            else if (secondBlock.getAnimation() == Animation.WATER_UP_RIGHT || secondBlock.getAnimation() == Animation.WATER_HORIZONTAL_RIGHT) firstBlock.setAnimation(Animation.WATER_LEFT);
        }

        WaterBlock oldLastBlock = flow.get(flow.size() - 2);
        if(oldLastBlock.getAnimation() == Animation.WATER_LEFT) oldLastBlock.setAnimation(Animation.WATER_HORIZONTAL_LEFT);
        else if (oldLastBlock.getAnimation() == Animation.WATER_RIGHT) oldLastBlock.setAnimation(Animation.WATER_HORIZONTAL_RIGHT);
        else if (oldLastBlock.getAnimation() == Animation.WATER_DOWN) oldLastBlock.setAnimation(Animation.WATER_VERTICAL);
        if(flow.getFirst().getY() > Model.SCREEN_HEIGHT){
            flow.clear();

        }
        if(flow.size() > MAX_LENGTH) flow.removeFirst();

    }

    /**
     * @return number of enemies killed by WaterBlock
     */
    public int getSwimmingVictims() {return swimmingVictims; }

    /**
     * @return ArrayList of WaterBlock
     */
    @Override
    public ArrayList<WaterBlock> getContent() {
        return flow;
    }

    /**
     * Called when an Enemy hits a WaterBlock
     * @param enemy Enemy that hit the FireBlock
     */
    @Override
    public void handleCollision(Enemy enemy) {
        if (enemy.getState() != State.SWIMMING && enemy.getHealthState() != State.DEAD) {
            swimmingVictims++;
            enemy.setJumping(false); //in case the water catches it while jumping
            enemy.setState(State.SWIMMING);
            enemy.setHealthState(State.DEAD);
            enemy.setAnimation(Animation.DYING);
        }
        enemy.setX(flow.get(Math.min(flow.size() - 1, 6)).getX());
        enemy.setY(flow.get(Math.min(flow.size() - 1, 6)).getY() - Model.TILE_SIZE);
    }

    /**
     * element contained inside Blaze
     */
    public class WaterBlock extends ElementContained{

        /**
         * WaterBlock constructor
         * @param x x coordinate
         * @param y y coordinate
         */
        public WaterBlock(int x, int y) {
            super(x, y, 0,0, new Rectangle(x, y, Model.TILE_SIZE, Model.TILE_SIZE));
            animation = Animation.WATER_DOWN;
        }

        /**
         * WaterBlock constructor
         * @param x x coordinate
         * @param y y coordinate
         * @param animation animation to set
         */
        public WaterBlock(int x, int y, Animation animation) {
            super(x, y, 0,0, new Rectangle(x, y, Model.TILE_SIZE, Model.TILE_SIZE));
            this.animation = animation;
        }

    }

}
