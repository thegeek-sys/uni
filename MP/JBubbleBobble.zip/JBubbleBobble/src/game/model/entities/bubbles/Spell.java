package game.model.entities.bubbles;

import game.model.Animation;
import game.model.Model;
import game.model.State;

import java.awt.*;

/**
 * Bubble blown by Mighta
 */
public class Spell extends Bubble{
    private final int endX;
    private long poppingTimer;
    public static final long POPPING_LENGTH = 250_000_000;

    /**
     * Spell's constructor
     * @param x x coordinate
     * @param y y coordinate
     * @param endX where the Spell collides with a block
     */
    public Spell(int x, int y, int endX){
        super(x, y,( x > endX )? -Model.GAME_GRAVITY - 2: Model.GAME_GRAVITY + 2, 0, new Rectangle(x, y, Model.TILE_SIZE*2, Model.TILE_SIZE*2));
        this.endX = endX;
        state = State.FLOATING;
        animation = Animation.FLOATING;
    }

    /**
     * Manages the updates for state, animation and x coordinate.
     */
    @Override
    public void update() {
        if (poppingTimer != 0 && System.nanoTime()-poppingTimer >= POPPING_LENGTH){
            state = State.DEAD;

        }
        if(((velX > 0 && x >= endX) || (velX < 0 && x<=endX)) && poppingTimer == 0) pop();
        else if(animation != Animation.POPPED) moveX(velX);
    }

    /**
     * Sets the animation to POPPED and start the animation before disappearing
     */
    @Override
    public void pop(){
        if(animation != Animation.POPPED){
            animation = Animation.POPPED;
            poppingTimer = System.nanoTime();
        }
    }

}
