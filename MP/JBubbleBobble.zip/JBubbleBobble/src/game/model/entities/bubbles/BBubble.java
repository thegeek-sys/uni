package game.model.entities.bubbles;

import game.model.Animation;
import game.model.Model;
import game.model.State;
import game.model.behaviours.PopBehaviour;
import game.model.behaviours.PopWithEnemy;
import game.model.behaviours.PopWithoutEnemy;
import game.model.entities.opps.Enemy;

/**
 * The kind of Bubble blown by Bubblun
 */
public class BBubble extends Bubble {

    private PopBehaviour popStrategy;
    private Enemy absordbedEnemy;
    private final long id;
    private static long numBubbles = 0;

    private boolean spawning;
    private long spawningTimer;

    private final int speedMultiplier;

    public static final long SPAWNING_LENGTH = 900_000_000L;
    public static final long FLOATING_LENGTH  = 2_500_000_000L;
    public static final long EXPLODING1_LENGTH = 1_500_000_000L;
    public static final long EXPLODING2_LENGTH = 500_000_000L;

    public static final long STANDARD_POPPING_LENGTH = 7_500_000_000L;
    public static final long FURTHER_POPPING_LENGTH = 11_500_000_000L;

    private final long poppingLength;

    /**
     * BBubble con constructor which uses an id to make the bubbles have different animations and a popStrategy due to the implementation of the Strategy Pattern
     * @param x x coordinate
     * @param y y coordinate
     * @param velX velocity on x-axis
     * @param further whether the player has the power-up to make the bubbles go further
     * @param faster whether the player has the power-up to make the bubbles go faster
     */
    public BBubble(int x, int y, int velX, boolean further, boolean faster) {
        super(x, y, velX, 0);
        spawningTimer = System.nanoTime();
        poppingLength = further ? FURTHER_POPPING_LENGTH : STANDARD_POPPING_LENGTH;
        spawning = true;
        animation = Animation.SPAWNING;
        id = numBubbles++;
        speedMultiplier = faster ? 2 : 1;
        popStrategy = new PopWithoutEnemy();
    }

    /**
     * Updates BBubble animation to make it firstly blink red and orange, then red and lastly pop. This decision is took using timers
     */
    public void updateSprite() {
        long timeElapsed = System.nanoTime() - spawningTimer;
        if (timeElapsed >= poppingLength-FLOATING_LENGTH) {
            animation = switch (animation.toString().substring(0, 3)) {
                case "ZEN" ->
                        (timeElapsed >= BBubble.this.poppingLength-EXPLODING1_LENGTH) ? Animation.ZENCHAN_EXPLODING2 : Animation.ZENCHAN_EXPLODING1;
                case "MON" ->
                        (timeElapsed >= poppingLength-EXPLODING1_LENGTH) ? Animation.MONSTA_EXPLODING2 : Animation.MONSTA_EXPLODING1;
                case "BAN" ->
                        (timeElapsed >= poppingLength-EXPLODING1_LENGTH) ? Animation.BANEBOU_EXPLODING2 : Animation.BANEBOU_EXPLODING1;
                case "INV" ->
                        (timeElapsed >= poppingLength-EXPLODING1_LENGTH) ? Animation.INVADER_EXPLODING2 : Animation.INVADER_EXPLODING1;
                case "MIG" ->
                        (timeElapsed >= poppingLength-EXPLODING1_LENGTH) ? Animation.MIGHTA_EXPLODING2 : Animation.MIGHTA_EXPLODING1;
                case "HID" ->
                        (timeElapsed >= poppingLength-EXPLODING1_LENGTH) ? Animation.HIDEGONS_EXPLODING2 : Animation.HIDEGONS_EXPLODING1;
                default -> (timeElapsed >= poppingLength-EXPLODING1_LENGTH) ? Animation.EXPLODING2 : Animation.EXPLODING1;
            };
            if (timeElapsed >= poppingLength-EXPLODING2_LENGTH) {
                if (timeElapsed >= poppingLength) state = State.POPPED;
                else if(animation == Animation.EXPLODING2) animation = Animation.POPPED;
            }
        }
    }

    /**
     * Used to update sprite and hitbox of the BBubble
     */
    @Override
    public void update(){
        updateSprite();
        if(spawning) if(System.nanoTime() - spawningTimer >= SPAWNING_LENGTH) setSpawning(false);
        else updateSprite();
        updateHitbox();
    }

    /**
     * Used to update BBubble's hitbox
     */
    @Override
    public void updateHitbox(){
        hitbox.x = (x + Model.TILE_SIZE/2+1);
        hitbox.y = (y + Model.TILE_SIZE/2+1);
    }

    /**
     * Make BBubble move on y coordinate
     */
    public void moveY(){
        if (animation != Animation.POPPED) y += velY * speedMultiplier;
    }

    /**
     * Make BBubble move on x coordinate
     */
    public void moveX() {
        if (animation != Animation.POPPED) x += velX * speedMultiplier;
    }

    /**
     * @return bubble's id
     */
    public long getId(){ return id; }

    /**
     * @return whether the BBubble is spawning or not
     */
    public boolean isSpawning() { return spawning; }

    /**
     * When a BBubble while spawning hits an Enemy, absorbedEnemy is set to that enemy. The popStrategy is changed to PopWithEnemy due to Strategy Pattern implementation. Changes the animation
     * @param e Enemy hit
     */
    public void addEnemy(Enemy e){
        popStrategy = new PopWithEnemy();
        spawningTimer = System.nanoTime();
        absordbedEnemy = e;
        setSpawning(false);
        animation = switch(e.getClass().getSimpleName()){
            case "ZenChan" -> Animation.ZENCHAN;
            case "Mighta" -> Animation.MIGHTA;
            case "Invader" -> Animation.INVADER;
            case "Hidegons" -> Animation.HIDEGONS;
            case "Banebou" -> Animation.BANEBOU;
            case "Monsta" -> Animation.MONSTA;
            default -> null;
        };
        velY = -Model.GAME_GRAVITY;
    }

    /**
     * @return enemy hit
     */
    public Enemy getAbsordbedEnemy() { return absordbedEnemy; }

    /**
     * Calls popStrategy pop method in accordance with Strategy Pattern
     */
    @Override
    public void pop(){
        popStrategy.pop(this);
    }

    /**
     * Used to make a BBubble stop moving on x coordinate and make it float
     * @param set whether the BBubble is spawning or not
     */
    public void setSpawning(boolean set){
        if(!set && animation == Animation.SPAWNING){
            spawning = false;
            animation = Animation.FLOATING;
            velY = -Model.GAME_GRAVITY;
            velX = 0;
        }
    }

    /**
     * Two Bbubbles are equal if their id is the same.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || !(this.getClass().equals(o.getClass()))) return false;
        BBubble bubble = (BBubble)o;
        return bubble.id == id;
    }

    /**
     * @return speed multiplier (used for power-ups)
     */
    public int getSpeedMultiplier(){ return speedMultiplier; }

    /**
     * Sets the spawning timer (used for Strategy Pattern)
     * @param spawningTimer spawning timer to set
     */
    public void setSpawningTimer(long spawningTimer) { this.spawningTimer = spawningTimer; }

    /**
     * @return after how much time the BBubble has to pop
     */
    public long getPoppingLength() { return poppingLength; }
}
