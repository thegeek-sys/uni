package game.model.entities.bubbles;

import game.model.entities.bubbles.special_bubbles.ElementContained;
import game.model.entities.opps.Enemy;

import java.util.ArrayList;

/**
 * Abstract class describing general Elements behaviours
 */
public abstract class Element <T extends ElementContained>  {

    /**
     * Implemented by son classes
     */
    public abstract void update();

    /**
     * Implemented by son classes
     */
    public abstract ArrayList<T> getContent();

    /**
     * Implemented by son classes
     */
    public abstract void handleCollision(Enemy enemy);

}