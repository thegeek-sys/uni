package game.model.entities.bubbles.special_bubbles;

import game.model.Model;
import game.model.State;
import game.model.entities.bubbles.Bubble;
import game.model.entities.bubbles.Element;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Abstract class describing general SpecialBubble behaviours
 */
public abstract class SpecialBubble extends Bubble implements Serializable {
    private final long delay;
    private long timer;

    /**
     * SpecialBubble constructor that deices if the bubble will start from the bottom and got up or viceversa
     * @param delay time to wait before appearing inside a level
     * @param x x coordinate of where to spawn
     */
    public SpecialBubble(long delay, int x) {
        super(x, -Model.TILE_SIZE*2, 0, 1);
        double rnd = Math.random();
        if (rnd >= 0.69) {
            y = Model.GAME_SCREEN_HEIGHT;
            velY = -1;
        }
        this.delay = delay;
        state = State.STANDARD;
    }

    /**
     * Override of update method
     */
    @Override
    public void update() {
        if (System.nanoTime()-timer>=delay) {
            y += velY;
            updateHitbox();
        }
    }

    /**
     * Starts the spawn timer
     */
    public void startTimer() {timer = System.nanoTime();}

    /**
     * Override of pop method
     */
    @Override
    public void pop(){}

    /**
     * Implemented by the single special bubbles
     * @param elements ArrayList of Element
     */
    public void pop(ArrayList<Element> elements){}

}
