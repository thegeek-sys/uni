package game.model.entities.bubbles.special_bubbles;

import game.model.Animation;
import game.model.Model;
import game.model.State;
import game.model.entities.Bubblun;
import game.model.entities.bubbles.Element;
import game.model.entities.opps.Enemy;

import java.awt.*;
import java.util.ArrayList;

/**
 * Element spawned when LightningBubble is popped
 */
public class Storm extends Element {
    private final ArrayList<Lightning> flow;

    /**
     * Storm's constructor. It spawns a Lightning
     * @param x x coordinate of where LightningBubble is popped
     * @param y y coordinate of where LightningBubble is popped
     */
    public Storm(int x, int y) {
        flow = new ArrayList<>();
        int spawnX = Bubblun.getInstance().getAnimation().toString().endsWith("LEFT") ? Model.SCREEN_WIDTH+Model.TILE_SIZE : -Model.TILE_SIZE;
        flow.add(new Lightning(x,y, spawnX));
    }

    /**
     * If the Lightning is out of the screen it gets removed from the ArrayList
     */
    @Override
    public void update() {
        for(int i=flow.size()-1; i>-1; i--) {
            Lightning lightning = flow.get(i);
            //TODO call new static methods when refactored
            if(lightning.getX() < -1 || lightning.getX() > Model.SCREEN_WIDTH){
                flow.remove(lightning);
            }
        }
    }

    /**
     * @return ArrayList of Lightning
     */
    @Override
    public ArrayList<Lightning> getContent() {
        return flow;
    }

    /**
     * Called when an Enemy hits a Lightning
     * @param enemy Enemy that hit the Lightning
     */
    @Override
    public void handleCollision(Enemy enemy) {
        Model.getInstance().getPlayerStats().addEnemiesStruck();
        flow.getFirst().handleStrikes();
        enemy.setHealthState(State.DYING);
        enemy.setState(State.STRUCK);
    }

    /**
     * element contained inside Storm
     */
    public class Lightning extends ElementContained{
        private final int spawnX;
        private long strikeTimer;
        public static final long STRIKE_LENGTH = 1_000_000_000L;

        /**
         * Lightning constructor
         * @param x x coordinate
         * @param y y coordinate
         * @param spawnX towards where the Lightning has to go
         */
        public Lightning(int x, int y, int spawnX) {
            super(x, y, 0,0, new Rectangle(x, y, (int)(Model.TILE_SIZE*1.5), (int)(Model.TILE_SIZE*1.5)));
            this.spawnX = spawnX;
            animation = Animation.LIGHTNING_STORM;
        }

        /**
         * Updates Lightning.
         * <ul>
         *     <li>If the strikeTimer is finished, resets the state to State.STANDARD and changes the animation to make it go towards spawnX</li>
         *     <li>If the timer is finished, the Lightning goes towards the spawnX</li>
         * </ul>
         */
        public void update() {
            if(state == State.STRUCK && (System.nanoTime() - strikeTimer) >= STRIKE_LENGTH) {
                state = State.STANDARD;
                animation = Animation.LIGHTNING_STORM;
            }
            else if(state == State.STRUCK) return;

            if (x<spawnX) {
                x+=Model.GAME_LATERAL_SPEED*2;
                updateHitbox();
            }
            else if (x>spawnX){
                x-=Model.GAME_LATERAL_SPEED*2;
                updateHitbox();
            }
        }

        /**
         * As soon as the Lightning hits an enemy, it sets its own state to STRUCK to stay still. A timer starts.
         * When the timer ends, it starts moving again
         */
        public void handleStrikes(){
            if(strikeTimer == 0){
                state = State.STRUCK;
                animation = Animation.LIGHTNING_STRUCK;
                strikeTimer = System.nanoTime();
            }
        }
    }
}
