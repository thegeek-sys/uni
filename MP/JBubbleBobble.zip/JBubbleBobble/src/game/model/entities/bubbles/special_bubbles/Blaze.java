package game.model.entities.bubbles.special_bubbles;

import game.model.Animation;
import game.model.CollisionHandler;
import game.model.Model;
import game.model.State;
import game.model.entities.bubbles.Element;
import game.model.entities.opps.Enemy;

import java.awt.*;
import java.util.ArrayList;

/**
 * Element spawned when FireBubble is popped
 */
public class Blaze extends Element {
    private final ArrayList<FireBlock> flow;
    public static final long EXTINGUISH_TIMEOUT = 5_000_000_000L;

    /**
     * Blaze's constructor. It spawns a random number of FireBlock and calculates where to land through the "findSpawnY" static method in CollisionHandler
     * @param x x coordinate of where FireBubble is popped
     * @param y y coordinate of where FireBubble is popped
     */
    public Blaze(int x, int y) {
        flow = new ArrayList<>();
        int blockAmt = (int)(Math.random() * (6 - 1) + 1);

        for(int i = 0; i<blockAmt; i++){
            int spawnY = CollisionHandler.findSpawnY(x+(i*Model.TILE_SIZE), y);
            flow.add(new Blaze.FireBlock(x+(i*Model.TILE_SIZE),y, spawnY));
        }
    }

    /**
     * If the FireBlock needs to be extinguished, it gets removed from the ArrayList
     */
    @Override
    public void update() {
        for(int i=flow.size()-1; i>-1; i--) {
            if (System.nanoTime()-flow.get(i).extinguishTimer >= EXTINGUISH_TIMEOUT && flow.get(i).extinguishTimer != 0) {
                flow.remove(flow.get(i));
            }
        }
    }

    /**
     * @return ArrayList of FireBlock
     */
    @Override
    public ArrayList<FireBlock> getContent() { return flow; }

    /**
     * Called when an Enemy hits a FireBlock
     * @param enemy Enemy that hit the FireBlock
     */
    @Override
    public void handleCollision(Enemy enemy) {
        enemy.setHealthState(State.DYING);
        if (enemy.getState()!=State.SWIMMING) enemy.setState(State.BURNT);
    }

    /**
     * element contained inside Blaze
     */
    public class FireBlock extends ElementContained {
        private final int spawnY;
        private long extinguishTimer;

        /**
         * FireBlock constructor
         * @param x x coordinate
         * @param y y coordinate
         * @param spawnY landing y coordinate
         */
        public FireBlock(int x, int y, int spawnY) {
            super(x, y, 0,0, new Rectangle(x, y, Model.TILE_SIZE, Model.TILE_SIZE));
            this.spawnY = spawnY-Model.TILE_SIZE;
            animation = Animation.FIRE_DROPPING;
        }

        /**
         * Updates FireBlock.
         * <ul>
         *     <li>Updates y while FireBlock hasn't reached landing destination</li>
         *     <li>When FireBlock has reached the ground, the extinguish timer starts </li>
         * </ul>
         */
        public void update() {
            if (spawnY>y) {
                y += Model.GAME_GRAVITY;
                updateHitbox();
            }
            else if (extinguishTimer == 0) {
                animation = Animation.FIRE_GROUND;
                extinguishTimer = System.nanoTime();
            }
        }

    }

}
