package game.model.entities.bubbles.special_bubbles;

import game.model.Animation;
import game.model.Model;
import game.model.entities.bubbles.Element;

import java.util.ArrayList;

/**
 * A SpecialBubble that instances a Blaze when popped
 */
public class FireBubble extends SpecialBubble{

    /**
     * FireBubble constructor.
     * @param delay time to wait before appearing inside a level
     * @param x x coordinate of where to spawn
     */
    public FireBubble(long delay, int x){
        super(delay, x);
        animation = Animation.FIRE;
    }

    /**
     * Called when Bubblun hits a FireBubble
     * @param elements ArrayList of Element to which the new Blaze is added
     */
    @Override
    public void pop(ArrayList<Element> elements) {
        Model.getInstance().getPlayerStats().addScore(9000);
        elements.add(new Blaze(x + x%Model.TILE_SIZE, y + y%Model.TILE_SIZE));
    }

}
