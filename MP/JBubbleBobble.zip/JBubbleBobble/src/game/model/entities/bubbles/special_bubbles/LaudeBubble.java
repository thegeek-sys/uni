package game.model.entities.bubbles.special_bubbles;

import game.model.Model;

/**
 * A SpecialBubble that gives Bubblun one extra life when all 6 different LaudeBubble are collected (forming "30LODE")
 */
public class LaudeBubble extends SpecialBubble {
    private final LaudeType letter;

    /**
     * LaudeBubble constructor.
     * @param delay time to wait before appearing inside a level
     * @param x x coordinate of where to spawn
     */
    public LaudeBubble(long delay, int x){
        super(delay, x);
        letter = LaudeType.getRandom();
    }

    /**
     * Called when Bubblun collides with it. It adds to the player's stats the letter inside it. Used to spawn power-ups
     */
    @Override
    public void pop() {Model.getInstance().getPlayerStats().addLaude(letter);}

    /**
     * @return LaudeType inside it
     */
    public LaudeType getLetter(){return letter;}

}
