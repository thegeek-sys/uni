package game.model.entities.bubbles.special_bubbles;

import game.model.entities.Entity;

import java.awt.*;

/**
 * Abstract class describing general behaviours of the inner class of each Element (Blaze, WaterFlow and Storm)
 */
public abstract class ElementContained extends Entity {
    /**
     * ElementContained constructor.
     * @param x x coordinate
     * @param y y coordinate
     * @param velX velocity on x-axis
     * @param velY velocity on y-axis
     * @param hitbox hitbox of the ElementContained
     */
    public ElementContained(int x, int y, int velX, int velY, Rectangle hitbox) {
        super(x, y, velX, velY, hitbox);
    }

}
