package game.model.entities.bubbles.special_bubbles;

import game.model.Animation;
import game.model.Model;
import game.model.entities.bubbles.Element;

import java.util.ArrayList;

/**
 * A SpecialBubble that instances WaterFlow when popped
 */
public class WaterBubble extends SpecialBubble{

    /**
     * WaterBubble constructor.
     * @param delay time to wait before appearing inside a level
     * @param x x coordinate of where to spawn
     */
    public WaterBubble(long delay, int x){
        super(delay, x);
        y = -Model.TILE_SIZE*2;
        velY = 1;
        animation = Animation.WATER;
    }

    /**
     * Called when Bubblun hit a WaterBubble
     * @param elements ArrayList of Element where the new WaterFlow is added
     */
    @Override
    public void pop(ArrayList<Element> elements) {
        //power-up count:
        Model.getInstance().getPlayerStats().addWaterBubblesPopped();
        Model.getInstance().getPlayerStats().addScore(7000);
        elements.add(new WaterFlow(x - x%Model.TILE_SIZE, y - y%Model.TILE_SIZE));
    }
}
