package game.model.entities.bubbles;

import game.model.Animation;
import game.model.Model;
import game.model.State;

import java.awt.*;

/**
 * Bubble blown by Invader
 */
public class Zap extends Bubble {
    private long poppingTimer;
    public static final long POPPING_LENGTH = 250_000_000;

    /**
     * Zap's constructor
     * @param x x coordinate
     * @param y y coordinate
     */
    public Zap(int x, int y){
        super(x, y,0,Model.GAME_GRAVITY*3, new Rectangle(x, y, Model.TILE_SIZE*2, Model.TILE_SIZE*2));;
        state = State.FLOATING;
        animation = Animation.FLOATING;
    }

    /**
     * Manages the updates for state, animation and y coordinate.
     */
    @Override
    public void update() {
        if (poppingTimer != 0 && System.nanoTime()-poppingTimer >= POPPING_LENGTH){
            state = State.DEAD;
        }

        if(y > Model.SCREEN_HEIGHT - 5*Model.TILE_SIZE && poppingTimer == 0) pop();
        else if(animation != Animation.POPPED) moveY(velY);
    }

    /**
     * Sets the animation to POPPED and start the animation before disappearing
     */
    @Override
    public void pop(){
        if(animation != Animation.POPPED){
            animation = Animation.POPPED;
            poppingTimer = System.nanoTime();
        }
    }

}
