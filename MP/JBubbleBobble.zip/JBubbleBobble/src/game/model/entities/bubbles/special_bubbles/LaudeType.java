package game.model.entities.bubbles.special_bubbles;

import game.model.entities.ItemType;

/**
 * Contained as field in LaudeBubble. Needed to spawn power-ups and to gain lives.
 */
public enum LaudeType {

    THREE(0), ZERO(1), L(2), O(3), D(4), E(5);

    int id;

    /**
     * LaudeType constructor
     * @param id id associated to each LaudeType
     */
    LaudeType(int id) { this.id = id; }

    /**
     * @return id of the LaudeType
     */
    public int getId(){return id;}

    /**
     * Used in LaudeBubble constructor
     * @return random LaudeType
     */
    public static LaudeType getRandom(){
    int i = (int)(Math.round(Math.random()*(5)));
        return switch(i){
            case 0 -> THREE;
            case 1-> ZERO;
            case 2 -> L;
            case 3 -> O;
            case 4 -> D;
            case 5 -> E;
            default -> null;
        };
    }

    /**
     * Gets corresponding LaudeType from a given id
     * @param id id to check
     * @return corresponding LaudeType
     */
    public static LaudeType getLetter(int id) {
        for (LaudeType letter : values()){
            if(letter.id == id){
                return letter;
            }
        }
        return null;
    }

    /**
     * Used to spawn score items. Chooses what ItemType to return according to LaudeType in input
     * @param laudeType a LaudeType
     * @return ItemType to spawn
     */
    public static ItemType getLaudeCane(LaudeType laudeType){
        return switch (laudeType){
            case THREE -> ItemType.BLUE_CANDY_CANE;
            case ZERO -> ItemType.BROWN_CANDY_CANE;
            case L -> ItemType.ORANGE_CANDY_CANE;
            case O -> ItemType.RED_CANDY_CANE;
            case D -> ItemType.YELLOW_CANDY_CANE;
            case E -> ItemType.CYAN_CANDY_CANE;
        };
    }


}


