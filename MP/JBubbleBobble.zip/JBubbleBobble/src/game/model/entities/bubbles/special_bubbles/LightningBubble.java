package game.model.entities.bubbles.special_bubbles;

import game.model.Animation;
import game.model.Model;
import game.model.entities.bubbles.Element;

import java.util.ArrayList;

/**
 * A SpecialBubble that instances Storm when popped
 */
public class LightningBubble extends SpecialBubble{

    /**
     * LightningBubble constructor.
     * @param delay time to wait before appearing inside a level
     * @param x x coordinate of where to spawn
     */
    public LightningBubble(long delay, int x){
        super(delay, x);
        animation = Animation.LIGHTNING;
    }

    /**
     * Called when Bubblun hit a FireBubble
     * @param elements ArrayList of Element where the new Blaze is added
     */
    @Override
    public void pop(ArrayList<Element> elements) {
        Model.getInstance().getPlayerStats().addScore(8000);
        elements.add(new Storm(x - x%Model.TILE_SIZE, y - y%Model.TILE_SIZE));
    }

}
