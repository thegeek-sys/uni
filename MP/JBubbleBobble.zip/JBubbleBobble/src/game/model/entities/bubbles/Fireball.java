package game.model.entities.bubbles;

import game.model.Animation;
import game.model.Model;
import game.model.State;

import java.awt.*;

/**
 * Bubble blown by Hidegons
 */
public class Fireball extends Bubble{
    private final int endX;
    private long spawningTimer;

    public static final long SPAWNING_LENGTH = 250_000_000;

    /**
     * Fireball's constructor
     * @param x x coordinate
     * @param y y coordinate
     * @param endX where the Fireball collides with a block
     */
    public Fireball(int x, int y, int endX){
        super(x, y,( x > endX )? -Model.GAME_GRAVITY - 3: Model.GAME_GRAVITY + 3, 0, new Rectangle(x, y, Model.TILE_SIZE*2, Model.TILE_SIZE*2));
        this.endX = endX;
        state = State.SPAWNING;
        animation = (x > endX) ? Animation.SPAWNING_LEFT : Animation.SPAWNING_RIGHT;
        spawningTimer = System.nanoTime();
    }

    /**
     * Manages the updates for state, animation and x coordinate.
     */
    @Override
    public void update() {
        if(System.nanoTime() - spawningTimer >= SPAWNING_LENGTH && spawningTimer != -1){
            state = State.FLOATING;
            spawningTimer = -1;
            animation = (animation.toString().endsWith("LEFT")) ? Animation.FLOATING_LEFT : Animation.FLOATING_RIGHT;
        }
        if((velX>0 && x>=endX) || (velX<0 && x<=endX)) pop();
        else moveX(velX);
    }

    /**
     * Sets state to DEAD
     */
    @Override
    public void pop(){
        state = State.DEAD;
    }

}
