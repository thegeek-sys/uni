package game.model.entities.bubbles;

import game.model.Model;
import game.model.entities.Entity;

import java.awt.*;
import java.io.Serializable;

/**
 * Abstract class describing general Bubbles behaviours
 */
public abstract class Bubble extends Entity implements Serializable{

    /**
     * Bubble's constructor
     * @param x x coordinate
     * @param y y coordinate
     * @param velX velocity on x-axis
     * @param velY velocity on y-axis
     */
    public Bubble(int x, int y, int velX, int velY){
        super(x, y, velX, velY, new Rectangle(x+ Model.TILE_SIZE/2+1, y + Model.TILE_SIZE/2+1, Model.TILE_SIZE-2, Model.TILE_SIZE-2));
    }

    /**
     * Bubble's other constructor
     * @param x x coordinate
     * @param y y coordinate
     * @param velX velocity on x-axis
     * @param velY velocity on y-axis
     * @param hitbox Bubble's hitbox
     */
    public Bubble(int x, int y, int velX, int velY, Rectangle hitbox){
        super(x, y, velX, velY, hitbox);
    }

    /**
     * Implemented by son classes
     */
    public abstract void update();

    /**
     * Move Bubble on x-axis
     * @param velX velocity on x-axis
     */
    public void moveX(int velX){
        x += velX;
        updateHitbox();
    }

    /**
     * Move Bubble on y-axis
     * @param velY velocity on y-axis
     */
    public void moveY(int velY) {
        y += velY;
        updateHitbox();
    }

    /**
     * Implemented by son classes
     */
    public abstract void pop();
}
