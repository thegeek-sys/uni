package game.model.entities;

import game.model.Animation;
import game.model.State;

import java.awt.Rectangle;
import java.io.Serializable;

/**
 * Abstract class used to define any kind of entity in the game.
 */
public abstract class Entity implements Serializable{
    protected int x;
    protected int y;
    protected int velX;
    protected int velY;
    protected Animation animation;
    protected Rectangle hitbox;
    private boolean falling;
    protected State state;
    //protected State movementState;

    /**
     * Entity constructor. Sets its coordinates, scale, and velocities.
     * @param x x coordinate
     * @param y y coordinate
     * @param velX horizontal velocity
     * @param velY vertical velocity
     * @param hitbox hitbox
     */
    public Entity(int x, int y, int velX, int velY, Rectangle hitbox) {
        this.velX = velX;
        this.velY = velY;
        this.x = x;
        this.y = y;
        this.hitbox = hitbox;
    }

    /**
     * @return the entity's x coordinate.
     */
    public int getX() {return x;}
    /**
     * @return the entity's x coordinate.
     */
    public int getY() {return y;}

    /**
     * Sets the entity's x coordinate
     * @param x x coordinate
     */
    public void setX(int x) { this.x = x; }

    /**
     * Sets the entity's y coordinate
     * @param y y coodrinate
     */
    public void setY(int y) { this.y = y; }

    /**
     * Updates the entity's hitbox
     */
    public void updateHitbox(){
        hitbox.x = x;
        hitbox.y = y;
    }

    /**
     * @return entity's x velocity
     */
    public int getVelX(){ return velX; }

    /**
     * @return entity's y velocity
     */
    public int getVelY(){ return velY; }


    /**
     * Sets the entity's x velocity
     * @param velX x velocity
     */
    public void setVelX(int velX) { this.velX = velX; }

    /**
     * Sets the entity's y velocity
     * @param velY y velocity
     */
    public void setVelY(int velY) { this.velY = velY;}

    /**
     *
     * @return the entity's hitbox
     */
    public Rectangle getHitbox(){ return hitbox; }

    /**
     * Sets the entity's falling field
     * @param falling whether the entity is falling or not
     */
    public void setFalling (boolean falling) {this.falling = falling; }

    /**
     * @return whether the entity is falling or not
     */
    public boolean isFalling() { return falling; }

    /**
     * Sets the entity's current animation
     * @param animation the entity's animation
     */
    public void setAnimation(Animation animation) {
        this.animation = animation;
    }

    /**
     * @return the current animation
     */
    public Animation getAnimation() {
        return animation;
    }

    /**
     * Sets the entity's current state
     * @param state the entity's state
     */
    public void setState(State state) { this.state = state; }

    /**
     * @return the entity's current state
     */
    public State getState() { return state; }
}
