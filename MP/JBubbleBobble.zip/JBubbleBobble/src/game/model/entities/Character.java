package game.model.entities;

import game.model.Animation;
import game.model.State;

import java.awt.*;
import java.io.Serializable;

/**
 * Abstract class used to define Characters
 */
public abstract class Character extends Entity  {
    protected State healthState;

    /**
     * Constructor to create any kind of character
     * @param x x coordinate
     * @param y y coordinate
     * @param velX velocity on x
     * @param velY velocity on y
     * @param hitbox hitbox
     * @param animation current animation
     */
    public Character(int x, int y, int velX, int velY, Rectangle hitbox, Animation animation) {
        super(x, y, velX, velY, hitbox);
        this.animation = animation;
        state = State.STANDARD;
        healthState = State.STANDARD;
        setFalling(true);
    }
}
