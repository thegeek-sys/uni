package game.model.entities.opps;

import game.model.Model;
import game.model.Animation;
import game.model.CollisionType;
import game.model.State;
import game.model.entities.Character;
import game.model.entities.Item;
import game.model.entities.ItemType;

import java.awt.Rectangle;

/**
 * Abstract class used to define Enemies
 */
public abstract class Enemy extends Character {
    protected int spawnY;

    protected boolean jumping;
    protected long jumpingTimer;

    protected boolean exploding;
    protected long explodingTimer;
    protected  int explodingX;


    public static final long SMALL_JUMP_LENGTH = 700_000_000L;
    public static final long BIG_JUMP_LENGTH = 1_800_000_000L;
    public static final long EXPLODING_LENGTH = 2_000_000_000L;
    protected CollisionType prevCollision;


    /**
     * Constructor used to create any kind of Enemy
     * @param x x coordinate
     * @param y y coordinate
     * @param animation current animation
     */
    public Enemy(int x, int y, Animation animation) {
        super(x, y, 0, Model.GAME_GRAVITY, new Rectangle(x, y, Model.TILE_SIZE * 2, Model.TILE_SIZE * 2), animation);
        state = State.SPAWNING;
        setFalling(true);
        prevCollision = CollisionType.NO_COLLISION;
    }

    /**
     * Updates the enemy. Handles its state and its movement.
     */
    public void update(){
        if (healthState == State.DYING) explode();
        if(healthState == State.DEAD) velY = Model.GAME_GRAVITY;
        move();
    }

    /**
     * Moves the enemy according to its velocity
     */
    public void move() {
        x += velX;
        y += velY;
        velY = velX = 0;
        updateHitbox();
    }

    /**
     * Handles enemies' tendency to explode after being killed. Handles their movement during explosion.
     */
    public void explode(){
        jumping = false;
        if(explodingTimer == 0){
            setExploding(true);
            explodingX = (x > Model.SCREEN_WIDTH/2) ? -Model.GAME_LATERAL_SPEED+1 : Model.GAME_LATERAL_SPEED-1;
        }else{
            if(System.nanoTime() - explodingTimer <=  EXPLODING_LENGTH){
                velX = explodingX;
                velY = (System.nanoTime() - explodingTimer <= EXPLODING_LENGTH/2) ? -Model.GAME_GRAVITY : Model.GAME_GRAVITY;
            }else{
                setExploding(false);
                healthState = State.DEAD;
            }
        }
    }

    /**
     * Sets whether the enemy is exploding or not
     * @param exploding whether the enemy is exploding or not
     */
    public void setExploding(boolean exploding){
        this.exploding = exploding;
        explodingTimer = exploding ? System.nanoTime() : 0;
    }

    /**
     * Method signature used to update y velocity and handle enemies' ability to make jumps of different lengths
     * @param b whether the enemy should to a small jump or a big jump
     */
    public void updateY(boolean b){}

    /**
     * Method signature used to update y velocity
     */
    public void updateY(){}

    /**
     * Handles enemy's animation during collisions or changes of direction
     */
    public void updateSprite(){
        if(healthState == State.DYING) animation = Animation.DYING;
        else {
            animation = switch (animation){
                case LEFT -> Animation.RIGHT;
                case RIGHT -> Animation.LEFT;
                case SHOOTING_LEFT -> Animation.SHOOTING_RIGHT;
                case SHOOTING_RIGHT -> Animation.SHOOTING_LEFT;
                case JUMPING_LEFT -> Animation.JUMPING_RIGHT;
                case JUMPING_RIGHT -> Animation.JUMPING_LEFT;
                case ANGRY_SHOOTING_LEFT -> Animation.ANGRY_SHOOTING_RIGHT;
                case ANGRY_SHOOTING_RIGHT -> Animation.ANGRY_SHOOTING_LEFT;
                case ANGRY_JUMPING_RIGHT -> Animation.ANGRY_JUMPING_LEFT;
                case ANGRY_JUMPING_LEFT -> Animation.ANGRY_JUMPING_RIGHT;
                case ANGRY_LEFT -> Animation.ANGRY_RIGHT;
                case ANGRY_RIGHT -> Animation.ANGRY_LEFT;
                default -> animation;
            };
        }
    }

    /**
     * Method signature used to update x coordinate
     */
    public void updateX() {}

    /**
     * Sets enemy's spawn y coordinate
     * @param spawnY spawn y coordinate
     */
    public void setSpawnY(int spawnY) { this.spawnY = spawnY; }

    /**
     * Set whether the enemy is jumping or not
     * @param jumping boolean
     */
    public void setJumping(boolean jumping) {
        this.jumping = jumping;
        jumpingTimer = jumping ? System.nanoTime() : 0;
    }

    /**
     * @return whether the enemy is jumping.
     */
    public boolean isJumping(){ return jumping;}

    /**
     * Sets enemy's last collision detected
     * @param prevCollision last collision detected
     */
    public void setPrevCollision(CollisionType prevCollision) {
        this.prevCollision = prevCollision;
    }

    /**
     * @return last collision detected with enemy
     */
    public CollisionType getPrevCollision(){ return prevCollision; }

    /**
     * @return enemy's current health state
     */
    public State getHealthState() { return healthState; }

    /**
     * Sets enemy's current health state
     * @param healthState health state
     */
    public void setHealthState(State healthState) { this.healthState = healthState;}

    /**
     * Drops an item after the enemy's death
     * @param enemyPopped the number of enemies popped during a certain time frame
     * @return the kind of item dropped by the enemy
     */
    public Item drop(int enemyPopped){
        ItemType spawnFruit = ItemType.getFruit(Math.min(enemyPopped, 7));
        return new Item(x, y, spawnFruit);
    }

    /**
     * @return enemy's spawn y
     */
    public int getSpawnY() { return spawnY; }
}
