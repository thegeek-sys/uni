package game.model.entities.opps;

import game.model.Animation;
import game.model.CollisionHandler;
import game.model.Model;
import game.model.State;
import game.model.behaviours.Shooting;
import game.model.entities.bubbles.Fireball;

/**
 * Class that defines Hidegons enemy kind
 */
public class Hidegons extends Enemy implements Shooting {
    private int shootingCounter;

    private Fireball fireball;

    /**
     * Constructor. calls super with parameter values
     * @param x x coordinate
     * @param y y coordinate
     * @param animation current animation
     */
    public Hidegons(int x, int y, Animation animation){
        super(x, y, animation);
        shootingCounter = -1;
    }

    /**
     * Override of Enemy method. Updates Hidegons state, movement and projectile.
     */
    @Override
    public void update(){
        if(fireball != null && fireball.getState() == State.DEAD) fireball = null;
        if(state != State.SPAWNING && state != State.DYING && healthState != State.DEAD)tryShooting();

        tryJumping();
        if (shootingCounter != -1) shootingCounter++;
        if (healthState == State.DYING) explode();
        if(healthState == State.DEAD) velY = Model.GAME_GRAVITY;
        move();
    }

    /**
     * Implementation of Shooting interface method. Handles Hidegons ability and odds of shooting
     */
    @Override
    public void tryShooting(){
        if(fireball == null && Math.random() <= 0.0075) {
            boolean left = animation.toString().endsWith("LEFT");
            int dir = left ? -1 : 1;
            int endX = CollisionHandler.findEndX(x + (dir*x%Model.TILE_SIZE), y-y%Model.TILE_SIZE, dir);
            fireball = new Fireball(x, y, endX);
        }
    }

    /**
     * Override of Enmey method. Updates x velocity according to current direction
     */
    @Override
    public void updateX(){
        if(animation.toString().startsWith("ANGRY")) setVelX(animation.toString().endsWith("LEFT") ? (int)(-Model.GAME_LATERAL_SPEED*1.5) : (int)(Model.GAME_LATERAL_SPEED*1.5));
        else setVelX(animation == Animation.LEFT || animation == Animation.JUMPING_LEFT? -Model.GAME_LATERAL_SPEED : Model.GAME_LATERAL_SPEED);
    }

    /**
     * Handles Hidegons ability and odds of jumping
     */
    public void tryJumping(){
        if(healthState == State.DEAD) return;
        if (!jumping && !isFalling() && Math.random() <= 0.0005) {
            setJumping(true);
            setJumpingSprite();
        }
    }

    /**
     * Handles Hidegons animation when jumping
     */
    public void setJumpingSprite() {
        if (jumping && healthState == State.STANDARD) {
            animation = switch (animation) {
                case ANGRY_LEFT -> Animation.ANGRY_JUMPING_LEFT;
                case ANGRY_RIGHT -> Animation.ANGRY_JUMPING_RIGHT;
                case LEFT -> Animation.JUMPING_LEFT;
                case RIGHT -> Animation.JUMPING_RIGHT;
                default -> animation;
            };
        }
    }

    /**
     * Override of Enemy method. Updates y coordinate according to actions performed and state.
     * @param smallJump whether the enemy should to a small jump or a big jump
     */
    @Override
    public void updateY(boolean smallJump) {
        if (y >= spawnY && state == State.SPAWNING) { state = State.STANDARD;}

        velY = isFalling() ? Model.GAME_GRAVITY : 0;
        if(!isJumping()) tryJumping();
        if(jumping){
            if (System.nanoTime() - jumpingTimer >= SMALL_JUMP_LENGTH) setJumping(false);
            else if (System.nanoTime() - jumpingTimer < SMALL_JUMP_LENGTH /2){
                updateX();
                velY = -Model.GAME_GRAVITY;
            }else{
                updateX();
                setFalling(true);
                state = State.STANDARD;
            }
        }
    }

    /**
     * Implementation of Shooting interface method
     * @return projectile
     */
    @Override
    public Fireball getBubble() {
        return fireball;
    }
}

