package game.model.entities.opps;

import game.model.Animation;
import game.model.CollisionHandler;
import game.model.Model;
import game.model.State;
import game.model.behaviours.Shooting;
import game.model.entities.Bubblun;
import game.model.entities.bubbles.Bubble;
import game.model.entities.bubbles.Spell;

/**
 * Class that defines Mighta enemy kind
 */
public class Mighta extends Enemy implements Shooting {
    private long currentJumpLength;
    private Spell spell;

    private int shootingCounter;

    /**
     * Constructor. calls super with parameter values
     * @param x x coordinate
     * @param y y coordinate
     * @param animation current animation
     */
    public Mighta(int x, int y, Animation animation){
        super(x, y, animation);
        shootingCounter = -1;
    }

    /**
     * Override of Enemy method. Updates Mighta's state, movement, actions performed and projectile.
     */
    @Override
    public void update() {
        if(spell != null && spell.getState() == State.DEAD) spell = null;
        if(healthState == State.DEAD) velY = Model.GAME_GRAVITY;
        else {
            if(state != State.SPAWNING) tryShooting();

            if (shootingCounter == 25) {
                boolean left = animation.toString().endsWith("LEFT");
                int dir = left ? -1 : 1;
                int endX = CollisionHandler.findEndX(x + (dir*x%Model.TILE_SIZE), y-y%Model.TILE_SIZE, dir);
                spell = new Spell(x, y, endX);
                shootingCounter = -1;
                if(animation.toString().startsWith("ANGRY")) animation = left ? Animation.ANGRY_LEFT : Animation.ANGRY_RIGHT;
                else animation = left ? Animation.LEFT : Animation.RIGHT;
            }

            if (shootingCounter != -1) shootingCounter++;
            if (healthState == State.DYING) explode();
        }
        move();
    }

    /**
     * Override of Enemy method. Updates y velocity according to state and action performed
     * @param smallJump whether the enemy should to a small jump or a big jump
     */
    @Override
    public void updateY(boolean smallJump) {
        if (y >= spawnY && state == State.SPAWNING) { state = State.STANDARD;}

        velY = isFalling() ? Model.GAME_GRAVITY : 0;
        if(!isJumping()) tryJumping(smallJump);

        if (jumping) {
            if (System.nanoTime() - jumpingTimer >= currentJumpLength) setJumping(false);
            else if (System.nanoTime() - jumpingTimer < currentJumpLength / 2) {
                updateX();
                velY = -Model.GAME_GRAVITY;
            } else {
                updateX();
                setFalling(true);
                state = State.STANDARD;
            }
        }
    }

    /**
     * Handles Mighta's ability and odds of jumping.
     * @param smallJump whether it will try to do a small jump
     */
    public void tryJumping(boolean smallJump){
        if(healthState == State.DEAD) return;
        if (!smallJump){
            if (Bubblun.getInstance().getY() < y && !Bubblun.getInstance().isJumping() && !jumping && !isFalling() && Math.random() <= 0.05) {
                currentJumpLength = Enemy.BIG_JUMP_LENGTH;
                setJumping(true);
            }
        }else{
            if(Math.random() <= 0.6 && !jumping) {
                setJumping(true);
                currentJumpLength = Enemy.SMALL_JUMP_LENGTH;
            }
        }
    }

    /**
     * Override of Enemy method. Updates x velocity according to current direction
     */
    @Override
    public void updateX(){
        if(animation.toString().startsWith("ANGRY_S")) setVelX(animation == Animation.ANGRY_SHOOTING_LEFT ?  (int)(-Model.GAME_LATERAL_SPEED*1.5) : (int)(Model.GAME_LATERAL_SPEED*1.5));
        else if(animation.toString().startsWith("ANGRY")) setVelX(animation == Animation.ANGRY_LEFT ?  (int)(-Model.GAME_LATERAL_SPEED*1.5) : (int)(Model.GAME_LATERAL_SPEED*1.5));
        else setVelX(animation.toString().endsWith("LEFT") ? -Model.GAME_LATERAL_SPEED : Model.GAME_LATERAL_SPEED);
    }

    /**
     * Implemenation of Shooting interface method. Handles Mighta's ability and odds of shooting.
     */
    @Override
    public void tryShooting(){
        if(spell == null && Math.random() <= 0.01 && y == Bubblun.getInstance().getY()) {
            boolean left = (animation.toString().endsWith("LEFT"));
            if(animation.toString().startsWith("ANGRY")) animation = left ? Animation.ANGRY_SHOOTING_LEFT : Animation.ANGRY_SHOOTING_RIGHT;
            else animation = left ? Animation.SHOOTING_LEFT : Animation.SHOOTING_RIGHT;
            shootingCounter = 0;
        }
    }

    /**
     * Implementation of Shooting interface method.
     * @return projectile
     */
    @Override
    public Spell getBubble() {
        return spell;
    }
}
