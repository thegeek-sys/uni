package game.model.entities.opps;

import game.model.Animation;
import game.model.Model;
import game.model.State;
import game.model.entities.Bubblun;

/**
 * Class that defines ZenChan enemy kind
 */
public class ZenChan extends Enemy {
    private long currentJumpLength;

    /**
     * Constructor. Calls super constructor with parameter values
     * @param x x coordinate
     * @param y y coordinate
     * @param animation current animation
     */
    public ZenChan(int x, int y, Animation animation) {
        super(x, y, animation);
    }

    /**
     * Override of Enemy method. Updates the y velocity according to actions performed by ZenChan and state
     * @param smallJump whether the enemy should to a small jump or a big jump
     */
    @Override
    public void updateY(boolean smallJump) {
        if (y >= spawnY && state == State.SPAWNING) { state = State.STANDARD; }

        velY = isFalling() ? Model.GAME_GRAVITY : 0;
        tryJumping(smallJump);

        if (jumping) {
            if (System.nanoTime() - jumpingTimer >= currentJumpLength) setJumping(false);
            else if (System.nanoTime() - jumpingTimer < currentJumpLength / 2) {
                updateX();
                velY = -Model.GAME_GRAVITY;
            } else {
                updateX();
                setFalling(true);
                state = State.STANDARD;
            }
        }
    }

    /**
     * Handles ZenChan's ability and odds of jumping
     * @param smallJump the type of jump to be performed
     */
    public void tryJumping(boolean smallJump){
        if(healthState == State.DEAD) return;
        if (!smallJump){
            if (Bubblun.getInstance().getY() < y && !Bubblun.getInstance().isJumping() && !jumping && !isFalling() && Math.random() <= 0.05) {
                currentJumpLength = Enemy.BIG_JUMP_LENGTH;
                setJumping(true);
            }
        }else{
            if(Math.random() <= 0.6 && !jumping) {
                setJumping(true);
                currentJumpLength = Enemy.SMALL_JUMP_LENGTH;
            }
        }
    }

    /**
     * Updates x velocity according to its current direction
     */
    public void updateX(){
        if(animation.toString().startsWith("ANGRY")) setVelX(animation == Animation.ANGRY_LEFT ? (int)(-Model.GAME_LATERAL_SPEED*1.5) : (int)(Model.GAME_LATERAL_SPEED*1.5));
        else setVelX(animation == Animation.LEFT ? -Model.GAME_LATERAL_SPEED : Model.GAME_LATERAL_SPEED);
    }
}
