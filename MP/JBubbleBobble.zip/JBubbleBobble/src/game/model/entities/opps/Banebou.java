package game.model.entities.opps;

import game.model.Animation;
import game.model.Model;
import game.model.State;

/**
 * Class that defines Banebou enemy kind
 */
public class Banebou extends Enemy {
    private long currentJumpLength;

    /**
     * Constructor. Calls super with parameter values
     * @param x x coordinate
     * @param y y coordinate
     * @param animation current animation
     */
    public Banebou(int x, int y, Animation animation) {
        super(x, y, animation);
    }

    /**
     * Override of Enemy method. Updates y velocity according to Banebou's state and actions performent
     */
    @Override
    public void updateY() {
        if (y >= spawnY && state == State.SPAWNING) { state = State.STANDARD; }

        velY = isFalling() ? Model.GAME_GRAVITY : 0;
        chooseJump();

        if (jumping) {
            if (System.nanoTime() - jumpingTimer >= currentJumpLength) setJumping(false);
            else if (System.nanoTime() - jumpingTimer < currentJumpLength / 2) {
                updateX();
                velY = -Model.GAME_GRAVITY;
            } else {
                updateX();
                setFalling(true);
                state = State.STANDARD;
            }
        }
    }

    /**
     * Handles Banebou's odds of doing small instead of big jumps
     */
    public void chooseJump() {
        if (!jumping && !isFalling()) {
            if (Math.random()<=0.3d) {
                setJumping(true);
                currentJumpLength = Enemy.BIG_JUMP_LENGTH;
            } else {
                setJumping(true);
                currentJumpLength = Enemy.SMALL_JUMP_LENGTH;
            }
        }
    }


    /**
     * Updates x velocity according to current direction
     */
    public void updateX(){
        if(animation.toString().startsWith("ANGRY")) setVelX(animation == Animation.ANGRY_LEFT ? (int)(-Model.GAME_LATERAL_SPEED*1.5) : (int)(Model.GAME_LATERAL_SPEED*1.5));
        else setVelX(animation == Animation.LEFT ? -Model.GAME_LATERAL_SPEED : Model.GAME_LATERAL_SPEED);
    }

    /**
     * Calls super updateSprite method. Adds dying case
     */
    public void updateSprite(){
        super.updateSprite();
        if(state != State.DYING) updateX();
    }


}
