package game.model.entities.opps;

import game.model.Animation;
import game.model.Model;
import game.model.SoundEffect;
import game.model.State;
import game.model.behaviours.Shooting;
import game.model.entities.Bubblun;
import game.model.entities.bubbles.Bubble;
import game.model.entities.bubbles.Zap;

/**
 * Class used to define Invader kind of Enemy
 */
public class Invader extends Enemy implements Shooting {
    private Zap zap;

    /**
     * Constructor. Calls super with parameter values
     * @param x x coordinate
     * @param y y coordinate
     * @param animation current animation
     */
    public Invader(int x, int y, Animation animation){
        super(x, y, animation);
    }

    /**
     * Override of Enemy method. Updates Invader's state, actions performed, movement and projectile.
     */
    @Override
    public void update(){
        if(zap != null && zap.getState() == State.DEAD) {
            Model.getInstance().addSound(SoundEffect.INVADER_MISSILE_HIT);
            zap = null;
        }
        if(state != State.SPAWNING)tryShooting();
        if (healthState == State.DYING) explode();
        if(healthState == State.DEAD) velY = Model.GAME_GRAVITY;
        move();
    }

    /**
     * Override of Enemy method. Updates y velocity according to state
     */
    @Override
    public void updateY(){
        if (y >= spawnY && state == State.SPAWNING) { state = State.STANDARD;}
        if(isFalling()){
            velX = 0;
        }
        velY = isFalling() ? Model.GAME_GRAVITY : 0;
    }

    /**
     * Override of Enemy method.Updates x velocity according to current direction
     */
    @Override
    public void updateX(){
        velY = 0;
        if(velX == 0){
            if(animation.toString().startsWith("ANGRY")) velX = x < Bubblun.getInstance().getX() ? (int)(-Model.GAME_LATERAL_SPEED*1.5) : (int)(Model.GAME_LATERAL_SPEED*1.5);
            else velX = x < Bubblun.getInstance().getX() ? Model.GAME_LATERAL_SPEED : -Model.GAME_LATERAL_SPEED;
        }
    }

    /**
     * Override of Enemy method. Moves Invader according to its velocity
     */
    @Override
    public void move(){
        x += velX;
        y += velY;
        updateHitbox();
    }

    /**
     * Override of Enemy method. Updates sprite by calling super method and adding dying case
     */
    @Override
    public void updateSprite() {
        if(healthState == State.DYING) animation = Animation.DYING;
        super.updateSprite();
        velX = -velX;
    }

    /**
     * Implementation of Shooting interface method. Handles Invader's abiilty and odds to shoot projectiles
     */
    @Override
    public void tryShooting(){
        if(healthState == State.DEAD || healthState == State.DYING) return;
        if(Math.random() <= 0.05 && zap == null){
            zap = new Zap(x,y);
        }
    }

    /**
     * Implementation of Shooting interface method.
     * @return projectile
     */
    @Override
    public Zap getBubble() {
        return zap;
    }
}
