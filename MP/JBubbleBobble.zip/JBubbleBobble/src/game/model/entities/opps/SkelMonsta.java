package game.model.entities.opps;

import game.model.Animation;
import game.model.Model;
import game.model.State;
import game.model.entities.Bubblun;

/**
 * Class that defines SkelMonsta enemy kind
 */
public class SkelMonsta extends Enemy{
    private long spawningTimer;
    private boolean followsX;
    private long cooldownMultiplier;

    private long cooldownTimer;
    private long movingTimer;
    public static final long SPAWNING_LENGTH = 1_000_000_000L;
    public static final long COOLDOWN_LENGTH = 2_000_000_000L;
    public static final long MOVE_LENGTH = 2_000_000_000L;

    /**
     * Constructor. Calls super with parameters, sets fields
     */
    public SkelMonsta(){
        super(Bubblun.SPAWN_X, Bubblun.SPAWN_Y, Animation.SPAWNING);
        state = State.SPAWNING;
        spawningTimer = System.nanoTime();
        velY = velX = 0;
        setFalling(false);
    }

    /**
     * Override of Enemy method. Updates SkelMonsta state, handles its movement pattern.
     */
    @Override
    public void update(){
        if(spawningTimer!=-1 && System.nanoTime() - spawningTimer >= SPAWNING_LENGTH) {
            if(healthState != State.DYING) state = State.STANDARD;
            else healthState = State.DEAD;
            if(state == State.STANDARD) {
                animation = Animation.RIGHT;
                movingTimer = System.nanoTime();
                spawningTimer = -1;
            }
        }

        if(state == State.STANDARD){
            if((velY > 0 && y > Bubblun.getInstance().getY()) || (velY < 0 && y < Bubblun.getInstance().getY())) {
                velY = 0;
                movingTimer -= MOVE_LENGTH;
            }
            else if ((velX > 0  && x > Bubblun.getInstance().getX()) || (velX < 0  && x < Bubblun.getInstance().getX())) {
                velX = 0;
                movingTimer -= MOVE_LENGTH;
            }

            if(System.nanoTime() - movingTimer <= MOVE_LENGTH){
                cooldownTimer = -1;
                move();
            } else {
                if (cooldownTimer == -1) {
                    cooldownTimer = System.nanoTime();
                    velX = velY = 0;
                } else if(System.nanoTime() - cooldownTimer >= Math.max(COOLDOWN_LENGTH - cooldownMultiplier, 0)){
                    cooldownMultiplier += 150_000_000L;
                    followsX = !followsX;
                    movingTimer = System.nanoTime();
                    if(followsX) velX = Bubblun.getInstance().getX() > x ? Model.GAME_LATERAL_SPEED+1 : -(Model.GAME_LATERAL_SPEED+1);
                    else velY = Bubblun.getInstance().getY() > y ? Model.GAME_GRAVITY+1 : -(Model.GAME_GRAVITY+1);
                    updateSprite();
                }
            }
        }
    }

    /**
     * Override of Enemy method. Updates animation according to x velocity
     */
    @Override
    public void updateSprite(){
        if (healthState != State.DYING) animation = velX >= 0 ? Animation.RIGHT : Animation.LEFT;
    }

    /**
     * Override of Enemy method. Moves SkelMonsta according to velocity
     */
    @Override
    public void move(){
        x += velX;
        y += velY;
        updateHitbox();
    }

    /**
     * Handles SkelMonsta's behaviour after hitting Bubblun
     */
    public void setKiller(){
        state = State.SPAWNING;
        healthState = State.DYING;
        animation = Animation.SPAWNING;
        spawningTimer = System.nanoTime();
    }


}
