package game.model.entities.opps;

import game.model.Animation;
import game.model.Model;
import game.model.State;

/**
 * Class that defines Monsta enemy kind
 */
public class Monsta extends Enemy {
    /**
     * Constructor. Calls super with parameter values, sets y velocity
     * @param x x coordinate
     * @param y y coordinate
     * @param animation current animation
     */
    public Monsta(int x, int y, Animation animation){
        super(x, y, animation);
        velY = Model.GAME_GRAVITY;
    }

    /**
     * Override of Enemy method. Handles Monsta's movement pattern, updates y velocity
     * @param hit whether a vertical collisions was detected in the last frame
     */
    @Override
    public void updateY(boolean hit){
        if (y >= spawnY && state == State.SPAWNING) {
            state = State.STANDARD;
            updateX();
        }
        velY = hit ? -velY : velY;
        setFalling(hit != isFalling());
    }

    /**
     * Override of Enemy method. Updates x velocity according to current direction
     */
    @Override
    public void updateX(){
        if(animation.toString().startsWith("ANGRY")) setVelX(animation == Animation.ANGRY_LEFT ? (int)(-Model.GAME_LATERAL_SPEED*1.5) : (int)(Model.GAME_LATERAL_SPEED*1.5));
        else setVelX(animation == Animation.LEFT ? -Model.GAME_LATERAL_SPEED : Model.GAME_LATERAL_SPEED);
    }

    /**
     * Override of Enemy method. Moves Monsta according to velocity.
     */
    @Override
    public void move(){
        x += velX;
        y += velY;
        updateHitbox();
    }



}
