package game.model.entities;

import game.model.Animation;
import game.model.GameStats;
import game.model.Model;
import game.model.State;
import game.model.entities.bubbles.BBubble;
import java.awt.*;
import java.util.*;

/**
 * Singleton class that represents the character moved by the player
 */
public class Bubblun extends Character {
    private static Bubblun instance;

    private GameStats playerStats;

    private int health;
    private State healthState;
    private boolean lostLives;

    private boolean jumping;
    private long jumpingTimer;

    private boolean shooting;
    private long shootingTimer;

    private long damagedTimer;
    private long burnTimer;
    private long meltingTimer;
    private long cooldownTimer;

    private boolean wet;

    private ItemType powerUp;

    private int speedMultiplier;
    private double shootingMultiplier;

    public final static int VEL_X = 4;
    public static final int MAX_HEALTH = 5;
    private static final long JUMP_LENGTH = 1000000000L;
    private static final long DAMAGED_LENGTH = 1000000000L;
    public static final long INVULNERABILITY_LENGTH = 3000000000L;
    public static final long SHOOTING_ANIMATION_LENGTH = 50_000_000L;
    public static final long BURN_LENGTH = 1_000_000_000L;
    public static final long MELT_LENGTH = 2_000_000_000L;
    public static final long SHOOTING_COOLDOWN = 500_000_000L;

    public static int SPAWN_X = 5*Model.TILE_SIZE;
    public static int SPAWN_Y = Model.GAME_SCREEN_HEIGHT -(3*Model.TILE_SIZE);

    /**
     * Private player's constructor according to singleton design pattern
     */
    private Bubblun() {
        super(SPAWN_X, SPAWN_Y,
                VEL_X, 0, new Rectangle(SPAWN_X, SPAWN_Y, Model.TILE_SIZE*2, Model.TILE_SIZE * 2), Animation.STILL_RIGHT);
        speedMultiplier = 1;
        shootingMultiplier = 1;
        health = 3;
        healthState = State.STANDARD;
        setFalling(true);
    }

    /**
     * Method to implement singleton design pattern
     * @return instance of the player
     */
    public static Bubblun getInstance() {
        if(instance==null) instance = new Bubblun();
        return instance;
    }

    /**
     * Sets bubblun's game stats
     * @param stats the player's game stats
     */
    public void setPlayerStats(GameStats stats){ this.playerStats = stats; }

    //updates bubblun. handles damage, shooting, and moves the player.

    /**
     * Updates bubblun. Handles its states, lives, animations, and movement
     */
    public void update() {
        if(healthState == State.BURNT && System.nanoTime() - burnTimer >= BURN_LENGTH){
            healthState = State.STANDARD;
            burnTimer = 0;
            animation = Animation.STILL_RIGHT;

        }else if(healthState == State.MELTING && System.nanoTime() - meltingTimer >= MELT_LENGTH){
            healthState = State.HIT;
            damagedTimer = System.nanoTime() - DAMAGED_LENGTH;
            meltingTimer = 0;
        }
        if(state == State.OOB) handleOutOfBounds();
        if(healthState != State.STANDARD) handleDamage();
        if(health < MAX_HEALTH && !Arrays.asList(playerStats.getLaudeBubbles()).contains(false)){
            health++;
            playerStats.resetLaudeBubbles();
        }
        if(shooting)
            if(System.nanoTime() - shootingTimer >= SHOOTING_ANIMATION_LENGTH) shooting = false;

        if(state != State.FLOATING) updateY();

        move();
    }

    /**
     * Moves the player according to its velocity
     */
    public void move(){
        //adding to the step counter
        playerStats.addSteps( Math.abs(velX * speedMultiplier));
        if(powerUp == ItemType.CYAN_RING) playerStats.addScore(10 * (Math.max(velX, velY) * speedMultiplier));
        x += velX * speedMultiplier;
        y += velY * speedMultiplier;
        velY = velX = 0;
        updateHitbox();
    }

    /**
     * Handles bubblun's animation and states in the case it gets hit and takes damage
     */
    public void handleDamage(){
        if(healthState == State.HIT && System.nanoTime() - damagedTimer >= DAMAGED_LENGTH) {
            healthState = State.INVULNERABLE;
            animation = Animation.STILL_RIGHT;
            damagedTimer = System.nanoTime();
            x = SPAWN_X;
            y = SPAWN_Y;
            setFalling(false);
        }
        //if invulnerability is over
        if(healthState == State.INVULNERABLE &&  System.nanoTime()-damagedTimer > INVULNERABILITY_LENGTH) {
            state = State.STANDARD;
            healthState = State.STANDARD;
            damagedTimer = 0;
        }
    }

    /**
     * Handles bubblun's movement in case it falls into the void during the level
     */
    public void handleOutOfBounds(){
        velX = 0;
        if(y > -1) {
            state = State.STANDARD;}
    }

    /**
     * Updates bubblun's velY coordinate by checking its movement state
     */
    public void updateY(){
        velY = isFalling() ? Model.GAME_GRAVITY : 0;

        if (jumping) {
            if (System.nanoTime() - jumpingTimer >= JUMP_LENGTH) jumping = false;

            else if (System.nanoTime() - jumpingTimer < JUMP_LENGTH / 2) velY = -Model.GAME_GRAVITY * 2;
            else {
                setFalling(true);
                state = State.STANDARD;
            }
        }
    }

    /**
     * Sets whether the player is jumping or not
     * @param jumping boolean
     */
    public void setJumping(boolean jumping) {
        if (jumping) playerStats.addJumps();
        if(powerUp == ItemType.PURPLE_RING) playerStats.addScore(500);
        jumpingTimer = jumping ? System.nanoTime() : 0;
        this.jumping = jumping;
    }

    /**
     * Sets bubblun on fire
     */
    public void burn() {
        if (burnTimer == 0) {
            burnTimer = System.nanoTime();
            healthState = State.BURNT;
            animation = Animation.BURNT;

        }
    }

    /**
     * Sets bubblun to melting
     */
    public void melt(){
        health--;
        lostLives = true;
        if(health == 0) healthState = State.DEAD;
        else if(meltingTimer == 0){
            meltingTimer = System.nanoTime();
            healthState = State.MELTING;
            animation = Animation.MELTING;
        }
    }

    /**
     * @return whether the player is jumping or not
     */
    public boolean isJumping(){ return jumping; }

    /**
     * @return whether the player is shooting or not
     */
    public boolean isShooting() { return shooting;}

    /**
     * Starts the bubblun's shooting action
     * @param shooting whether it's shooting
     */
    public void setShooting(boolean shooting) {
        shootingTimer = shooting ? System.nanoTime() : 0;
        this.shooting = shooting;
    }

    /**
     * Handles bubblun's lives in case he takes damage
     */
    public void loseHealth() {
        health--;
        lostLives = true;
        if(health > 0) {
            healthState = State.HIT;
            damagedTimer = System.nanoTime();
            animation = Animation.DAMAGED;
            setFalling(false);
        }
        else healthState = State.DEAD;
    }

    /**
     * Handles bubblun's lives in case he gains a life by collecting all 30LODE bubbles
     */
    public void gainHealth(){health++;}

    /**
     * @return bubblun's current health state
     */
    public State getHealthState(){return healthState;}

    /**
     * @return number of bubblun's lives
     */
    public int getHealth(){ return health; }

    /**
     * Handles bubblun's shooting action. Sets animations, updates stats
     * @return new bubble shot
     */
    public BBubble shootBubble(){
        if(powerUp == ItemType.RED_RING) playerStats.addScore(100);
        if (animation == Animation.JUMPING_LEFT || animation == Animation.LEFT || animation == Animation.STILL_LEFT){
            playerStats.addBubblesBlown();
            return new BBubble(x - (Model.TILE_SIZE + 8), y + 8, -Model.GAME_LATERAL_SPEED, (powerUp == ItemType.PURPLE_CANDY), (powerUp == ItemType.BLUE_CANDY));
        }
        else if (animation == Animation.JUMPING_RIGHT || animation == Animation.RIGHT || animation == Animation.STILL_RIGHT) {
            playerStats.addBubblesBlown();
            return new BBubble(x + (Model.TILE_SIZE * 2 - 14), y + 8, Model.GAME_LATERAL_SPEED, (powerUp == ItemType.PURPLE_CANDY), (powerUp == ItemType.BLUE_CANDY));
        }
        return null;
    }

    /**
     * Handles bubblun's animation during changes in states, actions, or movement.
     * @param velX bubblun's x velocity
     * @param jump whether bubblun has started jumping or not
     * @param shoot wheter bubblun is shooting a bubble or not
     */
    public void updateSprite(int velX, boolean jump, boolean shoot){
        if(shoot){
            if(animation.toString().endsWith("LEFT")) animation = Animation.SHOOTING_LEFT;
            else if(animation.toString().endsWith("RIGHT")) animation = Animation.SHOOTING_RIGHT;
        } else if (jump){
            if (animation == Animation.RIGHT || animation == Animation.STILL_RIGHT) animation = (Animation.JUMPING_RIGHT);
            if (animation == Animation.LEFT || animation == Animation.STILL_LEFT) animation = (Animation.JUMPING_LEFT);
        }else if(velX != 0){
            if(!isJumping() && !shooting) animation = velX > 0 ? Animation.RIGHT : Animation.LEFT;
            else if(isJumping()) animation = velX > 0 ? Animation.JUMPING_RIGHT : Animation.JUMPING_LEFT;
        }else{
            if(animation.toString().endsWith("LEFT")) animation = Animation.STILL_LEFT;
            else if(animation.toString().endsWith("RIGHT")) animation = Animation.STILL_RIGHT;
         }
    }

    /**
     * Handles bubblun's ability to collect power ups. Performs different actions according to power up.
     * @param powerUp type of power up collected
     */
    public void setPowerUp(ItemType powerUp) {
        int maxLevelsSkippable = 25 - Model.getInstance().getLevel().getLevelNumber();
        this.powerUp = powerUp;
        switch (powerUp) {
            case RED_SHOE -> speedMultiplier = 2;
            case PURPLE_CANDY ->playerStats.addPurpleCandiesEaten();
            case YELLOW_CANDY -> {
                playerStats.addYellowCandiesEaten();
                shootingMultiplier = 0.5;
            }
            case BLUE_CANDY -> playerStats.addBlueCandiesEaten();
            case ORANGE_UMBRELLA -> Model.getInstance().setLevelsSkipped(Math.min(3, maxLevelsSkippable));
            case RED_UMBRELLA -> Model.getInstance().setLevelsSkipped(Math.min(5, maxLevelsSkippable));
            case PURPLE_UMBRELLA -> Model.getInstance().setLevelsSkipped(Math.min(7, maxLevelsSkippable));
            case SILVER_DOOR -> {}
            case SILVER_RING -> {}
        }
    }

    /**
     * Clears bubblun's current power up
     */
    public void clearPowerUp() { powerUp = null; }

    /**
     * Checks if bubblun is allowed to shoot according to the cooldown period
     * @return whether bubblun can shoot a bubble or not
     */
    public boolean isAllowedToShoot() {
        if (cooldownTimer==0) {
            cooldownTimer = System.nanoTime();
            return true;
        } else if (System.nanoTime()-cooldownTimer<=(long)(SHOOTING_COOLDOWN*shootingMultiplier))
            return false;
        else {
            cooldownTimer = 0;
            return false;
        }
    }

    /**
     * @return bubblun's current power up
     */
    public ItemType getPowerUp(){ return powerUp; }

    /**
     * @return whether bubblun has lost lives anytime during the game
     */
    public boolean hasLostLives() { return lostLives; }

    /**
     * Sets bubblun's wet field
     * @param wet whether bubblun is wet or not
     */
    public void setWet(boolean wet) { this.wet = wet; }

    /**
     * @return whether bubblun is wet or not
     */
    public boolean isWet() { return wet; }

    /**
     * Sets bubblun's spawn y coordinate
     * @param spawnY spawn y coordinate
     */
    public void setSpawnY(int spawnY) { SPAWN_Y = spawnY; }

    /**
     * Resets Bubblun's multipliers
     */
    public void resetMultipliers(){
        speedMultiplier = 1;
        shootingMultiplier = 1;
    }

}