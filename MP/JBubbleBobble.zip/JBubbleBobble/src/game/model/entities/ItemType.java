package game.model.entities;

/**
 * Enumeration that defines all the items in the game, and their points value
 */
public enum ItemType {
    // power-ups
    YELLOW_CANDY(100), BLUE_CANDY(100), PURPLE_CANDY(100), RED_SHOE(100),
    ORANGE_UMBRELLA(200), RED_UMBRELLA(200), PURPLE_UMBRELLA(200),
    PURPLE_RING(1000), RED_RING(1000), CYAN_RING(1000), SILVER_DOOR(1000),
    SILVER_RING(3000),

    // time related point items
    FUDGESICLE(650), POPSICLE(700), STRAWBERRY_SHERBET(750),LEMON_SHERBET(800), MATCHA_SHERBET(850),
    RED_BEAN_SHERBET(900), SINGLE_CONE(950), DOUBLE_CONE(1000), FRENCH_FRIES(1000),

    //common value items
    GREEN_PEPPER(10), EGGPLANT(20), CARROT(30), ONION(40), RADISH(50), TURNIP(60), PARSNIP(70),
    CUCUMBER(80),SNOW_PEA(90), MUSHROOM(100),

    //randomly spawning
    ACORN(-10_000), CORN(150), FRIED_EGG(200), OCTOPUS(1000), CORNDOG(70), BUTTERFLY(90), LEMON(350),
    AVOCADO(600), BURGER(1000), BEER(2000), CHICKEN(700), SHRIMP_NIGIRI(200), EGG_NIGIRI(150), RAMEN(1200),
    CHERRY(500), STRAWBERRY(50), SODA_CAN(400), PIZZA(2000), FLAMINGO(850), //18

    //enemies popped
    BANANA(500), ORANGE(1000), PEACH(2000), WATERMELON(3000), GRAPES(4000), PINEAPPLE(5000), PINK(6000),

    //candy canes
    BLUE_CANDY_CANE(500), RED_CANDY_CANE(500), CYAN_CANDY_CANE(500),
    BROWN_CANDY_CANE(500), ORANGE_CANDY_CANE(500), YELLOW_CANDY_CANE(500),

    //diamonds
    PINK_DIAMOND(6000), BLUE_DIAMOND(7000), YELLOW_DIAMOND(8000), ORANGE_DIAMOND(9000),

    //final level
    METRO_A(-2000), METRO_B(1000), METRO_C(2000);



    public int value;

    /**
     * Constructor
     * @param value points value
     */
    ItemType(int value) { this.value = value; }

    /**
     * @return item's points value
     */
    public int getValue() { return value; }

    /**
     * @param i points value of the item
     * @return item type with matching points value
     */
    public static ItemType getItem(int i) {
        for (ItemType point : values()){
            if(point.value == i){
                return point;
            }
        }
        return null;
    }

    /**
     * Handles enemies' fruit drop
     * @param enemyPopped number of enemies popped in the same time frame
     * @return fruit dropped by the enemy
     */
    public static ItemType getFruit(int enemyPopped){
        return switch(enemyPopped) {
            case 1 -> BANANA;
            case 2 -> ORANGE;
            case 3 -> PEACH;
            case 4 -> WATERMELON;
            case 5 -> GRAPES;
            case 6 -> PINEAPPLE;
            case 7 -> PINK_DIAMOND;
            default -> null;
        };
    }

    /**
     * @param item item type
     * @return whether the item is a power up or not
     */
    public static boolean isPowerUp(ItemType item) {
        return switch (item) {
            case YELLOW_CANDY, BLUE_CANDY, PURPLE_CANDY, RED_SHOE, ORANGE_UMBRELLA,
                 RED_UMBRELLA, PURPLE_UMBRELLA, PURPLE_RING, RED_RING, CYAN_RING, SILVER_DOOR, SILVER_RING -> true;
            default -> false;
        };
    }

    /**
     *
     * @param seconds amount of seconds elapsed during the previous level
     * @return item drop based on the seconds parameter
     */
    public static ItemType getTimePointItem(int seconds){
        //first level
        if(seconds == 0) return (getItem(10 * (int)(Math.random() *(10 -1)+1)));

        return switch (seconds){
            case 29 -> FUDGESICLE;
            case 28 -> POPSICLE;
            case 27 -> STRAWBERRY_SHERBET;
            case 26 -> LEMON_SHERBET;
            case 25 -> MATCHA_SHERBET;
            case 24 -> RED_BEAN_SHERBET;
            case 22 -> SINGLE_CONE;
            case 21 -> DOUBLE_CONE;
            case 20 -> FRENCH_FRIES;
            default -> null;
        };
    }

    /**
     * @return random item
     */
    public static ItemType getRandomItem(){
        int i = (int)(Math.random()*(17-1)+1);
        return switch(i){
            case 1 -> CORN;
            case 2 -> FRIED_EGG;
            case 3 -> OCTOPUS;
            case 4 -> CORNDOG;
            case 5 -> BUTTERFLY;
            case 6 -> LEMON;
            case 7 -> AVOCADO;
            case 8 -> BURGER;
            case 9 -> BEER;
            case 10 -> CHICKEN;
            case 11 -> SHRIMP_NIGIRI;
            case 12 -> EGG_NIGIRI;
            case 13 -> RAMEN;
            case 14 -> CHERRY;
            case 15 -> STRAWBERRY;
            case 16 -> SODA_CAN;
            case 17 -> PIZZA;
            case 18 -> FLAMINGO;
            case 19 -> GREEN_PEPPER;
            case 20 -> EGGPLANT;
            case 21 -> CARROT;
            case 22 -> ONION;
            case 23 -> RADISH;
            case 24 -> TURNIP;
            case 25 -> PARSNIP;
            case 26 -> CUCUMBER;
            case 27 -> SNOW_PEA;
            case 28 -> MUSHROOM;
            case 29 -> ACORN; //hehehehehehe
            default -> null;
        };
    }
}