package game.model.entities;

import java.awt.*;

/**
 * Class that defines Train, a kind of Entity
 */
public class Train extends Entity {
    private final ItemType metroLine;

    /**
     * Constructor. Calls super with parameter value, sets metro type
     * @param x x coordinate
     */
    public Train(int x) {
        super(x, 358, (int) Math.round(Math.random() * (-4 - 4) + 4), -4, new Rectangle(x, 358, 18, 64));
        double r = Math.random();

        if (r <= 0.5) metroLine = ItemType.METRO_A;
        else if (r <= 0.9) metroLine = ItemType.METRO_B;
        else metroLine = ItemType.METRO_C;
    }

    /**
     * Updates Train
     */
    public void update(){
        move();
        updateHitbox();
    }

    /**
     * Updates Train's positions according to velocity
     */
    public void move(){
        x += velX;
        y += velY;
    }

    /**
     * @return metro type
     */
    public ItemType getLine(){return metroLine;}
}
