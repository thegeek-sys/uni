package game.model.entities;

import game.model.Model;

import java.awt.*;

/**
 * Class that defines the blocks that make up the level
 */
public class Block {
    private boolean solid;
    private int srtX, srtY;
    private Rectangle hitbox;

    /**
     * Constructor
     * @param solid whether the block is solid or not
     * @param srtX x coordinate
     * @param srtY y coordinate
     */
    public Block(boolean solid, int srtX, int srtY) {
        this.hitbox = new Rectangle(srtX, srtY, Model.TILE_SIZE, Model.TILE_SIZE);
        this.solid = solid;
        this.srtX = srtX;
        this.srtY = srtY;
    }

    /**
     * @return whether a block is solid or not
     */
    public boolean isSolid() {
        return solid;
    }

    /**
     * @return x coordinate
     */
    public int getSrtX() {
        return srtX;
    }

    /**
     * @return y coordinate
     */
    public int getSrtY() {
        return srtY;
    }

    /**
     * @return block hitbox
     */
    public Rectangle getHitbox() { return hitbox;}

}
