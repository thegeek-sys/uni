package game.model.entities;

import game.model.Animation;
import game.model.Model;

import java.awt.*;

/**
 * Class that defines stars, a kind of Entity
 */
public class Star extends Entity{
    /**
     * Constructor
     * @param x x coordinate
     */
    public Star(int x){
        super(x, -Model.TILE_SIZE*2, (int)Math.round(Math.random()*(4+4)-4), 4, new Rectangle(x, -Model.TILE_SIZE*2, (int)(Model.TILE_SIZE*1.5), (int)(Model.TILE_SIZE*1.5)));
        animation = Animation.STAR;
    }

    /**
     * Updates Star
     */
    public void update(){
        move();
        updateHitbox();
    }

    /**
     * Updates Stars position according to velocity
     */
    public void move(){
        x += velX;
        y += velY;
    }

}
