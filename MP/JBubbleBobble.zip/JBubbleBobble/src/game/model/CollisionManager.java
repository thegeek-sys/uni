package game.model;

import game.model.behaviours.Shooting;
import game.model.entities.ItemType;
import game.model.entities.Star;
import game.model.entities.bubbles.*;
import game.model.entities.Bubblun;
import game.model.entities.bubbles.special_bubbles.*;
import game.model.entities.opps.*;
import game.model.entities.Item;

import java.util.ArrayList;

/**
 * Class that handles the collisions between entities,the level. Handles their consequences
 */
public class CollisionManager {

    /**
     * Handles collisions between two bubbles.
     * @param collision the CollisionHandler that will return the collision type.
     * @param bubble the first BBubble (the one that is currently moving)
     * @param otherBubble the second BBubble (that could be hit)
     */
    public static void doubleBubbleCollisions(CollisionHandler collision, BBubble bubble, BBubble otherBubble){
        switch (collision.handleDoubleBubble(otherBubble)) {
            case CollisionType.TOP -> bubble.moveY(6);
            case CollisionType.HIT_LEFT -> bubble.moveX(6);
            case CollisionType.HIT_RIGHT -> bubble.moveX(-6);
            default -> {}
        }
    }

    /**
     * Handles whether a BBubble is hitting an enemy, and what to do in that case.
     * @param enemyHit the enemy that has been hit, if there is one.
     * @param bubble the BBubble possibly hitting the enemy
     * @param enemies the Enemy ArrayList to check for collisions
     */
    public static void checkEnemyHit(Enemy enemyHit, BBubble bubble, ArrayList<Enemy> enemies){
        if (bubble.getAbsordbedEnemy() == null && bubble.isSpawning() && !(enemyHit instanceof SkelMonsta)) {
            bubble.addEnemy(enemyHit);
            enemies.remove(enemyHit);
        }
    }

    /**
     * Handles the different collisions the BBubble can have with the player and the surrounding blocks.
     * @param collision the CollisionType the BBubble is having (after having considered both the player and the blocks).
     * @param bubble the BBubble possibly being hit by the player or hitting some blocks
     * @param player the player
     */
    public static void checkBubbleBub(CollisionType collision, BBubble bubble, Bubblun player, Level level){ //level could be a field or something else
        switch(collision){
            case TOP -> bubble.moveX();
            case BOUNDS -> {
                bubble.setY(Model.GAME_SCREEN_HEIGHT - Model.TILE_SIZE+8);
                bubble.updateHitbox();
            }
            case SIDE -> {
                if(bubble.isSpawning()) bubble.setSpawning(false);
                bubble.setVelX(0);
                bubble.moveY();
            }
            case CORNER -> {
                if(bubble.isSpawning()){
                    bubble.setSpawning(false);
                    bubble.moveY();
                }
                bubble.setVelX(0);
                bubble.setVelY(0);
            }
            case BUBBLUN -> {
                bubble.pop();
                if (bubble.getAbsordbedEnemy() != null) {
                    Model.getInstance().addSound(SoundEffect.POP_BUBBLES);
                    level.handleHits(bubble, false);
                    if (level.getEnemies().isEmpty() || (level.getEnemies().size() == 1 && level.getEnemies().getFirst() instanceof SkelMonsta)) {

                        if(!level.getEnemies().isEmpty()) ((SkelMonsta)level.getEnemies().getFirst()).setKiller();
                        ArrayList<BBubble> bubbles = level.getBubbles();
                        int totalBubbles = (int)bubbles.stream().filter(x -> x.getAbsordbedEnemy()!=null).count();
                        level.setEnemyMultiplier(totalBubbles);
                        level.handleHits(bubble, true);
                        for (BBubble bBubble : bubbles) {
                            bBubble.pop();
                        }
                        level.getSpecialBubbles().clear();
                    }
                }
                //adding to the empty bubbles popped counter for item spawn logic
                else Model.getInstance().getPlayerStats().addEmptyBubblesPopped();
            }
            case HIT_LEFT, HIT_RIGHT -> {
                bubble.setVelX(collision == CollisionType.HIT_LEFT ? Bubblun.VEL_X : -Bubblun.VEL_X);
                bubble.moveX();
            }
            case UNDER_BUB -> {
                if(bubble.getAnimation() != Animation.POPPED) player.setJumping(true);
            }

            default -> {
                bubble.moveX();
                bubble.moveY();
            }

        }
    }

    /**
     * Handles the collisions between a water block and the level, updates the water flow
     * @param waterBlock water block
     * @param waterFlow water flow
     */
    public static void checkWaterCollision(WaterFlow.WaterBlock waterBlock, WaterFlow waterFlow ){
        CollisionHandler collisionH = new CollisionHandler(waterBlock);
        switch(collisionH.handleWaterBlock()) {
            case STANDARD -> {
                if(waterBlock.getAnimation().toString().endsWith("LEFT")) waterFlow.addWater(waterBlock.getX() - Model.TILE_SIZE, waterBlock.getY(), Animation.WATER_LEFT);
                else waterFlow.addWater(waterBlock.getX() + Model.TILE_SIZE, waterBlock.getY(), Animation.WATER_RIGHT);
            }
            case CORNER_LEFT ->{
                if(waterFlow.getContent().getLast().getAnimation() == Animation.WATER_DOWN) waterFlow.addWater(waterBlock.getX(), waterBlock.getY() + Model.TILE_SIZE, Animation.WATER_DOWN_RIGHT);
                else waterFlow.addWater(waterBlock.getX() - Model.TILE_SIZE, waterBlock.getY(), Animation.WATER_RIGHT);

            }
            case CORNER_RIGHT -> {
                if(waterFlow.getContent().getLast().getAnimation() == Animation.WATER_DOWN) waterFlow.addWater(waterBlock.getX(), waterBlock.getY() + Model.TILE_SIZE, Animation.WATER_DOWN_LEFT);
                else waterFlow.addWater(waterBlock.getX() +Model.TILE_SIZE, waterBlock.getY(), Animation.WATER_LEFT);
            }
            case NO_COLLISION -> {
                if(waterBlock.getAnimation() == Animation.WATER_LEFT) waterFlow.addWater(waterBlock.getX() - Model.TILE_SIZE, waterBlock.getY(), Animation.WATER_UP_LEFT);
                else if(waterBlock.getAnimation() == Animation.WATER_RIGHT) waterFlow.addWater(waterBlock.getX() + Model.TILE_SIZE, waterBlock.getY(), Animation.WATER_UP_RIGHT);
                else waterFlow.addWater(waterBlock.getX(), waterBlock.getY() + Model.TILE_SIZE, Animation.WATER_DOWN);
            }

            default -> {}
        }
    }

    /**
     * Handles the collision between a special bubble and Bubblun
     * @param specialBubble bubble
     * @param player Bubblun instance
     * @return whether Bubblun hit a special bubble or not
     */
    public static boolean checkSpecialBubbleBub(SpecialBubble specialBubble, Bubblun player){
        if(Model.GAME_SCREEN_HEIGHT>specialBubble.getY() && specialBubble.getY() > 0) {
            return player.getHitbox().intersects(specialBubble.getHitbox());
        }
        return false;
    }

    /**
     * Handles collisions between Bubblun and the level map
     * @param player Bubblun instance
     */
    public static void bubblunCollisions(Bubblun player) {
        CollisionHandler collisionH = new CollisionHandler(player);

        switch(collisionH.handleBubblun()){
            case CollisionType.STANDARD -> player.setFalling(false);
            case CollisionType.BOUNDS -> player.setFalling(true);
            case CollisionType.SIDE -> player.setVelX(0);
            case CollisionType.CORNER -> {
                player.setVelX(0);
                player.setFalling(false);
            }
            case CollisionType.VOID -> {
                player.setState(State.OOB);
                player.setY(-48 );
                player.setFalling(true);
                player.updateY();
            }
            default -> player.setFalling(true);

        }
        player.update();
    }

    /**
     * Handles collisions between an enemy and potential stars, elements and the level map
     * @param enemy enemy
     * @param level current level
     * @return whether the enemy has to do a small jump to not fall into a hole
     */
    public static boolean enemyCollisions(Enemy enemy, Level level) {

        //skelMonsta has no collisions, we override them !
        if(enemy instanceof SkelMonsta) return false;
        if(enemy instanceof Monsta) return monstaCollisions((Monsta)enemy, level);
        if(enemy instanceof Shooting) handleEnemyBubble((Shooting)enemy);

        CollisionHandler collisionH = new CollisionHandler(enemy);

        ArrayList<Star> stars = level.getStars();
        if(collisionH.entityHit(stars)!= null){
            enemy.setHealthState(State.STARSTRUCK);
            handleDying(enemy, level);
        }

        ArrayList<Element> elements = level.getElements();
        for (Element element : elements) {

            ArrayList<? extends ElementContained> flow = element.getContent();
            ElementContained block = (ElementContained) collisionH.entityHit(flow);

            if (block != null) {
                element.handleCollision(enemy);
            }
        }

        if(enemy.getState() == State.SWIMMING) return false;

        if(enemy.getHealthState() == State.DYING  && collisionH.isVoid(enemy.getHitbox())) {
            enemy.setY(-Model.TILE_SIZE * 2);
            return false;
        }

        CollisionType collision = collisionH.handleEnemy();

        //when dead, we only want the enemy to react to standard collision
        if (collision != CollisionType.STANDARD && enemy.getHealthState() == State.DEAD) return false;
        switch (collision) {
            case CollisionType.STANDARD -> {
                handleDying(enemy, level);
                enemy.setFalling(false);
                enemy.updateX();
            }
            case CollisionType.BOUNDS -> {
                enemy.setFalling(true);
            }
            case CollisionType.SIDE_BOUNDS -> {
                enemy.updateSprite();
                enemy.updateX();
            }

            case CollisionType.SIDE -> {
                if (!enemy.isFalling() && !enemy.isJumping()) {
                    enemy.updateSprite();
                    enemy.updateX();
                }
            }

            case CollisionType.CORNER -> {
                enemy.updateSprite();
                enemy.updateX();
                enemy.setFalling(false);
            }
            case CollisionType.VOID -> enemy.setY(-Model.TILE_SIZE*2);

            default -> {
                enemy.setFalling(true);
                if (enemy.getPrevCollision() == CollisionType.STANDARD && !enemy.isJumping()) return true;
            }
        }
        enemy.setPrevCollision(collision);
        return false;
    }

    /**
     * Handles Monsta's collisions and its movement pattern
     * @param monsta monsta
     * @param level current level
     * @return whether a vertical collision was detected or not
     */
    public static boolean monstaCollisions(Monsta monsta, Level level){
        CollisionType collision = new CollisionHandler(monsta).handleMonsta();
        if (collision != CollisionType.STANDARD && monsta.getHealthState() == State.DEAD) return false;

        switch(collision){
            case CollisionType.TOP -> {return true;}
            case CollisionType.SIDE -> {
                monsta.updateSprite();
                monsta.updateX();
            }

            case CollisionType.STANDARD -> {
                handleDying(monsta, level);
                return true;
            }
            case CollisionType.CORNER -> {
                monsta.updateSprite();
                monsta.updateX();
                return true;
            }
            default -> {}
        }
        return false;
    }

    /**
     * Handles the collisions between an enemy's projectile and Bubblun
     * @param enemy enemy
     */
    public static void handleEnemyBubble(Shooting enemy){
        Bubble bubble = enemy.getBubble();

        if(bubble != null){
            Bubblun player = Bubblun.getInstance();
            if(CollisionHandler.bubHit(bubble, player)) {
                if(player.getHealthState() == State.STANDARD && !player.isWet()) {
                    if(bubble instanceof Fireball) player.melt();
                    else player.loseHealth();
                }
                bubble.pop();
            }
            bubble.update();
        }
    }

    /**
     * Handles an enemy's death and what items to be dropped
     * @param enemy enemy
     * @param level current level
     */
    public static void handleDying(Enemy enemy, Level level){
        if (enemy.getHealthState() == State.DEAD && enemy.getState() == State.BURNT) {
            level.getItems().add(new Item(enemy.getX(), enemy.getY(), ItemType.ORANGE_DIAMOND));
            level.getEnemies().remove(enemy);
        }

        else if (enemy.getHealthState() == State.DEAD && enemy.getState() == State.STRUCK) {
            level.getItems().add(new Item(enemy.getX(), enemy.getY(), ItemType.YELLOW_DIAMOND));
            level.getEnemies().remove(enemy);
        }

        else if (enemy.getHealthState() == State.STARSTRUCK){
            level.getItems().add(new Item((enemy.getX() + enemy.getX()%Model.TILE_SIZE), -Model.TILE_SIZE*2, CollisionHandler.findSpawnY(enemy.getX() + enemy.getX()%Model.TILE_SIZE, enemy.getY() + enemy.getY()%Model.TILE_SIZE), ItemType.PINK_DIAMOND));
            level.getEnemies().remove(enemy);
        }

        else if (enemy.getHealthState() == State.DEAD) {
            level.setCurrEnemyMultiplier();
            level.getItems().add(enemy.drop(level.decrementEnemyMultiplier()));
            level.getEnemies().remove(enemy);
        }
    }
}
