package game.model;

import game.model.entities.*;
import game.model.entities.bubbles.*;
import game.model.entities.bubbles.special_bubbles.*;
import game.model.entities.opps.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Class that handles the interaction between each entity and the rest of entities and the level
 */
public class MovementManager {

    private static Level level;

    /**
     * Sets level
     * @param lev current level
     */
    public static void setLevel(Level lev){ level = lev; }

    /**
     * Handles the interaction between a enemy and the rest of the level.
     * @param enemy enemy
     */
    public static void moveEnemy(Enemy enemy) {

        boolean specificBehaviour = CollisionManager.enemyCollisions(enemy, level);
        if (enemy.getHealthState() == State.DYING) enemy.updateSprite();

        if(enemy instanceof Banebou || enemy instanceof Invader) enemy.updateY();
        else enemy.updateY(specificBehaviour);
        enemy.update();

        if(enemy instanceof SkelMonsta && enemy.getHealthState() == State.DEAD) level.getEnemies().remove(enemy);
    }

    /**
     * Handles item life cycle in the level
     * @param item item
     * @param items array of all items
     */
    public static void moveItem(Item item, ArrayList<Item> items){
        item.update();
        if((item.getState() == State.DEAD && item.isUp()) || item.isExpired()) items.remove(item);
    }

    /**
     * Handles the interaction between a bubble and the rest of the level. Handles its life cycle in the level, the game mechanic of having absorbed enemies, updates the bubble
     * @param bubble bubble
     * @param bubbles array of all bubbles
     * @param enemies array of all enemies
     * @param player Bubblun instance
     */
    public static void moveBubble(BBubble bubble, ArrayList<BBubble> bubbles, ArrayList<Enemy> enemies, Bubblun player) {
        level.handleTimer();
        //if the BBubble has popped or is out of bounds:
        if (bubble != null && bubble.getState() == State.POPPED) {
            //if there's an enemy inside, make it respawn and remove the bubble
            Enemy enemy = bubble.getAbsordbedEnemy();
            if (enemy != null) {
                handleEnemyInside(bubble, enemy, enemies);
                //used to make pop animation when enemies get out of a bubble
                BBubble escamotageBubble = new BBubble(bubble.getX(), bubble.getY(), 0, false, false);
                escamotageBubble.setState(State.FLOATING);
                escamotageBubble.pop();
                bubbles.add(escamotageBubble);
            }
            bubbles.remove(bubble);
        }

        //normal BBubble handling
        else{
            CollisionHandler bubbleCollision = new CollisionHandler(bubble);

            //handling collisions between bubbles, blocks and the player
            CollisionManager.checkBubbleBub(bubbleCollision.checkBub(bubbleCollision.handleBubbleWithBlocks(), player), bubble, player, level);

            //handling collisions between BBubbles
            for(BBubble otherBubble : bubbles){
                if (otherBubble==null) continue;
                if(!bubble.equals(otherBubble)) CollisionManager.doubleBubbleCollisions(bubbleCollision, bubble, otherBubble);
            }

            Enemy enemyHit = (Enemy)bubbleCollision.entityHit(enemies);
            if(enemyHit != null && enemyHit.getAnimation() != Animation.DYING) CollisionManager.checkEnemyHit(enemyHit, bubble, enemies);
            bubble.update();
        }
    }

    /**
     * Handles the interaction between Bubblun and the level. Handles items and enemies hit, present elements, updates Bubblun
     * @param player Bubblun instance
     * @param items array of all items
     * @param enemies array of all enemies
     */
    public static void moveBubblun(Bubblun player, ArrayList<Item> items, ArrayList<Enemy> enemies){
        CollisionHandler collisionHandler = new CollisionHandler(player);

        Item itemHit = (Item)collisionHandler.entityHit(items);


        if(itemHit != null && itemHit.getType() != null) {

            if(ItemType.isPowerUp(itemHit.getType())) {
                player.setPowerUp(itemHit.getType());
                Model.getInstance().addSound(SoundEffect.PICK_UP_SPECIAL_ITEM);
            }

            //handle points
            if(itemHit.getState() != State.DEAD){
                Model.getInstance().getPlayerStats().addScore(itemHit.getType().getValue());
                itemHit.showValue();
                Model.getInstance().addSound(SoundEffect.PICK_UP_ITEM);
            }
        }

        if(player.getHealthState() == State.STANDARD && !player.isWet()){
            Enemy e = (Enemy)collisionHandler.entityHit(enemies);
            if(e != null && e.getHealthState() != State.DYING && e.getHealthState() != State.DEAD){
                player.loseHealth();
                if(e instanceof SkelMonsta) ((SkelMonsta)e).setKiller();
            }
        }
        handleElements(level.getElements(), player);
        CollisionManager.bubblunCollisions(player);
    }

    /**
     * Handles the interaction between a special bubble and Bubblun, updates the bubble
     * @param specialBubble bubble
     * @param specialBubbles array of all special bubbles
     * @param player Bubblun instance
     */
    public static void moveSpecialBubble(SpecialBubble specialBubble, ArrayList<SpecialBubble> specialBubbles, Bubblun player){
        if(CollisionManager.checkSpecialBubbleBub(specialBubble, player)){
            if(specialBubble instanceof LaudeBubble) {
                specialBubble.pop();
                Model.getInstance().addSound(SoundEffect.PICK_UP_30LODE);
            }
            else specialBubble.pop(level.getElements());
            specialBubbles.remove(specialBubble);
        } else specialBubble.update();

        if(specialBubble.getY() > Model.GAME_SCREEN_HEIGHT +24 || specialBubble.getY() < -48) {
            specialBubbles.remove(specialBubble);
        }

    }

    /**
     * Handles the interaction between an element and all the entities, its life cycle in the level, updates each element
     * @param element element
     * @param elements array of all elements
     */
    public static void moveElement(Element element, ArrayList<Element> elements){
        switch (element.getClass().getSimpleName()){
            case "WaterFlow" -> {
                //if there are no blocks in the flow, it
                if(element.getContent().isEmpty()){
                    for(int i=0; i < ((WaterFlow)element).getSwimmingVictims(); i++){
                        int spawnX = Model.TILE_SIZE*7 + i*Model.TILE_SIZE*2;
                        int spawnY = CollisionHandler.findSpawnY(spawnX);
                        level.getItems().add(new Item(spawnX, 0, spawnY, ItemType.BLUE_DIAMOND));
                    }
                    elements.remove(element);
                }
                else CollisionManager.checkWaterCollision((WaterFlow.WaterBlock) element.getContent().getLast(), (WaterFlow) element);
            }

            case "Blaze" -> {
                element.update();

                ArrayList<Blaze.FireBlock> flow = element.getContent();

                if(flow.isEmpty()) elements.remove(element);
                else{
                    for(int i=0; i<flow.size(); i++) {
                        //handles the fire blocks' behaviour
                        flow.get(i).update();
                    }
                }
            }

            case "Storm" -> {
                element.update();
                ArrayList<Storm.Lightning> flow = element.getContent();
                if(flow.isEmpty()) elements.remove(element);
                else flow.getFirst().update();
            }
        }
    }

    /**
     * Handles the Star life cycle in the level
     * @param star star
     * @param stars array of all stars
     */
    public static void moveStar(Star star, ArrayList<Star> stars){
        star.update();
        if(star.getY() > Model.GAME_SCREEN_HEIGHT) {stars.remove(star);}
    }

    /**
     * Handles the interaction between the train and bubblun in the level
     * @param train train
     * @param trains array of all trains
     * @param player bubblun instance
     */
    public static void moveTrain(Train train, ArrayList<Train> trains, Bubblun player){
        if(train.getHitbox().intersects(player.getHitbox()) && player.getState() == State.STANDARD){
            switch (train.getLine()){
                case METRO_C -> {
                    player.gainHealth();
                    trains.remove(train);
                    Model.getInstance().getPlayerStats().addScore(train.getLine().getValue());
                }
                case METRO_B -> {
                    trains.remove(train);
                    level.addTrain();
                    Model.getInstance().getPlayerStats().addScore(train.getLine().getValue());

                }
                default -> {
                    if (player.getHealthState() != State.INVULNERABLE) {
                        player.loseHealth();
                        trains.remove(train);
                        Model.getInstance().getPlayerStats().addScore(train.getLine().getValue());
                    }
                }
            }
        }
        train.update();
        if(train.getY() < 0) {trains.remove(train);}
    }

    /**
     * Handles the enemy inside a BBubble (and its respawning or dying)
     * @param bubble the BBubble containing the enemy
     * @param enemy the Enemy
     * @param enemies the ArrayList containing all the enemies (to which a respawning Enemy has to be re-added)
     */
    public static void handleEnemyInside(BBubble bubble, Enemy enemy, ArrayList<Enemy> enemies) {
        fineTuneRespawn(bubble, enemy);
        //if the enemy needs to get out of the BBubble (it hasn't been hit by bub)
        if(enemy.getHealthState() != State.DYING) {
            enemy.setAnimation(enemy.getAnimation() == Animation.LEFT ? Animation.ANGRY_LEFT: Animation.ANGRY_RIGHT);
            enemy.setState(State.ANGRY);
        }
        enemies.add(enemy);
    }

    public static void handleElements(ArrayList<Element> elements, Bubblun player){
        CollisionHandler collisionH = new CollisionHandler(player);
        for (Element element : elements) {
            if (element instanceof WaterFlow) {
                ArrayList<WaterFlow.WaterBlock> flow = element.getContent();
                WaterFlow.WaterBlock waterBlock = (WaterFlow.WaterBlock)collisionH.entityHit(flow);
                if(waterBlock != null && !player.isJumping()) {
                    player.setX(flow.get(Math.min(flow.size()-1, 8)).getX());
                    player.setY(flow.get(Math.min(flow.size()-1, 8)).getY()-24);
                    player.setWet(true);
                    return;
                } else {
                    player.setWet(false);
                }
            }
        }
        if(player.getHealthState() == State.STANDARD || player.getHealthState() == State.BURNT){
            List<Element> blazes = level.getElements().stream().filter(x -> x.getClass() == Blaze.class).toList();

            for(Element blaze : blazes){
                ArrayList<Blaze.FireBlock> flow = ((Blaze)blaze).getContent();
                Blaze.FireBlock f = (Blaze.FireBlock) collisionH.entityHit(flow);
                if(f != null && f.getAnimation() != Animation.FIRE_DROPPING){
                    player.burn();
                }
            }
        }
    }

    /**
     * Handles fine-tuning for respawning enemies that were caught in a BBubble, as to not cause bugs.
     * @param bubble the BBubble containing the enemy
     * @param enemy the enemy contained
     */
    public static void fineTuneRespawn(BBubble bubble, Enemy enemy){
        int respawnXMargin = 0;
        //fine-tuning for the screen edges
        if (bubble.getX()-12 <= Model.TILE_SIZE * 2) respawnXMargin = 20;
        else if (bubble.getX()+12 >= Model.SCREEN_WIDTH - (Model.TILE_SIZE* 4)) respawnXMargin = -20;
        //ready to respawn
        enemy.setX(bubble.getX()+respawnXMargin);
        enemy.setY(bubble.getY() - bubble.getY() % 6); //%6 necessary to avoid spawning at a height that would cause issues

        //Monsta
        if(enemy instanceof Monsta) enemy.setY(enemy.getY() + Model.TILE_SIZE);

        enemy.updateHitbox();
    }



}