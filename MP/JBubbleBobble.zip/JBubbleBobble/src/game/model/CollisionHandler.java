package game.model;

import game.model.entities.*;
import game.model.entities.bubbles.BBubble;
import game.model.entities.opps.Enemy;
import game.model.entities.opps.Invader;
import game.model.entities.opps.Monsta;

import java.awt.*;
import java.awt.geom.Line2D;
import java.util.ArrayList;

/**
 * Used to handle collision inside the level
 */
public class CollisionHandler {
    private Entity e;
    private static Block[][] blocksArray;

    /**
     * Sets the Entity to check the collisions on.
     * @param e Entity
     */
    public CollisionHandler(Entity e) {
        this.e = e;
    }

    /**
     * Sets the level block array.
      * @param bArray level Blocks
     */
    public void setBlocksArray(Block[][] bArray) {
        blocksArray = bArray;
    }

    /**
     * Gets the entity's hitbox and translates it by its velocity to accurately guess its next position.
     * @return the Entity's future position.
     */
    public Rectangle handleHitbox() {
        Rectangle hitbox = e.getHitbox();
        hitbox.translate(e.getVelX(), e.getVelY());
        return hitbox;
    }

    /**
     * Shifts the Entity's hitbox to the position it will occupy in the next frame.
     * @param e Entity
     * @return the Entity's hitbox shifted to the next position
     */
    public static Rectangle handleHitbox(Entity e){
        Rectangle hitbox = e.getHitbox();
        hitbox.translate(e.getVelX(), e.getVelY());
        return hitbox;
    }

    // Collision Handlers
    // ==========================================================

    /**
     * Handles Bubblun's collisions. Checks for bound and block collisions.
     * @return BBubble's collision for this frame.
     */
    public CollisionType handleBubblun(){
        Rectangle hitbox = handleHitbox();

        //checks for bound collisions
        CollisionType bound = boundCollisions(hitbox);
        if(bound != CollisionType.NO_COLLISION) return bound;

        return handlePlayerCollisions(hitbox);
    }

    /**
     * Helper method to handle Bubblun's collisions. Uses accurate guesses to calculate Bubblun's surrounding blocks in the array, in order to avoid checking too many blocks.
     * @param hitbox Bubblun's hitbox.
     * @return Bubblun's collision with the first colliding block found, or no collision.
     */
    public CollisionType handlePlayerCollisions(Rectangle hitbox){

        //guesses as to where the player is in the array
        int guessSrtX = Math.max(hitbox.x/Model.TILE_SIZE,0);
        int guessSrtY = Math.max(hitbox.y/Model.TILE_SIZE,0);

        int guessEndY = Math.min(guessSrtY+11,26);
        int guessEndX = Math.min(guessSrtX+3,31);


        for (int y=guessSrtY; y<guessEndY; y++) {
            for (int x=guessSrtX; x<guessEndX; x++) {
                if (blocksArray[y][x].isSolid()) {
                    Rectangle blockHit = new Rectangle(blocksArray[y][x].getSrtX(), blocksArray[y][x].getSrtY(), Model.TILE_SIZE, Model.TILE_SIZE);

                    if (e.getState() == State.JUMPING) return CollisionType.NO_COLLISION;
                    if (isSide(hitbox, blockHit)) return CollisionType.SIDE;
                    if (isStandard(hitbox, blockHit)) return CollisionType.STANDARD;
                }
            }
        }
        return CollisionType.NO_COLLISION;
    }

    /**
     * Handles a bubble's collisions with blocks. Uses accurate guesses to calculate Bubblun's surrounding blocks in the array, in order to avoid checking too many blocks.
     * @return the bubble's collision with blocks in the current frame, if there is one.
     */
    public CollisionType handleBubbleWithBlocks(){

        Rectangle hitbox = e.getHitbox();
        hitbox.translate(e.getVelX() * ((BBubble)e).getSpeedMultiplier(), e.getVelY()*((BBubble)e).getSpeedMultiplier());

        //guesses as to where the bubble is in the array
        int guessSrtX = Math.max(hitbox.x/Model.TILE_SIZE-1, 0);
        int guessSrtY = Math.max(hitbox.y/Model.TILE_SIZE-1, 0);
        int guessEndY = Math.min(guessSrtY+2,26);
        int guessEndX = Math.min(guessSrtX+3,31);

        //checks for bound collisions
        CollisionType boundBubble = boundFloatingCollisions(hitbox);
        if(boundBubble != CollisionType.NO_COLLISION) return boundBubble;


        return handleFloatingCollisions(hitbox, guessSrtX, guessSrtY, guessEndX, guessEndY);
    }

    /**
     * Handles a Bubble's or Monsta's collisions with blocks by adding them to an array and analysing it. Uses accurate guesses to calculate Bubblun's surrounding blocks in the array, in order to avoid checking too many blocks.
     * @param hitbox Entity's hitbox
     * @param guessSrtX approximate x position of where the bubble could be (used to make the code more efficient)
     * @param guessSrtY approximate y position of where the bubble could be (used to make the code more efficient)
     * @param guessEndX approximate x position of where the bubble could be (used to make the code more efficient)
     * @param guessEndY approximate y position of where the bubble could be (used to make the code more efficient)
     * @return the type of collision the bubble is having with the surrounding blocks in the current frame.
     */
    public CollisionType handleFloatingCollisions(Rectangle hitbox, int guessSrtX, int guessSrtY, int guessEndX, int guessEndY){
        ArrayList<CollisionType> collisions = new ArrayList<>();

        for (int y=guessSrtY; y<guessEndY; y++) {
            for (int x=guessSrtX; x<guessEndX; x++) {
                if (blocksArray[y][x].isSolid()) {
                    Rectangle blockHit = new Rectangle(blocksArray[y][x].getSrtX(), blocksArray[y][x].getSrtY(), Model.TILE_SIZE, Model.TILE_SIZE);
                    if (isSideBubble(hitbox, blockHit)) collisions.add(CollisionType.SIDE);
                    if (isTop(hitbox, blockHit)) collisions.add(CollisionType.TOP);
                    //Monsta behaves exactly like a bubble, except it has Standard collisions
                    if((e instanceof Monsta && isStandard(hitbox, blockHit))) collisions.add(CollisionType.STANDARD);
                }
            }
        }
        return processCollisions(collisions);
    }

    /**
     * Analyses a Bubble or a Monsta's ArrayList of current collisions with blocks to see which collision will prevail.
     * @param collisions list of collisions detected
     * @return the final collision.
     */
    public CollisionType processCollisions(ArrayList<CollisionType> collisions){
        if(collisions.isEmpty()) return CollisionType.NO_COLLISION;

        boolean containsSide = collisions.contains(CollisionType.SIDE);
        boolean containsTop = collisions.contains(CollisionType.TOP);
        boolean containsStandard = collisions.contains(CollisionType.STANDARD);

        if(containsSide && !containsTop && !containsStandard) return CollisionType.SIDE;
        if(containsTop && !containsSide && !containsStandard) return  CollisionType.TOP;
        if(containsStandard && !containsTop && !containsSide) return CollisionType.STANDARD;

        if((collisions.getFirst() == CollisionType.TOP || collisions.getFirst() == CollisionType.STANDARD) && containsSide)
            return CollisionType.CORNER;

        //safe return
        return CollisionType.NO_COLLISION;
    }

    /**
     * Checks the different bound collisions for bubbles and Monsta.
     * @param hitbox Entity's hitbox
     * @return the type of collision made
     */
    public CollisionType boundFloatingCollisions(Rectangle hitbox){
        if (cornerBoundBubble(hitbox)) return CollisionType.CORNER;
        if (outOfBounds(hitbox)) return CollisionType.BOUNDS;
        if (sideBoundBubble(hitbox)) return CollisionType.SIDE;
        if(isVoid(hitbox)) return CollisionType.VOID;

        return CollisionType.NO_COLLISION;
    }

    /**
     * Handles the enemy's collisions with blocks around it.
     * @return the collision the enemy is having in the current frame.
     */
    public CollisionType handleEnemy() {

        Rectangle hitbox = handleHitbox();

        if(e.getState() == State.SPAWNING) return CollisionType.NO_COLLISION;

        CollisionType bound = boundCollisions(hitbox);
        if(bound != CollisionType.NO_COLLISION) return bound;


        //guesses as to where the bubble is in the array
        int guessSrtX = Math.max(hitbox.x/Model.TILE_SIZE-1, 0);
        int guessSrtY = Math.max(hitbox.y/Model.TILE_SIZE-1, 0);
        int guessEndY = Math.min(guessSrtY+5,26);
        int guessEndX = Math.min(guessSrtX+5,31);

        for (int y=guessSrtY; y<guessEndY; y++) {
            for (int x=guessSrtX; x<guessEndX; x++) {
                if (blocksArray[y][x].isSolid()) {
                    Rectangle blockHit = new Rectangle(blocksArray[y][x].getSrtX(), blocksArray[y][x].getSrtY(), Model.TILE_SIZE, Model.TILE_SIZE);
                    if (isSide(hitbox, blockHit)) return CollisionType.SIDE;
                    if (isStandard(hitbox, blockHit)) return CollisionType.STANDARD;
                    //invader uses the elements' standard collision
                    if(e instanceof Invader && isStandardElement(hitbox, blockHit)) return CollisionType.STANDARD;
                }
            }
        }
        return CollisionType.NO_COLLISION;
    }

    /**
     * Handles Monsta's collisions with blocks around it.
     * Monsta's collisions are similar to the bubbles', but with the addition of standard collisions.
     * @return the collision Monsta is having in the current frame.
     */
    public CollisionType handleMonsta(){

        if(e.getState() == State.SPAWNING) return CollisionType.NO_COLLISION;

        Rectangle hitbox = handleHitbox();

        CollisionType boundBubble = boundFloatingCollisions(hitbox);
        if(boundBubble != CollisionType.NO_COLLISION) return boundBubble;

        return handleFloatingCollisions(hitbox,0,0,31,26);
    }

    /**
     * Handles a bubble's collisions with the player.
     * @param collision collision between player and bubble
     * @param bub Bubblun
     * @return the collision the bubble is having with the player.
     */
    public CollisionType checkBub(CollisionType collision, Bubblun bub){
        boolean sideBub = isSideBubble(bub.getHitbox(), e.getHitbox());
        boolean standardBub = bubAbove(bub.getHitbox(), e.getHitbox()) && bub.isFalling();
        boolean intersectsBub = bubHit(e, bub);

        if(!intersectsBub) return collision;

        //if bub can jump on top of a bubble
        if(((BBubble)e).getAbsordbedEnemy() == null && standardBub &&
                (e.getState() != State.POPPED && e.getState() != State.SPAWNING))
        {
            return CollisionType.UNDER_BUB;
        }

        //if it collides with Bub and with the ceiling, it has to pop
        if (collision == CollisionType.TOP) return CollisionType.BUBBLUN;

        //if it doesn't collide with anything but Bub, depending on Bub's direction, it's being hit from the right or the left.
        if  (collision == CollisionType.NO_COLLISION)
            return bub.getAnimation().toString().endsWith("RIGHT") ? CollisionType.HIT_LEFT : CollisionType.HIT_RIGHT;

        //if it collides with Bub and the side of a block or a corner, it has to pop
        if (collision == CollisionType.SIDE || collision == CollisionType.CORNER) return CollisionType.BUBBLUN;

        //if bub is hitting it from the side and it is colliding with blocks on the side, it has to pop
        if(sideBub && (collision == CollisionType.SIDE || collision == CollisionType.BOUNDS || collision == CollisionType.CORNER))
            return CollisionType.BUBBLUN;

        return collision; //safe return
    }

    /**
     * Handles the collision between two bubbles.
     * @param otherBubble the other bubble this class's entity is colliding with.
     * @return the collision the two bubbles are having.
     */
    public CollisionType handleDoubleBubble(BBubble otherBubble){
        Rectangle hitbox = new Rectangle(e.getX() + Model.TILE_SIZE/2 +1 , e.getY() + Model.TILE_SIZE/2 +1, Model.TILE_SIZE-2, Model.TILE_SIZE-2);
        hitbox.translate(e.getVelX(), e.getVelY());
        Rectangle otherHitbox = otherBubble.getHitbox();

        if(isTopDoubleBubble(hitbox, otherHitbox)) return CollisionType.TOP;
        if(isSideBubbleLeft(hitbox, otherHitbox)) return CollisionType.HIT_LEFT;
        if(isSideBubbleRight(hitbox, otherHitbox)) return CollisionType.HIT_RIGHT;

        return CollisionType.NO_COLLISION;
    }

    /**
     * Used to check generic collisions between entities (the player and enemies, bubbles and enemies, WaterBlocks and the player, enemies and WaterBlocks)
     * @param entities list of entities to check collision on
     * @return Entity that collides
     */
    public <T extends Entity> Entity entityHit(ArrayList<T> entities){
        return entities.stream().filter(entity -> entity.getHitbox().intersects(e.getHitbox()))
                .filter(entity -> entity.getY()>0).findFirst().orElse(null);
    }

    /**
     * Handles a WaterBlock's next position collisions.
     * The next position is calculated based on where the block is currently heading,
     * and the collisions are then analysed by a helper method.
     * @return type of collision detected
     */
    public CollisionType handleWaterBlock(){

        ArrayList<CollisionType> collisions = new ArrayList<>();

        Animation animation = e.getAnimation();

        Rectangle hitbox = switch(animation){
            case WATER_LEFT, WATER_DOWN_LEFT-> new Rectangle(e.getX()-Model.TILE_SIZE, e.getY(), Model.TILE_SIZE, Model.TILE_SIZE);
            case WATER_RIGHT, WATER_DOWN_RIGHT -> new Rectangle(e.getX()+Model.TILE_SIZE, e.getY(), Model.TILE_SIZE, Model.TILE_SIZE );
            default -> new Rectangle(e.getX(), e.getY()+4, Model.TILE_SIZE, Model.TILE_SIZE);
        };


        //guesses as to where the bubble is in the array
        int guessSrtX = Math.max(hitbox.x/Model.TILE_SIZE-1, 0);
        int guessSrtY = Math.max(hitbox.y/Model.TILE_SIZE-1, 0);
        int guessEndY = Math.min(guessSrtY+3,26);
        int guessEndX = Math.min(guessSrtX+3,31);

        for (int y=guessSrtY; y<guessEndY; y++){
            for(int x=guessSrtX; x<guessEndX; x++){
                if (blocksArray[y][x].isSolid()) {
                    Rectangle blockHitbox = new Rectangle(blocksArray[y][x].getSrtX(), blocksArray[y][x].getSrtY(), Model.TILE_SIZE, Model.TILE_SIZE);

                    if (isStandardElement(hitbox, blockHitbox)) collisions.add(CollisionType.STANDARD);
                    if (isSideElementLeft(hitbox, blockHitbox)) collisions.add(CollisionType.SIDE_LEFT);
                    if (isSideElementRight(hitbox, blockHitbox)) collisions.add(CollisionType.SIDE_RIGHT);
                }
            }

        }
        return processElementCollisions(collisions, hitbox);
    }

    /**
     * Processes an element's future collisions with blocks to see which collision will prevail.
     * @param collisions list of collisions detected
     * @param hitbox Entity's hitbox
     * @return the final collision
     */
    public CollisionType processElementCollisions(ArrayList<CollisionType> collisions, Rectangle hitbox){
        if(collisions.isEmpty()) return CollisionType.NO_COLLISION;

        boolean containsSideLeft = collisions.contains(CollisionType.SIDE_LEFT);
        boolean containsSideRight = collisions.contains(CollisionType.SIDE_RIGHT);
        boolean containsStandard = collisions.contains(CollisionType.STANDARD);

        if((containsSideLeft || containsSideRight) && !containsStandard){
            boolean standard = false;
            hitbox.translate(0, 20);

            //guesses as to where the bubble is in the array
            int guessSrtX = Math.max(hitbox.x/Model.TILE_SIZE-1, 0);
            int guessSrtY = Math.max(hitbox.y/Model.TILE_SIZE-1, 0);
            int guessEndY = Math.min(guessSrtY+3,26);
            int guessEndX = Math.min(guessSrtX+3,31);

            for (int y=guessSrtY; y<guessEndY; y++){
                for(int x=guessSrtX; x<guessEndX; x++){
                    if (blocksArray[y][x].isSolid()) {
                        if (isStandardElement(hitbox, blocksArray[y][x].getHitbox())) standard = true;
                    }
                }
            }

            long lAmount = collisions.stream().filter(x->x==CollisionType.SIDE_LEFT).count();
            long rAmount = collisions.stream().filter(x->x==CollisionType.SIDE_RIGHT).count();

            if(standard && lAmount>rAmount) return  CollisionType.CORNER_LEFT;
            if(standard && rAmount>lAmount) return CollisionType.CORNER_RIGHT;
            return CollisionType.NO_COLLISION;
        }

        if(containsSideLeft && containsSideRight && containsStandard) return CollisionType.STANDARD;


        if(containsStandard && !containsSideLeft && !containsSideRight) return CollisionType.STANDARD;

        if(containsStandard && containsSideLeft) return CollisionType.CORNER_LEFT;
        if(containsStandard && containsSideRight) return CollisionType.CORNER_RIGHT;

        //safe return
        return CollisionType.NO_COLLISION;
    }

    /**
     * Checks if an Entity collides with Bubblun.
     * @param e Entity
     * @param bub Bubblun
     * @return whether there is a collision or not
     */
    public static boolean bubHit(Entity e, Bubblun bub){
        return handleHitbox(e).intersects(bub.getHitbox());
    }

    // Collision type checks
    // ==========================================================

    /**
     * Used to determine where the diamonds spawned from killing an enemy with the WaterFlow and power-ups have to land.
     * @param x starting x
     * @return landing y coordinate
     */
    public static int findSpawnY(int x) {
        for (int i=1; i<blocksArray.length; i++) {
            if (blocksArray[i][Math.min(x/Model.TILE_SIZE,31)].isSolid()) {
                return blocksArray[i][Math.min(x/Model.TILE_SIZE,31)].getSrtY();
            }
        }
        return Model.SCREEN_HEIGHT-2*Model.TILE_SIZE;
    }

    /**
     * Used to determine the final y for diamonds spawned when an enemy is hit by a star and for Blazes spawned when a FireBubble is hit.
     * @param x starting x
     * @param y starting y
     * @return landing y coordinate
     */
    public static int findSpawnY(int x, int y) {
        for (int i=y/Model.TILE_SIZE; i<blocksArray.length; i++) {
            if (blocksArray[i][Math.min(x/Model.TILE_SIZE,31)].isSolid()) {
                return blocksArray[i][Math.min(x/Model.TILE_SIZE,31)].getSrtY();
            }
        }
        return Model.SCREEN_HEIGHT-2*Model.TILE_SIZE;
    }

    /**
     * Used to determine the final x for Hidegons' and Mighta's shoot
     * @param x starting x
     * @param y starting y
     * @param dir direction
     * @return x coordinate where the shoot has to disappear
     */
    public static int findEndX(int x, int y, int dir) {
        for(int i=(x/Model.TILE_SIZE); i>=0 && i<32; i+=dir) {
            if (blocksArray[Math.max(Math.min(y,26),0)/Model.TILE_SIZE][i].isSolid() || blocksArray[Math.max(Math.min(y,26),0)/Model.TILE_SIZE+1][i].isSolid()) {
                return blocksArray[Math.max(y,0)/Model.TILE_SIZE][i].getSrtX()+(dir==1 ? -Model.TILE_SIZE*2 : Model.TILE_SIZE);
            }
        }
        return 3*Model.TILE_SIZE;
    }

    //bounds:

    /**
     * Checks the different bound collisions.
     * @param hitbox the Entity's hitbox
     * @return the kind of bound collision, if there is one
     */
    public CollisionType boundCollisions(Rectangle hitbox){
        if(isVoid(hitbox)) return CollisionType.VOID;
        if (cornerBound(hitbox)) return CollisionType.CORNER;
        if (outOfBounds(hitbox)) return CollisionType.BOUNDS;
        if (sideBound(hitbox)) return e instanceof Enemy ? CollisionType.SIDE_BOUNDS : CollisionType.SIDE;
        return CollisionType.NO_COLLISION;
    }
    /**
     * Checks if an Entity is above a level.
     * @param hitbox the Entity's hitbox
     * @return whether the Entity is out of bounds in height
     */
    private boolean outOfBounds(Rectangle hitbox) {
        return hitbox.y+hitbox.height <= 0;
    }

    /**
     * Checks if an Entity is falling out of a level.
     * @param hitbox the Entity's hitbox
     * @return whether the Entity is falling in the void at the bottom of the level.
     */
    public boolean isVoid(Rectangle hitbox){
        return hitbox.y+(hitbox.height) > Model.SCREEN_HEIGHT-Model.TILE_SIZE*2;
    }

    /**
     * Checks if an Entity is colliding with one of the four corners of the level.
     * @param hitbox the Entity's hitbox
     * @return whether the Entity is in one of the corners of the level.
     */
    private boolean cornerBound (Rectangle hitbox) {
        return (hitbox.y >= Model.SCREEN_HEIGHT-6 * Model.TILE_SIZE || hitbox.y <= Model.TILE_SIZE)&&
                (hitbox.x <= 2 * Model.TILE_SIZE || hitbox.x >= Model.SCREEN_WIDTH-4 * Model.TILE_SIZE);
    }

    /**
     * Checks if an Entity is colliding with the sides of the level.
     * @param hitbox the Entity's hitbox
     * @return whether the Entity is colliding with the sides of the level.
     */
    private boolean sideBound (Rectangle hitbox){ return hitbox.x <= 2*Model.TILE_SIZE || hitbox.x >= Model.SCREEN_WIDTH-4*Model.TILE_SIZE; }


    //classic:

    /**
     * Checks if an Entity is falling on a block.
     * @param c the Entity's hitbox
     * @param bl the block's hitbox
     * @return whether it's a standard collision (entity falling onto a block)
     */
    public boolean isStandard(Rectangle c, Rectangle bl){
        Line2D bottomLine = new Line2D.Double(c.x, c.y + c.height,
                c.x + c.width, c.y + c.height);

        return (bottomLine.intersectsLine(bl.x + 5, bl.y, bl.x + bl.width - 5, bl.y) && bottomLine.getX1()>Model.TILE_SIZE);
    }

    /**
     * Checks if the rectangle representing the lower half of an Entity's hitbox intersects a block.
     * @param hitbox the Entity's lower half hitbox
     * @param blockRect the block's hitbox
     * @return whether it's a side collision
     */
    public boolean isSide(Rectangle hitbox, Rectangle blockRect){
        Rectangle feetHitbox = new Rectangle(hitbox.x, hitbox.y + (hitbox.height / 2),
                hitbox.width, hitbox.height / 2);
        return feetHitbox.intersects(blockRect);
    }
    /**
     * Checks if an Entity is colliding with a block above it.
     * @param hitbox the Entity's hitbox
     * @param bl the block's hitbox
     * @return whether it's a top collision
     */
    public boolean isTop(Rectangle hitbox, Rectangle bl){
        Line2D topLine = new Line2D.Double(hitbox.x, hitbox.y, hitbox.x + hitbox.width, hitbox.y);
        return topLine.intersectsLine(bl.x+3, bl.y + bl.height+3, bl.x + bl.width+3, bl.y + bl.height+3);
    }

    //bubble-specific:

    /**
     * Checks if a bubble is colliding with the sides of the level
     * @param hitbox the bubble's hitbox
     * @return whether a bubble is colliding with the sides of the level.
     */
    private boolean sideBoundBubble(Rectangle hitbox){
        return hitbox.x <= 2*Model.TILE_SIZE || hitbox.x >= Model.SCREEN_WIDTH-(3*Model.TILE_SIZE - 6);
    }

    /**
     * Checks if a bubble is in one of the two top corners of the screen
     * @param hitbox the bubble's hitbox
     * @return whether a bubble is in one of the top corners of the screen.
     */
    private boolean cornerBoundBubble (Rectangle hitbox) {
        return (hitbox.y >= Model.SCREEN_HEIGHT-6 * Model.TILE_SIZE || hitbox.y <= Model.TILE_SIZE)&&
                (hitbox.x <= 2 * Model.TILE_SIZE || hitbox.x >= Model.SCREEN_WIDTH-3 * Model.TILE_SIZE);
    }

    /**
     * Checks if a bubble is intersecting with another bubble on its left and/or right by calling other methods
     * @param hitbox the first bubble's hitbox
     * @param bl the second bubble's hitbox
     * @return whether a bubble is intersecting with another bubble on the left and/or on the right.
     */
    public boolean isSideBubble(Rectangle hitbox, Rectangle bl){
        return isSideBubbleLeft(hitbox, bl) || isSideBubbleRight(hitbox, bl);
    }

    /**
     * Checks if a bubble is intersecting with another bubble on its left.
     * @param hitbox the first bubble's hitbox
     * @param bl the second bubble's hitbox
     * @return whether a bubble is intersecting with another bubble on the left.
     */
    public boolean isSideBubbleLeft(Rectangle hitbox, Rectangle bl){
        Rectangle side = new Rectangle(bl.x + bl.width, bl.y, 5, bl.height);
        return hitbox.intersects(side);
    }
    /**
     * Checks if a bubble is intersecting with another bubble on its right.
     * @param hitbox the first bubble's hitbox
     * @param bl the second bubble's hitbox
     * @return whether a bubble is intersecting with another bubble on the right.
     */
    public boolean isSideBubbleRight(Rectangle hitbox, Rectangle bl){
        Rectangle side = new Rectangle(bl.x - 5, bl.y, 5, bl.height);
        return hitbox.intersects(side);
    }

    /**
     * Checks if a bubble is intersecting with another bubble while going up
     * @param bubble the first bubble's hitbox
     * @param otherBubble the second bubble's hitbox
     * @return whether a bubble is intersecting with another bubble while going up
     */
    public boolean isTopDoubleBubble(Rectangle bubble, Rectangle otherBubble) {
        if (bubble.intersects(otherBubble)) {

            int topBubbleFeet = otherBubble.y + otherBubble.height;
            int bubbleTopHeight = bubble.y;
            int bubbleBottomHeight = bubble.y + bubble.height;

            //giving the top bubble a 12-pixel side "bound" inside which the other bubble can hit it for the collision to be a top
            boolean isUnderRight = bubble.x >= otherBubble.x && bubble.x+bubble.width < otherBubble.x+otherBubble.width+12;
            boolean isUnderLeft = bubble.x+bubble.width <= otherBubble.x+otherBubble.width && bubble.x > otherBubble.x-12;

            if(bubbleTopHeight <= topBubbleFeet && bubbleBottomHeight > topBubbleFeet && (isUnderRight || isUnderLeft )) return true;
        }
        return false;
    }

    /**
     * Checks if the player is landing on a bubble.
     * @param bub Bubblun's hitbox
     * @param bubble the bubble's hitbox
     * @return whether the player is hitting a bubble from above (to handle jumping on bubbles)
     */
    public boolean bubAbove(Rectangle bub, Rectangle bubble) {
        if (bub.intersects(bubble)) {

            int bubFeetHeight = bub.y + bub.height;
            int bubbleTopHeight = bubble.y;

            Line2D topLine = new Line2D.Double(bubble.x, bubbleTopHeight, bubble.x+bubble.width, bubbleTopHeight);

            //if bub's feet line is under the bubble's top line and the bubble's x positions are "inside" bub's
            if(bubFeetHeight >= bubbleTopHeight && topLine.getX1() >= bub.x && topLine.getX2() <= bub.x+bub.width) return true;
        }
        return false;
    }


    //element-specific:

    /**
     * Checks if an element has a block beneath it.
     * @param hitbox the element's hitbox
     * @param bl block's hitbox
     * @return whether the element is colliding with a block under it.
     */
    public boolean isStandardElement(Rectangle hitbox, Rectangle bl){
        Line2D bottomLine = new Line2D.Double(hitbox.x+4, hitbox.y + hitbox.height,
                hitbox.x + hitbox.width-4, hitbox.y + hitbox.height);

        //gives us some leeway to make sure it finds the collision
        Rectangle blockTop = new Rectangle(bl.x, bl.y-4, bl.width, 8 );

        //the element is colliding if its bottom is intersecting a rectangle on the top of the block
        return bottomLine.intersects(blockTop);
    }

    /**
     * Checks if an element is colliding with a block on its right.
     * @param hitbox element's hitbox
     * @param bl block's hitbox
     * @return whether the element is colliding with a block on its right.
     */
    public boolean isSideElementRight(Rectangle hitbox, Rectangle bl){
        Line2D sideLine = new Line2D.Double(hitbox.x+hitbox.width, hitbox.y+4,
                hitbox.x + hitbox.width, hitbox.y + hitbox.height-4);

        Rectangle blockLeft = new Rectangle(bl.x-2, bl.y, 4, bl.height );

        //the element is colliding if its right side is intersecting a rectangle on the left side of the block
        return sideLine.intersects(blockLeft);
    }

    /**
     * Checks if an element is colliding with a block on its left.
     * @param hitbox element's hitbox
     * @param bl block's hitbox
     * @return whether the element is colliding with a block on its left.
     */
    public boolean isSideElementLeft(Rectangle hitbox, Rectangle bl){
        Line2D sideLine = new Line2D.Double(hitbox.x, hitbox.y+4,
                hitbox.x, hitbox.y + hitbox.height-4);

        Rectangle blockRight = new Rectangle(bl.x+bl.width-2, bl.y, 4, bl.height );

        //the element is colliding if its left side is intersecting a rectangle on the right side of the block
        return sideLine.intersects(blockRight);
    }



}