package game.model;

/**
 * Enumeration that defines all type of possible collisions in the game
 */
public enum CollisionType {
    NO_COLLISION, SIDE, STANDARD, CORNER, TOP, BOUNDS, VOID, SIDE_BOUNDS, BUBBLUN,
    HIT_LEFT, HIT_RIGHT, UNDER_BUB, CORNER_LEFT, CORNER_RIGHT, SIDE_LEFT, SIDE_RIGHT;
}
