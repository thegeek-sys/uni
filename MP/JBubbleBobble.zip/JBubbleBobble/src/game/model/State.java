package game.model;

/**
 * Enumeration that defines all game states
 */
public enum State {
    ANGRY, INVULNERABLE, HIT, STANDARD, JUMPING, POPPED, SPAWNING, DEAD, DYING, FLOATING, OOB, SWIMMING,
    BURNT, STRUCK, MELTING, STARSTRUCK;
}
