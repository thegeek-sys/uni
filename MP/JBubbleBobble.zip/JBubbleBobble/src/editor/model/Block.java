package editor.model;

/**
 * Class to represent blocks in the level editor.
 */
public class Block {
    private static Block instance;
    private int x;
    private int y;
    private Direction direction;

    /**
     * Block constructor. Follows the Singleton Design Pattern.
     */
    private Block() {
        direction = Direction.STILL;
    }

    /**
     * @return the instance of the Block (Singleton Design Pattern)
     */
    public static Block getInstance() {
        if(instance==null) instance = new Block();
        return instance;
    }

    /**
     * Sets the direction the block is moving towards.
     * @param direction the direction
     */
    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    /**
     * Handles the movement of the block.
     */
    public void move() {
        switch (direction) {
            case UP -> {
                if(y - Model.TILE_SIZE >= 0) y-= Model.TILE_SIZE;
            }
            case DOWN ->{
                if(y + Model.TILE_SIZE < Model.GAMESCREEN_HEIGHT) y+= Model.TILE_SIZE;
            }
            case LEFT ->{
                if(x - Model.TILE_SIZE >= 0) x-= Model.TILE_SIZE;
            }
            case RIGHT -> {
                if(x + Model.TILE_SIZE < Model.SCREEN_WIDTH) x+= Model.TILE_SIZE;
            }
            default -> {}
        }
    }

    /**
     * @return  the x coordinate of the block.
     */
    public int getX() {
        return x;
    }

    /**
     * @return  the y coordinate of the block.
     */
    public int getY() {
        return y;
    }
}
