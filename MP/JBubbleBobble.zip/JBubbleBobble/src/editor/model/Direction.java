package editor.model;

/**
 * Directions for block movement.
 */
public enum Direction {
    LEFT, RIGHT, UP, DOWN, STILL;
}
