package editor.model;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Observable;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import game.model.Animation;
import game.model.entities.opps.*;

/**
 * MVC Model Class.
 */
@SuppressWarnings("deprecation")
public class Model extends Observable {

    private ArrayList<ArrayList<Integer>> level;
    private ArrayList<Enemy> enemies;
    private static Model instance;
    private final Block block;

    public final static int ORIGINAL_TILE_SIZE = 24; // 24x24 tiles
    public final static int SCALE = 1;
    public final static int TILE_SIZE = ORIGINAL_TILE_SIZE*SCALE; // 24x24 tile

    public final static int MAX_SCREEN_COL = 32;
    public final static int MAX_SCREEN_ROW = 26;
    public final static int SCREEN_WIDTH = TILE_SIZE * MAX_SCREEN_COL;
    public final static int GAMESCREEN_HEIGHT = TILE_SIZE * MAX_SCREEN_ROW;

    /**
     * Model constructor. Follows Singleton Design Pattern.
     */
    private Model(){
        level = new ArrayList<>(MAX_SCREEN_ROW);
        block = Block.getInstance();
        enemies = new ArrayList<>();
    }

    /**
     * @return the instance of the Model (Singleton Design Pattern)
     */
    public static Model getInstance(){
        if (instance == null) instance = new Model();
        return instance;
    }

    /**
     * Handles block movement, and notifies the class's observers.
     */
    public void update(){
        block.move();
        block.setDirection(Direction.STILL);

        setChanged();
        notifyObservers();
    }

    /**
     * @return the current block.
     */
    public Block getBlock() { return block; }

    /**
     * @return the enemies ArrayList
     */
    public ArrayList<Enemy> getEnemies(){ return enemies; }

    /**
     * Adds an enemy to the enemies ArrayList.
     * @param enemyType the enemy's class's simple name
     * @param an the enemy's animation
     */
    public void addEnemy(String enemyType, Animation an) {
        boolean busy = false;
        for (Enemy enemy : enemies) {
            if (enemy.getX() == block.getX() && enemy.getY() == block.getY()) {
                busy = true;
                break;
            }
        }
        if (!busy) {
            Enemy e = switch(enemyType){
                case "ZenChan" -> new ZenChan(block.getX(), block.getY(), an);
                case "Mighta" -> new Mighta(block.getX(), block.getY(), an);
                case "Monsta" -> new Monsta(block.getX(), block.getY(), an);
                case "Invader" -> new Invader(block.getX(), block.getY(), an);
                case "Banebou" -> new Banebou(block.getX(), block.getY(), an);
                case "Hidegons" -> new Hidegons(block.getX(), block.getY(), an);

                default -> null;
            };
            enemies.add(e);
        }
    }

    /**
     * @return the level matrix (containing its block information)
     */
    public ArrayList<ArrayList<Integer>> getLevel() { return level; }

    /**
     * Adds a block to the specified location of the level matrix.
     * The coordinates are given by the Block's position.
     * @param  blockInt integer representation of the block that will be added
     */
    public void setBlock(int blockInt) {
        int x = block.getX()/TILE_SIZE;
        int y =  block.getY()/TILE_SIZE;

        if(blockInt == 0){
            for(int i = enemies.size()-1; i>=0 ; i--){
                if(enemies.get(i).getX() == block.getX() && enemies.get(i).getY() == block.getY()) enemies.remove(i);
            }
        }
        level.get(y).set(x, blockInt); //adds a block to the matrix
    }

    /**
     * Saves the transition between two levels.
     * @param levelNumber the first level
     * @param otherLevelNumber the second level
     */
    public void saveLevelTransition(int levelNumber, int otherLevelNumber){
        String levelPath = "level" + levelNumber;
        String otherLevelPath = "level" + otherLevelNumber;
        try{
            BufferedReader levelReader = Files.newBufferedReader(Paths.get(System.getProperty("user.dir")+"/src/game/model/levels/"+ levelPath + "/" + levelPath + ".txt"));
            BufferedReader otherLevelReader = Files.newBufferedReader(Paths.get(System.getProperty("user.dir")+"/src/game/model/levels/" + otherLevelPath + "/" +otherLevelPath + ".txt"));
            BufferedWriter transitionWriter = Files.newBufferedWriter(Paths.get(System.getProperty("user.dir") + "/src/game/model/levels/" + levelPath + "/" +levelPath + "_" + otherLevelPath+ "_transition.txt"));

            ArrayList<String> level = (ArrayList<String>)levelReader.lines().collect(Collectors.toList());
            ArrayList<String> otherLevel = (ArrayList<String>)otherLevelReader.lines().collect(Collectors.toList());

            for(String line : level) transitionWriter.write(line + "\n");
            for(int i = 0; i < 2; i++) transitionWriter.write(level.getLast() + "\n");
            for(int i = 0; i < 4; i++) transitionWriter.write(otherLevel.getFirst() + "\n");
            for(String line : otherLevel) transitionWriter.write(line + "\n");
            levelReader.close();
            otherLevelReader.close();
            transitionWriter.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Saves a newly-created level.
     * @param path the level's name, needed for the file path
     */
    public void saveLevel(String path){
        /*this stream turns the Integer matrix into a Stream, then maps each element of the Stream so that:
        1) the element itself (an Integer ArrayList) becomes a Stream
        2) every element of the stream becomes a String
        3) the Strings get collected into one String with " " as their separator.*/
        Stream<String> stream = level.stream().map( x -> x.stream().map(Object::toString).collect(Collectors.joining(" ")));
        String file = stream.collect(Collectors.joining("\n"));
        try(BufferedWriter br = Files.newBufferedWriter(Paths.get(System.getProperty("user.dir")+"/src/game/model/levels/"+path+"/"+path+".txt"))) {
            br.write(file);
        }catch (IOException e) {
            throw new RuntimeException(e);
        }
        //saving level transitions
        int levelNumber = Integer.parseInt(path.substring(5));
        if(levelNumber == 100){
            saveLevelTransition(20, levelNumber);
            saveLevelTransition(levelNumber, 21);
        }else{
            if(levelNumber > 1) saveLevelTransition(levelNumber -1, levelNumber);
            if(levelNumber < 25) saveLevelTransition(levelNumber, levelNumber+1);
        }
    }

    /**
     * Transforms a String Stream into a 2D Integer matrix
     * @param path the level's name, needed for the file path
     */
    public void readLevel(String path){
        //if the level has already been filled, reset it
        if(!level.equals(new ArrayList<>(MAX_SCREEN_ROW))) level = new ArrayList<>(MAX_SCREEN_ROW);

        /* from a String stream containing the level's representation split into lines, this:
        1) takes each line, splits it and puts it into an Array,
        2) turns the array into a Stream, maps each String in the stream to an Integer, and
        3) collects the Integers into an ArrayList,
        4) adds the ArrayList to the "level" matrix, effectively creating a level
        */
        try(BufferedReader br = Files.newBufferedReader(Paths.get(System.getProperty("user.dir")+"/src/game/model/levels/"+path+"/"+path+".txt"))) {
            Stream<String> stream = br.lines();
            stream.forEach(s -> level.add((ArrayList<Integer>)Arrays.stream(s.split(" ")).map(Integer::parseInt).collect(Collectors.toList())));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Serializes the "enemies" array in the file with the name given in input
     * @param fileName the file name
     */
    public void serializeEnemies(String fileName){
        try{
            FileOutputStream fos = new FileOutputStream(System.getProperty("user.dir")+"/src/game/model/levels/"+fileName +"/" + fileName+ ".enemy");

            ObjectOutputStream oos = new ObjectOutputStream(fos);

            //writes it in binary
            oos.writeObject(enemies);

            oos.close();

        }catch(IOException e) {e.printStackTrace();}
    }

    /**
     * Deserializes the "enemies" array from the file with the name given in input
     * @param fileName the file name
     */
    public ArrayList<Enemy> deserializeEnemy(String fileName){
        ArrayList<Enemy> enemyList = new ArrayList<>();
        try {
            FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"/src/game/model/levels/"+fileName + "/" + fileName + ".enemy");
            ObjectInputStream ois = new ObjectInputStream(fis);

            enemyList = (ArrayList<Enemy>) ois.readObject();
            ois.close();
        }

        catch(ClassNotFoundException | IOException e) {e.printStackTrace();}

        return enemyList;
    }

    /**
     * Sets the enemies ArrayList to the one given in input.
     * @param enemies the new ArrayList
     */
    public void loadEnemies(ArrayList<Enemy> enemies) {
        this.enemies = enemies;
    }
}


