package editor.controller;

import editor.model.Model;
import editor.view.View;

/**
 * JBubbleBobble Level editor main. Runs the game loop.
 */
public class Main {
    public static final int FPS = 15;
    public static final long NS_WAIT = 1000000000/FPS;

    public static void main(String[] args) throws InterruptedException {
        Model m = Model.getInstance();
        View v = View.getInstance();
        new Controller(m,v);

        long timeBefore = 0;
        long timeAfter = 0;
        long timeDifference = 0;

        while(true){
            timeBefore = System.nanoTime();

            m.update();

            timeAfter = System.nanoTime();
            timeDifference = timeAfter - timeBefore;
            long nsSleep = NS_WAIT - timeDifference;
            try {
                Thread.sleep(nsSleep/1000000);
            } catch(IllegalArgumentException e) {e.printStackTrace();}

        }
    }
}
