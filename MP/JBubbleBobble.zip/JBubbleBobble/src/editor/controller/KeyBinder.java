package editor.controller;

import javax.swing.*;

/**
 * Class that handles key bindings.
 */
public class KeyBinder<T extends JPanel> {

    private T jPanel;

    /**
     * KeyBinder constructor.
     */
    public KeyBinder(T jPanel) {
        this.jPanel = jPanel;
    }

    /**
     * Binds an Action to a Binding.
     * @param state the int representation of an InputMap condition (e.g. WHEN_IN_FOCUS)
     * @param b the Binding
     * @param action the action that needs to be bound
     */
    public <R extends AbstractAction> void setAction(int state, Bindings b, R action){
        jPanel.getInputMap(state).put(KeyStroke.getKeyStroke(b.getKey()), b.toString());
        jPanel.getActionMap().put(b.toString(), action);
    }

}
