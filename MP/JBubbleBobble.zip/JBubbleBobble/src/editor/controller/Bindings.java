package editor.controller;

/**
 * Different KeyBindings and their corresponding String representation and KeyStroke.
 */
public enum Bindings {
    MOVE_UP("move up", "UP"), MOVE_DOWN("move down", "DOWN"), MOVE_LEFT("move left", "LEFT"), MOVE_RIGHT("move right", "RIGHT"),
    ENTER("enter", "ENTER"), CTRL_S("control s", "control S"), ESC("escape", "ESCAPE") , MIRROR("mirror", "M");

    private String str;
    private String keyStroke;

    Bindings(String str, String keyStroke) {
        this.str = str;
        this.keyStroke = keyStroke;

    }
    @Override
    public String toString() { return str; }

    /**
     * @return a Binding's KeyStroke.
     */
    public String getKey() { return keyStroke; }
}
