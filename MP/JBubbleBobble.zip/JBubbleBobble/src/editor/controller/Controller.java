package editor.controller;

import editor.model.Direction;
import editor.view.LevelEditor;
import editor.view.View;
import editor.model.Model;
import game.model.Animation;

import javax.swing.*;
import java.awt.event.ActionEvent;

/**
 * MVC Controller class.
 */
public class Controller {

    private KeyBinder keyB;
    private View v;
    private Model m;

    /**
     * Controller constructor. Sets the View and Model instances, and the main key bindings.
     * Sets
     */
    public Controller(Model m, View v){
        this.v = v;
        this.m = m;

        keyB = new KeyBinder<>(v.getLevelPanel());
        keyB.setAction(JComponent.WHEN_IN_FOCUSED_WINDOW, Bindings.MOVE_UP, new MoveAction(Direction.UP));
        keyB.setAction(JComponent.WHEN_IN_FOCUSED_WINDOW, Bindings.MOVE_DOWN, new MoveAction(Direction.DOWN));
        keyB.setAction(JComponent.WHEN_IN_FOCUSED_WINDOW, Bindings.MOVE_LEFT, new MoveAction(Direction.LEFT));
        keyB.setAction(JComponent.WHEN_IN_FOCUSED_WINDOW, Bindings.MOVE_RIGHT, new MoveAction(Direction.RIGHT));

        keyB.setAction(JComponent.WHEN_IN_FOCUSED_WINDOW, Bindings.ENTER, new SetAction());
        keyB.setAction(JComponent.WHEN_IN_FOCUSED_WINDOW, Bindings.CTRL_S, new SaveAction());
        keyB.setAction(JComponent.WHEN_IN_FOCUSED_WINDOW, Bindings.MIRROR, new MirrorAction());

        m.addObserver(v);
    }

    /**
     * Sets a block's direction.
     */
    public void setDirection(Direction d){ m.getBlock().setDirection(d);}

    /**
     * Calls the "setBlock" method in Model, setting the current block.
     */
    public void setBlock(int blockInt) { m.setBlock(blockInt); }

    /**
     * Loads a level by calling the Model's readLevel method.
     */
    public static void loadLevel(String path) {
        Model.getInstance().readLevel(path);
    }

    /**
     * Class that represents a Move Action. Extends AbstractAction.
     * When the action is triggered, it calls setDirection;
     */
    private class MoveAction extends AbstractAction{
        private Direction d;
        MoveAction(Direction direction) {this.d = direction;}
        @Override
        public void actionPerformed(ActionEvent e) {
            setDirection(d);
        }
    }

    /**
     * Class that represents a Set Action. Extends AbstractAction.
     * When the action is triggered, it sets the current enemy or block.
     */
    private class SetAction extends AbstractAction{
        @Override
        public void actionPerformed(ActionEvent e) {
            LevelEditor levelEditor = v.getLevelPanel().getLevelEditor();

            if(levelEditor.getCurrentEnemy() != ""){
                m.addEnemy(levelEditor.getCurrentEnemy(), levelEditor.getCurrentEnemyAnimation());
            }
            else setBlock(v.getLevelPanel().getCurrentBlock());
        }
    }
    /**
     * Class that represents a Save Action. Extends AbstractAction.
     * When the action is triggered, it calls the method to display the "saved" image,
     * and saves the level.
     */
    private class SaveAction extends AbstractAction{
        @Override
        public void actionPerformed(ActionEvent e) {
            LevelEditor.getInstance().showSaved();
            String path = v.getPath();
            m.saveLevel(path);
            m.serializeEnemies(path);
        }
    }

    /**
     * Class that represents a Mirror Action. Extends AbstractAction.
     * When the action is triggered, it flips the enemy's animation, effectively mirroring it.
     */
    private class MirrorAction extends AbstractAction{
        @Override
        public void actionPerformed(ActionEvent e){
            Animation animation = v.getLevelPanel().getLevelEditor().getCurrentEnemyAnimation() == Animation.LEFT ? Animation.RIGHT : Animation.LEFT;
            v.getLevelPanel().getLevelEditor().setCurrentEnemyAnimation(animation);
        }
    }
}
