package editor.view;

import java.util.Observable;
import java.util.Observer;

/**
 * MVC View Class
 */
@SuppressWarnings("deprecation")
public class View  implements Observer {
    private static View instance;
    private final Frame frame;

    /**
     * View constructor. Follows the Singleton Design Pattern.
     */
    private View() {
        frame = Frame.getInstance();
    }

    /**
     * @return the instance of the View (Singleton Design Pattern)
     */
    public static View getInstance() {
        if (instance == null) instance = new View();
        return instance;
    }

    @Override
    public void update(Observable o, Object ob) {
        frame.repaint();
    }

    /**
     * @return the LevelPanel from the Frame
     */
    public LevelPanel getLevelPanel() {
        return frame.getLevelPanel();
    }
    /**
     * @return the path to the current level (from the frame)
     */
    public String getPath() {return frame.getPath();}
}
