package editor.view;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.HashMap;

import game.model.Animation;
import game.model.entities.opps.*;
import game.model.BlockType;

/**
 * Handles the Images for the level editor.
 */
public class ImageUtil {
    private final HashMap<BlockType, BufferedImage> blocks;
    private final HashMap<String, HashMap<Animation, BufferedImage>> enemies;
    private final HashMap<String, BufferedImage> levelIcons;
    private static ImageUtil instance;

    /**
     * ImageUtil constructor. Creates the "blocks" HashMap, which contains all the block images.
     * Follows the Singleton Design Pattern.
     */
    private ImageUtil() {
        enemies = new HashMap<>();
        blocks = new HashMap<>();
        dealImages();

        levelIcons = new HashMap<>();
        dealIcons();
    }

    /**
     * @return the instance of the ImageUtil (Singleton Design Pattern)
     */
    public static ImageUtil getInstance() {
        if (instance == null) instance = new ImageUtil();
        return instance;
    }

    /**
     * @return the "blocks" HashMap, containing all the block icons.
     */
    public HashMap<BlockType, BufferedImage> getBlocks(){
        return blocks;
    }

    /**
     *Adds the different Block images to the "blocks" HashMap and to the "enemies" HashMap
     */
    public void dealImages(){
        try {
            blocks.put(BlockType.ZERO, ImageIO.read(ImageUtil.class.getResource("../../resources/blocks/empty.png")));

            BlockType blockType;
            for(int i=1; i<101; i++){
                blocks.put(BlockType.getBlock(i), ImageIO.read(ImageUtil.class.getResource("../../resources/blocks/super blocks/block_"+i+".png")));
            }

            HashMap<Animation, BufferedImage> zenChanSprites = new HashMap<>();
            zenChanSprites.put(Animation.LEFT, ImageIO.read(ImageUtil.class.getResource("../../resources/sprites/zen-chan/normal left/left1.png")));
            zenChanSprites.put(Animation.RIGHT, ImageIO.read(ImageUtil.class.getResource("../../resources/sprites/zen-chan/normal right/right1.png")));
            enemies.put(ZenChan.class.getSimpleName(), zenChanSprites);

            HashMap<Animation, BufferedImage> mightaSprites = new HashMap<>();
            mightaSprites.put(Animation.LEFT, ImageIO.read(ImageUtil.class.getResource("../../resources/sprites/mighta/normal left/left1.png")));
            mightaSprites.put(Animation.RIGHT, ImageIO.read(ImageUtil.class.getResource("../../resources/sprites/mighta/normal right/right1.png")));
            enemies.put(Mighta.class.getSimpleName(), mightaSprites);

            HashMap<Animation, BufferedImage> monstaSprites = new HashMap<>();
            monstaSprites.put(Animation.LEFT, ImageIO.read(ImageUtil.class.getResource("../../resources/sprites/monsta/normal left/left1.png")));
            monstaSprites.put(Animation.RIGHT, ImageIO.read(ImageUtil.class.getResource("../../resources/sprites/monsta/normal right/right1.png")));
            enemies.put(Monsta.class.getSimpleName(), monstaSprites);

            HashMap<Animation, BufferedImage> invaderSprites = new HashMap<>();
            invaderSprites.put(Animation.LEFT, ImageIO.read(ImageUtil.class.getResource("../../resources/sprites/invader/normal/normal1.png")));
            invaderSprites.put(Animation.RIGHT, ImageIO.read(ImageUtil.class.getResource("../../resources/sprites/invader/normal/normal1.png")));
            enemies.put(Invader.class.getSimpleName(), invaderSprites);

            HashMap<Animation, BufferedImage> banebouSprites = new HashMap<>();
            banebouSprites.put(Animation.LEFT, ImageIO.read(ImageUtil.class.getResource("../../resources/sprites/banebou/normal left/left1.png")));
            banebouSprites.put(Animation.RIGHT, ImageIO.read(ImageUtil.class.getResource("../../resources/sprites/banebou/normal right/right1.png")));
            enemies.put(Banebou.class.getSimpleName(), banebouSprites);

            HashMap<Animation, BufferedImage> hidegonsSprites = new HashMap<>();
            hidegonsSprites.put(Animation.LEFT, ImageIO.read(ImageUtil.class.getResource("../../resources/sprites/hidegons/normal left/walk/left1.png")));
            hidegonsSprites.put(Animation.RIGHT, ImageIO.read(ImageUtil.class.getResource("../../resources/sprites/hidegons/normal right/walk/right1.png")));
            enemies.put(Hidegons.class.getSimpleName(), hidegonsSprites);

        } catch (IOException e) { e.printStackTrace();}
    }

    /**
     *Adds the icons for the level buttons to the "levelIcons" HashMap
     */
    public void dealIcons(){
        for(int i=1; i<26; i++){
            try{
                levelIcons.put("level"+i, ImageIO.read(ImageUtil.class.getResource("../../resources/panels/level"+i+".png")));
            }catch(IOException f) { f.printStackTrace();}
        }
    }

    /**
     * @param path the path to an image
     * @return a single BufferedImage
     */
    public static BufferedImage getImage(String path){
        BufferedImage image = null;
        try{
            image = ImageIO.read(game.view.ImageUtil.class.getResource(path));
        }catch(IOException e){e.printStackTrace();}
        return image;
    }

    /**
     * @return the levelIcons HashMap, containing the icons for the level buttons
     */
    public HashMap<String, BufferedImage> getLevelIcons(){return levelIcons;}

    /**
     * @return the enemies HashMap, containing the icons for the enemy buttons
     */
    public HashMap<String, HashMap<Animation, BufferedImage>> getEnemies(){return enemies;}

}
