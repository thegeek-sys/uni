package editor.view;

import editor.model.Model;

import javax.swing.*;
import java.awt.*;

/**
 * Level panel for the editor.
 * Contains the LevelEditor and the UtilBar panels.
 */
public class LevelPanel extends JPanel {

    private final LevelEditor levelEditor;

    /**
     * LevelPanel constructor.
     * Creates an instance of a Utilbar, sets some options.
     */
    public LevelPanel(){
        UtilBar utilBar = new UtilBar();
        levelEditor = LevelEditor.getInstance();

        setLayout(new BorderLayout());
        setBackground(Color.BLACK);

        add(utilBar, BorderLayout.PAGE_START);
        add(levelEditor, BorderLayout.CENTER);

        setSize(new Dimension(Model.SCREEN_WIDTH, Frame.SCREEN_HEIGHT));

        setFocusable(true);
        setVisible(true);
    }

    /**
     * @return The int representation of the current block
     */
    public int getCurrentBlock(){ return levelEditor.getCurrentBlock(); }

    /**
     * @return The levelEditor panel.
     */
    public LevelEditor getLevelEditor() { return levelEditor; }

}