package editor.view;

import game.view.ButtonFactory;
import game.view.ImageUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

/**
 * Help panel, containing the commands for the editor.
 */
public class HelpScreen extends JPanel {

    /**
     * HelpScreen constructor. Creates a help screen for the editor, containing the commands.
     * @param cardLayout organiser panel's cardLayout, needed to make the button show the editor.
     * @param manager organiser panel which shows the different screens
     */
    public HelpScreen(CardLayout cardLayout, JPanel manager){

        setLayout(new GridBagLayout());


        GridBagConstraints commandsGBC = new GridBagConstraints();

        commandsGBC.gridx = 1;
        commandsGBC.gridy = 1;
        commandsGBC.weightx = 1;
        commandsGBC.weighty = 1;
        commandsGBC.insets = new Insets(315, 0, 0, 10);

        add(ButtonFactory.createShowButton(new Dimension(226,48), "../../resources/panels/backeditor.png", cardLayout, manager, "levelPanel"), commandsGBC);
    }


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        BufferedImage background = ImageUtil.getImage( "../../resources/panels/editorCommands.png");
        g.drawImage(background, 0,0, null);
    }

}
