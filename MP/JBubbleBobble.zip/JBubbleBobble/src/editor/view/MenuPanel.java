package editor.view;

import editor.model.Model;
import game.view.ButtonFactory;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

/**
 * Editor main menu panel. Lets you choose which level to edit.
 */
public class MenuPanel extends JPanel {
    private final JPanel manager;
    private final CardLayout cardLayout;
    private final int levNum;

    HashMap<String, BufferedImage> levelIcons;

    /**
     * MenuPanel constructor.
     * Creates its sub-panels and sets its layout up.
     * @param cardLayout the organiser panel's CardLayout, used to display different panels.
     * @param manager the organiser panel, which shows the different panels
     */
    public MenuPanel(CardLayout cardLayout, JPanel manager){
        this.cardLayout = cardLayout;
        this.manager = manager;
        this.levNum = 25;
        this.levelIcons = ImageUtil.getInstance().getLevelIcons();

        setSize(new Dimension(Model.SCREEN_WIDTH, Frame.SCREEN_HEIGHT));
        setLayout(new GridBagLayout()); //needed to center the level buttons

        JPanel buttonPanel = new JPanel(){ //panel that contains the buttons
            {
                setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));//vertical
                setBackground(Color.BLACK);
                addButtons(this);
            }
        };

        JScrollPane scrollPane = new JScrollPane(buttonPanel){ //makes the buttonPanel scrollable
            {
                setPreferredSize(new Dimension(250, 400));
                setBorder(null);
                getVerticalScrollBar().setBackground(Color.BLACK);
            }
        };
        GridBagConstraints gbc = new GridBagConstraints(); //centering
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(scrollPane, gbc);
    }

    /**
     * Adds buttons to the provided JPanel.
     * The buttons are created by the ButtonFactory class.
     * @param buttonList the JPanel to add the buttons to
     */
    public void addButtons(JPanel buttonList){
        for(int i=1; i<levNum+1; i++){

            String levName = "level"+i;
            buttonList.add(Box.createRigidArea(new Dimension(0, 7)));

            buttonList.add(ButtonFactory.createRowButton(new ImageIcon(levelIcons.get(levName)),
                    e -> { Frame.getInstance().setPath(levName);
                Model.getInstance().loadEnemies(Model.getInstance().deserializeEnemy(levName));
                cardLayout.show(manager, "levelPanel");}));

            buttonList.add(Box.createRigidArea(new Dimension(0, 7)));
        }

        //secret level
        String levName = "level100";
        buttonList.add(new JButton(){
            {
                setAlignmentX(Component.CENTER_ALIGNMENT);
                addActionListener(e -> {
                    cardLayout.show(manager, "levelPanel");
                    Frame.getInstance().setPath(levName);
                    Model.getInstance().loadEnemies(Model.getInstance().deserializeEnemy(levName));
                });

                setBorder(BorderFactory.createEmptyBorder());
                setContentAreaFilled(false);

                setIcon(new ImageIcon(ImageUtil.getImage("../../resources/panels/level100.png")));
            }
        });
        buttonList.add(Box.createRigidArea(new Dimension(0, 7)));
    }

    @Override
    public void paintComponent(Graphics g){
        BufferedImage background;
        super.paintComponent(g);
        background = ImageUtil.getImage("../../resources/panels/background.png");
        g.drawImage(background, 0,0,null);
    }

}
