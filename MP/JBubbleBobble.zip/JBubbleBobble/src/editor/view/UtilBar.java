package editor.view;

import game.model.BlockType;
import editor.model.Model;
import game.model.Animation;
import game.view.ButtonFactory;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Bar containing the buttons to choose which enemy or block to place in the level.
 */
public class UtilBar extends JPanel {
    private final HashMap<BlockType, BufferedImage> blocks;
    private final HashMap<String,HashMap<Animation, BufferedImage>> enemies;
    public static final int HEIGHT = 168;

    /**
     * UtilBar constructor.
     * Gets the "blocks" and the "enemies" HashMaps from ImageUtil, and sets up the buttons used to edit a level.
     */
    public UtilBar() {
        setPreferredSize(new Dimension(Model.SCREEN_WIDTH, HEIGHT));
        blocks = ImageUtil.getInstance().getBlocks();
        enemies = ImageUtil.getInstance().getEnemies();

        for(int i = 0; i < blocks.size()-1; i++){
            BlockType curBlockType = BlockType.getBlock(i);

            ImageIcon icon = new ImageIcon(blocks.get(curBlockType).getScaledInstance(Model.TILE_SIZE, Model.TILE_SIZE, Image.SCALE_SMOOTH));

            add(ButtonFactory.createActionButton(new Dimension(Model.TILE_SIZE, Model.TILE_SIZE), icon,
                    e->  {LevelEditor.getInstance().setCurrentBlock(curBlockType); LevelEditor.getInstance().setCurrentEnemy("");}));
            add((Box.createRigidArea(new Dimension(0, 28))));
        }


        for(int j=0; j<enemies.size(); j++){
            ArrayList<String> enemyTypes = new ArrayList<String>(enemies.keySet());
            String enemyType = enemyTypes.get(j);

            ImageIcon eIcon = new ImageIcon(enemies.get(enemyType)
                    .get(Animation.LEFT).getScaledInstance(Model.TILE_SIZE, Model.TILE_SIZE, Image.SCALE_SMOOTH));
            add(ButtonFactory.createActionButton(new Dimension(Model.TILE_SIZE, Model.TILE_SIZE),eIcon, e -> LevelEditor.getInstance().setCurrentEnemy(enemyType)));
        }

        add(new JButton("help"){
            {
                addActionListener(e-> Frame.getInstance().getCardLayout().show(Frame.getInstance().getManager(), "commands"));
            }
        });

        add(new JButton("back"){
            {
                addActionListener(e-> Frame.getInstance().getCardLayout().show(Frame.getInstance().getManager(), "menuPanel"));
            }
        });

        //for the "grid" layout
        setLayout(new FlowLayout(FlowLayout.LEFT, 5, 5));
    }
}