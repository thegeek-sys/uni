package editor.view;

import editor.model.Model;
import editor.controller.Controller;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * JBubbleBobble editor Frame.
 */
public class Frame extends JFrame {

    private final JPanel manager;
    private final LevelPanel levelPanel;
    private static Frame instance;
    private final CardLayout cardLayout;
    private String path; //path to the current level

    public final static int SCREEN_HEIGHT = Model.TILE_SIZE * Model.MAX_SCREEN_ROW + UtilBar.HEIGHT;

    /**
     * Frame constructor.
     * Sets some options, and creates the main panels.
     * Follows the Singleton Design Pattern
     */
    private Frame(){
        super("Level Editor");
        setSize(new Dimension(Model.SCREEN_WIDTH, SCREEN_HEIGHT));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);

        //needed to switch between different panels
        cardLayout = new CardLayout();
        manager = new JPanel(cardLayout);
        manager.setSize(Model.SCREEN_WIDTH, SCREEN_HEIGHT);

        MenuPanel menu = new MenuPanel(cardLayout, manager);

        HelpScreen commands = new HelpScreen(cardLayout, manager);

        levelPanel = new LevelPanel();
        manager.add(commands, "commands");
        manager.add(menu, "menuPanel");
        manager.add(levelPanel, "levelPanel");

        add(manager);
        cardLayout.show(manager, "menuPanel");
        path = "";

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    /**
     * @return the instance of the Frame (Singleton Design Pattern)
     */
    public static Frame getInstance(){
        if (instance == null) instance = new Frame();
        return instance;
    }

    @Override
    public void repaint(){levelPanel.repaint();}

    @Override
    public void addKeyListener(KeyListener k) { levelPanel.addKeyListener(k); }

    /**
     * @return the levelPanel
     */
    public LevelPanel getLevelPanel() {return levelPanel;}

    /**
     * Loads a level (in levelPanel), and reads it (in View)
     * @param path level path
     */
    public void setPath(String path) {
        this.path = path;
        Controller.loadLevel(path);
    }

    /**
     * @return the path to the current level
     */
    public String getPath() { return path; }

    /**
     * @return the CardLayout used to display the panels
     */
    public CardLayout getCardLayout(){return cardLayout;}

    /**
     * @return the panel on which the different panels are shown through a CardLayout
     */
    public JPanel getManager(){return manager;}
}
