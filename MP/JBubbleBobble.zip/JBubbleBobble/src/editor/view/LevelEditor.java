package editor.view;

import game.model.BlockType;
import editor.model.Model;

import game.model.Animation;
import game.model.entities.opps.Enemy;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;


public class LevelEditor extends JPanel{
    private BlockType currentBlock;
    private String currentEnemy;
    private Animation currentEnemyAnimation;
    private static LevelEditor instance;
    private int flash;
    public static final long SAVE_ANIMATION_LENGTH = 300_000_000L;
    private long saveAnimationTimer;
    private JLabel saved;

    /**
     * Panel in which the level is displayed.
     */
    private LevelEditor(){
        setBackground(Color.black);
        setFocusable(true);
        requestFocus();
        setPreferredSize(new Dimension(Model.SCREEN_WIDTH,Frame.SCREEN_HEIGHT- UtilBar.HEIGHT));
        currentBlock = BlockType.ZERO;
        currentEnemyAnimation = Animation.LEFT;
        currentEnemy = "";
        saveAnimationTimer = 0L;
    }

    /**
     * @return the instance of the LevelEditor (Singleton Design Pattern)
     */
    public static LevelEditor getInstance(){
        if(instance==null) instance = new LevelEditor();
        return instance;
    }

    @Override
    public void paintComponent(Graphics g){
        Model m = Model.getInstance();
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(Color.white);

        //draw level
        for(int i = 0; i < Model.MAX_SCREEN_ROW; i++){
            for(int j = 0; j < Model.MAX_SCREEN_COL; j++){
                g2.drawImage(ImageUtil.getInstance().getBlocks().get(BlockType.getBlock(Model.getInstance().getLevel().get(i).get(j))),
                        j * Model.TILE_SIZE, i * Model.TILE_SIZE , Model.TILE_SIZE, Model.TILE_SIZE, null);

            }
        }
        //show enemies
        for(int i = 0; i < m.getEnemies().size(); i++){
            Enemy e = m.getEnemies().get(i);
            g2.drawImage(ImageUtil.getInstance().getEnemies().get(e.getClass().getSimpleName()).get(
                    e.getAnimation()), e.getX(), e.getY(), Model.TILE_SIZE * 2, Model.TILE_SIZE * 2, null
            );
        }

        if(!currentEnemy.isEmpty()){
            g2.drawImage(ImageUtil.getInstance().getEnemies().get(currentEnemy).get(currentEnemyAnimation),
                    m.getBlock().getX(), m.getBlock().getY(),
                    Model.TILE_SIZE*2, Model.TILE_SIZE*2, null);
        } else {
            g2.drawImage(ImageUtil.getInstance().getBlocks().get(currentBlock), m.getBlock().getX(), m.getBlock().getY(),
                Model.TILE_SIZE, Model.TILE_SIZE, null);
        }
        if(flash < 5){
            g2.drawRect(m.getBlock().getX(), m.getBlock().getY(), Model.TILE_SIZE, Model.TILE_SIZE);;
        }
        flash = (flash == 9 ? 0 : flash + 1);

        drawSaved(g2);

        g2.dispose();
    }

    /**
     * Invoked when CRTL-S is clicked while in the level editor.
     * Starts the timer to show the "saved!" text.
     */
    public void showSaved(){
        saveAnimationTimer = System.nanoTime();
    }

    /**
     * Handles the "saved!" text shown when a level is saved.
     * If the timer still hasn't run out, it shows it. Else, it resets the timer.
     */
    public void drawSaved(Graphics2D g2){
        if(saveAnimationTimer != 0 && (System.nanoTime() - saveAnimationTimer <= SAVE_ANIMATION_LENGTH)){
            BufferedImage saved = ImageUtil.getImage("../../resources/panels/saved.png");
            g2.drawImage(saved, 260, 250, 250, 125, null);
        }

        if(saveAnimationTimer != 0 && (System.nanoTime() - saveAnimationTimer >= SAVE_ANIMATION_LENGTH)){
            saveAnimationTimer = 0;
        }

    }

    /**
     * @return the current BlockType's value (according to the enum).
     */
    public int getCurrentBlock() {
        return currentBlock.getValue(); }

    /**
     * Sets the current BlockType.
     */
    public void setCurrentBlock(BlockType b) {
        currentBlock = b;
    }
    /**
     * Sets the current Enemy.
     */
    public void setCurrentEnemy(String currentEnemy) { this.currentEnemy = currentEnemy; }
    /**
     * @return  the current Enemy.
     */
    public String getCurrentEnemy(){ return currentEnemy; }

    /**
     * Sets the current Enemy's Animation (facing the left or the right).
     */
    public void setCurrentEnemyAnimation(Animation currentEnemyAnimation) { this.currentEnemyAnimation = currentEnemyAnimation;}

    /**
     * @return  the current Enemy's Animation.
     */
    public Animation getCurrentEnemyAnimation() { return currentEnemyAnimation; }


}
