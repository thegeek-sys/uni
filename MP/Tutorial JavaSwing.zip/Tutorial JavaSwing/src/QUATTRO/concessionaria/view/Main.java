package QUATTRO.concessionaria.view;

public class Main {
    public static void main(String[] args) {

        new Frame();
    }
}
